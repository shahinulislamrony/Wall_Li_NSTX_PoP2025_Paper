import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from matplotlib import gridspec
from scipy.optimize import curve_fit




dt = 1e-4    # Time step size (seconds)
t_sim = 5e-0
Nt = int(t_sim/dt)  # 100    # Number of time steps
DEPTH = 0.05
LI_DENSITY  =  535 
heat_vaporization_J_per_mol = 147000  # J/mol Heat of Vaporization 	147 kJ/mol
avogadro_number = 6.022e23
heat_per_atom = heat_vaporization_J_per_mol / avogadro_number


li_coeff = 2.44e-19 
Tinbc = 25 
T_air = 25
h_air = 10.0  # heat transfer coefficient (W/m^2K), vary from 5-25
h=0
I0 = 5.39 * 1.60218e-19      # 1st ionization potential [J]
I1 = 75.6 * 1.60218e-19      # 2nd ionization potential [J]
I2 = 122.4 * 1.60218e-19     # 3rd ionization potential [J]


T_ambient = 25  # Ambient temperature (°C)
energy_per_Li3_neutralization = I0 + I1 + I2

###UEDGE div cordinates, com.yyrb
x_data = np.array([-0.05544489, -0.0507309, -0.04174753, -0.03358036, -0.02614719, -0.01935555, -0.01316453, -0.00755603, -0.00245243, 0.00497426,
                   0.012563, 0.01795314, 0.02403169, 0.03088529, 0.03865124, 0.04744072, 0.05723254, 0.06818729, 0.0804908, 0.09413599,
                   0.10907809, 0.12501805, 0.14181528, 0.15955389, 0.17792796, 0.18716496]) 

q_data = np.array([8.516863747058426088e+04,
8.516863747058426088e+04,
8.658732672732640640e+04,
9.224168689024644846e+04,
1.082405806727624731e+05,
1.466081975609702058e+05,
2.283389318490335718e+05,
4.005193897112387349e+05,
9.411837655898311641e+05,
8.442317867601789534e+06,
6.758609278505317867e+06,
6.093629471681456082e+06,
5.143711920255075209e+06,
4.166083592164705973e+06,
3.367501593478952069e+06,
2.760775028947197832e+06,
2.298189146693516523e+06,
1.918289905024330597e+06,
1.605707128312068060e+06,
1.355246104763937416e+06,
1.158708622615067521e+06,
1.007663975185001036e+06,
8.828309174558679806e+05,
7.124721239178314572e+05,
3.894704975398445386e+05,
3.894704975398445386e+05,
])

Lx = 0.05
Ly = x_data[-1] - x_data[0] # Length of the plate in y-direction (meters)
Nx = 91 # len(q_data)*1 #20     # Number of spatial points in x-direction
Ny = len(q_data)      # Number of spatial points in y-direction

dx = Lx / (Nx - 1)
dy = Ly / (Ny - 1)

print('dx is:', dx)
print('Nx is:', Nx)

graphite_x_pos = int(Nx/10) #int(0.01 * scale_factor)

#Li property
thermal_conductivity = 64  # W/(m·K)


def eval_Li_evap_at_T_Cel(temperature):
    a1 = 5.055  
    b1 = -8023.0
    xm1 = 6.939 
    tempK = abs(temperature) + 273.15

    if np.any(tempK <= 0):
        raise ValueError("Temperature must be above absolute zero (-273.15°C).")

    vpres1 = 760 * 10**(a1 + b1/tempK)  
    
    sqrt_argument = xm1 * tempK
    if np.any(sqrt_argument <= 0):
        raise ValueError(f"Invalid value for sqrt: xm1 * tempK has non-positive values.")

    fluxEvap = 1e4 * 3.513e22 * vpres1 / np.sqrt(sqrt_argument)  
    return fluxEvap


def solve_heat_equation_2d(Lx, Ly, Nx, Ny, dt, Nt, boundary_conditions, graphite_x_pos, h, T_ambient):
    dx = Lx / (Nx - 1)
    dy = Ly / (Ny - 1)

    lithium_thickness = graphite_x_pos * dx  # Physical thickness of Li
    thickness_mm = lithium_thickness * 1e3
    print("Li thickness (mm):", thickness_mm)

    volume_li = Lx * lithium_thickness * DEPTH
    mass_li = LI_DENSITY * volume_li  # kg
    print("Lithium mass (g):", mass_li * 1e3)

   
    T = np.full((Ny, Nx), 25.0)  # Initial temperature in °C
    q_x = np.zeros((Ny, Nx))
    q_y = np.zeros((Ny, Nx))

    temp_surf = []
    no_itera = []
    evap_loss_history = []
    latent_loss_history = []
    evap_power = []
    latent_power = []

    for n in range(Nt):
        T_new = T.copy()

        for i in range(1, Nx - 1):
            for j in range(1, Ny - 1):
                T_ij = T[j, i]
                if i < graphite_x_pos:  # Lithium region
                    kappa = Li_thermal_conductivity(T_ij)
                    cp = specific_heat_Cp(T_ij)
                    rho = Li_rho(T_ij)
                else:  # Graphite region
                    kappa = C_thermal_conductivity(T_ij)
                    cp = C_specific_heat(T_ij)
                    rho = graphite_density(T_ij)  

                alpha = 1 / (rho * cp)

                # Compute conductivity at cell faces (averaged)
                # X direction
                T_ip = T[j, i + 1]
                T_im = T[j, i - 1]
                if i + 1 < graphite_x_pos:
                    kappa_ip = Li_thermal_conductivity(T_ip)
                else:
                    kappa_ip = C_thermal_conductivity(T_ip)
                if i - 1 < graphite_x_pos:
                    kappa_im = Li_thermal_conductivity(T_im)
                else:
                    kappa_im = C_thermal_conductivity(T_im)
                kappa_xp = 0.5 * (kappa + kappa_ip)
                kappa_xm = 0.5 * (kappa + kappa_im)

                # Y direction
                T_jp = T[j + 1, i]
                T_jm = T[j - 1, i]
                # Assume same region in y (or you can check based on i)
                if i < graphite_x_pos:
                    kappa_jp = Li_thermal_conductivity(T_jp)
                    kappa_jm = Li_thermal_conductivity(T_jm)
                else:
                    kappa_jp = C_thermal_conductivity(T_jp)
                    kappa_jm = C_thermal_conductivity(T_jm)
                kappa_yp = 0.5 * (kappa + kappa_jp)
                kappa_ym = 0.5 * (kappa + kappa_jm)

                # Correct alpha
                alpha = kappa / (rho * cp)

                # Discretized 2D heat equation with variable kappa
                term_x = (kappa_xp * (T_ip - T_ij) - kappa_xm * (T_ij - T_im)) / dx**2
                term_y = (kappa_yp * (T_jp - T_ij) - kappa_ym * (T_ij - T_jm)) / dy**2

                T_new[j, i] = T_ij + dt * (term_x + term_y) / (rho * cp)

                # Heat fluxes (Fourier's law, use face-averaged kappa)
                dT_dx = (T_ip - T_im) / (2 * dx)
                dT_dy = (T_jp - T_jm) / (2 * dy)
                q_x[j, i] = -kappa * dT_dx
                q_y[j, i] = -kappa * dT_dy

        # Left boundary: lithium surface with evaporation + conduction + latent heat
        try:
            evap_flux = 0#eval_Li_evap_at_T_Cel(T_new[:, 1])  # atoms/m²/s
            heat_loss_evap = 0#evap_flux * heat_per_atom  
            
            heat_flux_Li_surface = q_data 
            
           
            #print(f"Step {n}, Energy loss (J): evaporation = {total_evap_loss:.2e}, latent heat = {total_latent_loss:.2e}")
      
    
            kappa_left = np.vectorize(Li_thermal_conductivity)(T_new[:, 0])
            
            T_new[:, 0] = T[:, 1] + (heat_flux_Li_surface * dx) / kappa_left

        except ValueError as e:
            print(f"Left boundary error: {e}")
            T_new[:, 0] = T[:, 1] + boundary_conditions['left'](np.linspace(0, Lx, Nx), dx)

        # Other boundaries: Neumann (no flux)
        T_new[0, :] = T_new[1, :]
        T_new[-1, :] = T_new[-2, :]
        T_new[:, -1] = T_new[:, -2]

        # Convergence check
        max_change = np.max(np.abs(T_new - T))
        temp_surface = np.max(T_new[:, 1])
        temp_surf.append(temp_surface)
        no_itera.append(n)

        T = T_new.copy()

        if max_change < 1e-5:
            print(f"Converged at t={n * dt:.2e}s, ΔT_max={max_change:.2e}")
            break

        # Save plots periodically
        if n % (Nt // 10) == 0:
            x = np.linspace(0, Lx, Nx)
            y = np.linspace(0, Ly, Ny)
            X, Y = np.meshgrid(x, y)
            plt.figure(figsize=(12, 6))
            plt.contourf(X, Y, T, cmap='inferno')
            plt.colorbar(label='Temperature (°C)')
            plt.xlabel('x (m)')
            plt.ylabel('y (m)')
            plt.title(f'Temperature at t={n * dt:.4e} s')
            plt.axvline(x=graphite_x_pos * dx, color='g', linestyle='--', label='Graphite start')
            plt.annotate('Graphite', xy=(graphite_x_pos * dx, 0.02),
                         xytext=(graphite_x_pos * dx + 0.005, 0.1 * Ly),
                         arrowprops=dict(facecolor='black', width=2),
                         fontsize=14, color='red')
            plt.legend()
            plt.savefig(f'time{n * dt:.3e}.png', dpi=300)
            #plt.show()
            

    return T, no_itera, temp_surf, heat_flux_Li_surface, q_x, q_y


#  https://doi.org/10.1080/00319104.2019.1636377
def Li_rho(T_C):
    """Density as a function of temperature (T in Celsius)."""
    T_K = T_C + 273.15  # Convert Celsius to Kelvin
    return 562 - 0.10 * T_K

def Li_thermal_conductivity(T_C):
    T_K = T_C + 273.15  # Convert Celsius to Kelvin
    if 200 < T_K < 453: 
        return 44 + 0.02019 * T_K + 8037 / T_K
    else:
        return 33.25+ 0.0368 * T_K + 1.096e-5 * (T_K)**2


def specific_heat_Cp (T):
    T_K = T + 273.15  # Convert Celsius to Kelvin
    if 200 < T_K < 453: 
        return (-6.999e8/(T_K)**4 + 1.087e4/(T_K)**2 + 3.039 + 5.605e-6*(T_K)**2)*1e3
    else:
      #  return 21.42 + 0.05230 * T_K + 1.371e-5 * (T_K)**2
        return (1.044e5/(T_K)**2 - 135.1/(T_K) + 4.180)*1e3

###Andrei Khodak data for NSTX-U, 02/19/2025
def C_specific_heat(T):

    Cp = -0.000000 * T**4 + 0.000003 * T**3 - 0.004663 * T**2 + 3.670527 * T + 630.194408
    return Cp


T_exp = np.array([0, 25, 125, 300, 425, 600, 725, 1200, 1225, 1725, 2000])  # °C
K_exp = np.array([105.26, 102.56, 93.02, 80.0, 72.73, 64.52, 59.70, 46.51, 45.98, 37.38, 33.90])  # W/m·K


def quadratic_func(T, a, b, c):
    return a * T**2 + b * T + c

popt, _ = curve_fit(quadratic_func, T_exp, K_exp)
a, b, c = popt

def C_thermal_conductivity(T):
    return a * T**2 + b * T + c

T_graphite = np.array([0, 20, 100, 200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800])  # °C
density_graphite = np.array([1.82, 1.81, 1.79, 1.77, 1.73, 1.69, 1.66, 1.63, 1.60, 1.57, 1.54, 1.50]) * 1e3  # kg/m³

# Fit cubic polynomial (degree 3)
coeffs = np.polyfit(T_graphite, density_graphite, 3)

def graphite_density(T_C):

    a, b, c, d = coeffs
    return a * T_C**3 + b * T_C**2 + c * T_C + d



Ny_data = len(q_data)
q_data = np.interp(np.linspace(0, 1, Ny), np.linspace(0, 1, Ny_data), q_data)

# Boundary condition functions
def left_boundary(x,dx):
    # Use q_data directly, since it's in W/m² and is applied to the boundary, q*dy/k
    return np.interp(y, np.linspace(0, Ly, len(q_data)), q_data)*dx / thermal_conductivity  

def right_boundary(y,T_ambient):
    return T_ambient 

def bottom_boundary(x, h, T_ambient, dx):
     return T_ambient + (h * (T_ambient - 0)) * dx / 0.025 
  
def top_boundary(x, h, T_ambient, dx):
    return T_ambient + (h * (T_ambient - 0)) * dx / 0.025  

boundary_conditions = {
    'left': left_boundary,
    'right': right_boundary,
    'bottom': bottom_boundary,
    'top': top_boundary
}



# Solve the heat equation
T = solve_heat_equation_2d(Lx, Ly, Nx, Ny, dt, Nt, boundary_conditions, graphite_x_pos,  h, T_ambient)

# Prepare the mesh grid
x = np.linspace(0, Lx, Nx)
y = np.linspace(0, Ly, Ny)
X, Y = np.meshgrid(x, y)

# Plot the temperature distribution in lithium and graphite layers 
plt.figure(figsize=(6, 4))

plt.contourf(X, Y, T[0], cmap='inferno') 
#plt.colorbar(label='Temperature (°C)')
cbar = plt.colorbar()
cbar.set_label('Temperature (°C)', fontsize=18)
cbar.ax.yaxis.set_tick_params(labelsize=14)
plt.xlabel('x (m)', fontsize = 18)
plt.ylabel('y (m)', fontsize = 18)
plt.title('Temperature Distribution')
plt.axvline(x=graphite_x_pos * dx, color='g', linestyle='--', label='Graphite Position')
plt.annotate('Graphite Region', xy=(graphite_x_pos * dx, 0.002), 
             xytext=(graphite_x_pos * dx + 0.0005, 0.1* Ly),
             arrowprops=dict(facecolor='black',width=2),
             fontsize=20, color='red')

plt.legend()
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
plt.tight_layout()
plt.savefig('final_2D.png', dpi=300)
#plt.show()



plt.figure(figsize=(8, 6))
plt.plot(np.linspace(0, Ly, len(q_data)), q_data / 1e6, label='Heat flux', color='red', marker='o')
plt.xlabel('y (m)', fontsize=16)
plt.ylabel('q$_{div}$ (MW/m²)',fontsize=16)
plt.grid()
plt.legend()
plt.title('UEDGE Heat Flux on LM surface')
plt.tight_layout()
plt.savefig('heat_flux.png', dpi=300)
#plt.show()

plt.figure(figsize=(8, 6))
plt.plot(Y[:,0], T[0][:,1], label='Temperature on surface',color ='b',marker='o')
plt.ylabel('Surface temp (°C)',fontsize=16)
plt.xlabel('y (m)',fontsize=16)
plt.legend()
plt.grid(True)
plt.savefig('final_Tsurf.png', dpi=300)
#plt.show()

fig, ax1 = plt.subplots(figsize=(8, 6))

# Plot heat flux on primary y-axis
color = 'tab:red'
ax1.set_xlabel('y (m)', fontsize=16)
ax1.set_ylabel('Heat flux (MW/m²)', fontsize=16, color=color)
ax1.plot(Y, q_data / 1e6, color=color, marker='o', label='Heat flux')
ax1.tick_params(axis='y', labelcolor=color)
ax1.grid(True)
ax2 = ax1.twinx()  # instantiate a second axes that shares the same x-axis
color = 'tab:blue'
ax2.set_ylabel('Temperature (°C)', fontsize=16, color='blue')
ax2.plot(Y[:,0], T[0][:,1], color='blue', label='Temperature')
ax2.tick_params(axis='y', labelcolor='blue')

fig.tight_layout()  # adjust the layout
#ax1.legend(loc='upper left')
ax2.legend(loc='upper right')
plt.title('Heat Flux and Temperature on Surface')
plt.savefig('dual_axis_plot.png', dpi=300)
plt.show()


t_sim = np.multiply(T[1],dt)
np.savetxt('Tmax.txt', T[2])
np.savetxt('tsim.txt', t_sim)
np.savetxt('final.npy', T[0])
np.savetxt('q_surface', T[3])

# T, no_itera, temp_surf, q_x, q_y

plt.figure(figsize=(6, 4))
plt.plot(np.multiply(T[1],dt), T[2], color='red', marker='o')
plt.ylabel('T$_{surf}^{max}$ (°C)', fontsize=16)
plt.xlabel('t$_{simulation}$ (s)',fontsize=16)
plt.grid()
#plt.legend()
plt.ylim([0,800])
#plt.title('U on LM surface')
plt.tight_layout()
plt.savefig('tsurf_max.png', dpi=300)
#plt.show() 
 

plt.figure(figsize=(6, 4))
color = 'tab:red'
plt.plot(Y, q_data / 1e6, color=color, marker='o', label='Heat flux')
plt.ylim([0, 5])
plt.grid()
plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize =16)
plt.ylabel('Heat flux (MW/m²)', fontsize=16)
plt.tight_layout()  # adjust the layout
#plt.title('Heat Flux and Temperature on Surface')
plt.savefig('heat.png', dpi=300)
#plt.show()

plt.figure(figsize=(5,3))
plt.plot(np.multiply(T[1], dt), T[2], color='red')
plt.ylabel('T$_{surf}^{max}$ (°C)', fontsize=16)
plt.xlabel('t$_{simulation}$ (s)', fontsize=16)
plt.grid() 
plt.tick_params(axis='both', labelsize=16)
plt.ylim([0, 900])
plt.xlim([0, 5])
plt.tight_layout()
plt.savefig('tsurf_max.eps', format='eps', dpi=300)
plt.show()

plt.figure(figsize=(5, 3))
color = 'tab:red'
plt.plot(Y, q_data / 1e6, color=color, marker='o', label='Heat flux')
plt.ylim([0, 10])
plt.xlim([0, 0.25])
plt.grid()
plt.tick_params(axis='both', labelsize=16)
plt.xlabel('y (m)', fontsize=16)
plt.ylabel('Heat flux (MW/m²)', fontsize=16)
plt.tight_layout()  # Adjust the layout
plt.savefig('heat.eps', format='eps', dpi=300)
plt.show()





plt.figure(figsize=(5, 3), constrained_layout=True)
color = 'tab:red'
plt.plot(Y, q_data / 1e6, color=color, marker='o', label='Heat flux')  # convert to MW/m²
plt.ylim([0, 10])
plt.xlim([0, 0.25])
plt.grid()
plt.tick_params(axis='both', labelsize=16)
plt.xlabel('y (m)', fontsize=16)
plt.ylabel('Heat flux (MW/m²)', fontsize=16)
# Optional: show legend if desired
# plt.legend(fontsize=14, loc='upper right')
plt.savefig('heat.eps', format='eps', dpi=300, bbox_inches='tight')
plt.show()




fig = plt.figure(figsize=(8, 4))
gs = gridspec.GridSpec(1, 2, width_ratios=[1, 2], wspace=0.05)


ax0 = plt.subplot(gs[0])
y_vals = np.linspace(0, Ly, len(q_data))
ax0.plot(q_data / 1e6, y_vals, color='red', marker='o', label='Heat flux')
ax0.set_xlabel('q$_{\\perp}$ (MW/m²)', fontsize=18)
ax0.set_ylabel('y (m)', fontsize=18)
ax0.set_title('(a) q$_\\perp$', fontsize=18)
ax0.tick_params(labelsize=14)
ax0.grid(True, linestyle='-', linewidth=0.5)  # Major grid lines
#ax0.legend(fontsize=14)

# Add minor grid
ax0.minorticks_on()  # Enable minor ticks
ax0.grid(which='minor', linestyle=':', linewidth=0.5, color='gray')  # Minor grid lines
ax0.set_xlim([0, 9])  # Example xlim, adjust based on your data
ax0.set_ylim([0, Ly])  # Example ylim, adjust based on your data
ax0.set_xlim([10, 0])  # Flip x-axis
ax0.set_ylim([Ly, 0])

# --- Right: 2D Temperature Contour Plot ---
ax1 = plt.subplot(gs[1], sharey=ax0)
cf = ax1.contourf(X, Y, T[0], cmap='plasma')
cbar = plt.colorbar(cf, ax=ax1)
cbar.set_label('Temperature (°C)', fontsize=16)
cbar.ax.tick_params(labelsize=14)

ax1.set_xlabel('x (m)', fontsize=18)
ax1.set_title('(b) Temperature Distribution', fontsize=18)
ax1.axvline(x=graphite_x_pos * dx, color='g', linestyle='--', label='Graphite Position')
ax1.annotate('Graphite Region',
             xy=(graphite_x_pos * dx, 0.002), 
             xytext=(graphite_x_pos * dx + 0.0005, 0.1 * Ly),
             arrowprops=dict(facecolor='black', width=2),
             fontsize=16, color='red')
ax1.annotate('Li',
             xy=(graphite_x_pos * dx, 0.002), 
             xytext=(0.002, 0.1 * Ly),
             fontsize=16, color='white')
ax1.tick_params(labelsize=14)
ax1.legend(fontsize=14)

# Set the x and y limits
ax1.set_xlim([0, Lx])  # Adjust based on your x data range
ax1.set_ylim([0, Ly])  # Use the same y-limits as the left plot (or adjust accordingly)

# Remove redundant y-axis ticks on right plot
plt.setp(ax1.get_yticklabels(), visible=False)
plt.subplots_adjust(bottom=0.15, right=0.95)  

plt.tight_layout()
plt.savefig('combined_heatflux_temp_highres.png', dpi=300)
plt.show()
