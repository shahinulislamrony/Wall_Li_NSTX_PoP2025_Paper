# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 13:38:01 2025

@author: islam9
"""

import numpy as np
import matplotlib.pyplot as plt
import os



# Define file paths for data
base_dir = r'C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX_PoP_data\revised_code_reviweres\standalone_heat\Heat_code_new_with_all_corrections_reviwers_POP'
base_dir_latent = r'C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX_PoP_data\revised_code_reviweres\standalone_heat\Heat_code_new_with_all_corrections_reviwers_POP_WO_evap_latent_only'
base_dir_no_cool = r'C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX_PoP_data\revised_code_reviweres\standalone_heat\Heat_code_new_with_all_corrections_reviwers_POP_WO_cool'


# Load data
time = np.loadtxt(f'{base_dir}\\tsim.txt')
tmax_with_cool = np.loadtxt(f'{base_dir}\\Tmax.txt')
tmax_latent_only = np.loadtxt(f'{base_dir_latent}\\Tmax.txt')
tmax_no_cool = np.loadtxt(f'{base_dir_no_cool}\\Tmax.txt')

colors = {'no_cool': 'red', 'latent_only': 'green', 'with_cool': 'blue'}
linestyles = {'no_cool': '-', 'latent_only': ':', 'with_cool': '--'}
labels = {'no_cool': 'No-cooling', 'latent_only': 'Latent cooling only', 'with_cool': 'With cooling'}

def plot_max_surface_temperature(y_limits=None, save_path=None):
    plt.figure(figsize=(5, 3))
    plt.plot(time, tmax_no_cool, color=colors['no_cool'], linestyle=linestyles['no_cool'], label=labels['no_cool'])
    plt.plot(time, tmax_latent_only, color=colors['latent_only'], linestyle=linestyles['latent_only'], label=labels['latent_only'])
    plt.plot(time, tmax_with_cool, color=colors['with_cool'], linestyle=linestyles['with_cool'], label=labels['with_cool'])

    plt.xlabel('Simulation time (s)', fontsize=16)
    plt.ylabel('Maximum surface temperature (°C)', fontsize=16)
    plt.xlim([0, 5])
    if y_limits:
        plt.ylim(y_limits)
    else:
        plt.ylim([0, np.max(tmax_no_cool) * 1.1])
    plt.grid(True, which='both', linestyle=':', linewidth=0.7, alpha=0.7)
    plt.legend(fontsize=14)
    plt.tick_params(axis='both', labelsize=16)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, format='eps', dpi=1000)
    plt.show()

# 1. Basic plot
plot_max_surface_temperature()

# 2. Plot and save to file (with automatic y-limit)
plot_max_surface_temperature(save_path="max_surface_temperature.eps")

# 3. Plot with fixed y-limit (0 to 3000 °C), minor ticks and minor grid, and save
plt.figure(figsize=(5, 3))
plt.plot(time, tmax_no_cool, color=colors['no_cool'], linestyle=linestyles['no_cool'], label=labels['no_cool'])
#plt.plot(time, tmax_latent_only, color=colors['latent_only'], linestyle=linestyles['latent_only'], label=labels['latent_only'])
plt.plot(time, tmax_with_cool, color=colors['with_cool'], linestyle=linestyles['with_cool'], label=labels['with_cool'])

plt.xlabel('t$_{simulation}$ (s)', fontsize=18)
plt.ylabel('T$_{surf}^{max}$ (°C)', fontsize=18)
plt.xlim([0, 5])
plt.ylim([0, np.max(tmax_no_cool) * 1.1])

plt.minorticks_on()
plt.grid(which='major', linestyle='-', linewidth=0.75, alpha=0.8)
plt.grid(which='minor', linestyle=':', linewidth=0.5, alpha=0.6)

plt.legend(fontsize=14)
plt.tick_params(axis='both', labelsize=16)
plt.tight_layout()
plt.savefig("max_surface_temperature.eps", format='eps', dpi=1000)
plt.show()


molar_mass_lithium = 6.94  # g/mol for lithium
avogadro_number = 6.022e23  # atoms/mol

def lithium_atoms_per_second(mass_in_grams):
    moles_of_lithium = mass_in_grams / molar_mass_lithium
    total_atoms = moles_of_lithium * avogadro_number
    return total_atoms

m = lithium_atoms_per_second(2.14588)

x_data = np.array([-0.04731155, -0.04339678, -0.03580569, -0.0287926, -0.02241815, -0.01662467,
                    -0.01138454, -0.00667084, -0.00222074, 0.00074189, 0.00253791, 0.00484185,
                    0.00742937, 0.01039286, 0.0138512, 0.01783639, 0.02244914, 0.02780647,
                    0.03406285, 0.04135004, 0.04984127, 0.05964307, 0.07102367, 0.08421488,
                    0.09925538, 0.10724673])

###UEDGE q_perp 

q_data = np.array([
8.963790178736437520e+04,
8.495417639777387376e+04,
9.795719260932736506e+04,
1.159307861460527056e+05,
1.462868563955024874e+05,
1.974494761850824871e+05,
2.825961952962661162e+05,
4.224297666059850017e+05,
6.842671989677292295e+05,
9.993209280429951614e+05,
1.292507805776685709e+06,
1.941460892719849478e+06,
3.305475453626486007e+06,
4.142821811106371228e+06,
4.637000560050533153e+06,
4.406395729989341460e+06,
3.978698582463714294e+06,
3.509864202485042624e+06,
3.010893786305317655e+06,
2.514970880345709156e+06,
2.040909458293804899e+06,
1.621647626254735049e+06,
1.256815927057218505e+06,
8.875217568775143009e+05,
3.997192974923982401e+05,
1.749214676767415367e+05,

])

plt.figure(figsize=(3, 2))
plt.plot(x_data, q_data/1e6, color='red', linestyle = '-', label = 'T= 25C')
plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize=16)
plt.ylabel('q$_{\perp}$ (MW/m$^2$)',fontsize=16)
plt.xlim([-0.05, 0.15])
plt.grid()
#plt.legend(fontsize =16)
plt.ylim([0, 6])
#plt.title('Peak T$_{surf}$ becomes saturated \n over time due to evaporative cooling')
plt.tight_layout()
plt.savefig('heat_flux.png', dpi=300)
plt.show() 