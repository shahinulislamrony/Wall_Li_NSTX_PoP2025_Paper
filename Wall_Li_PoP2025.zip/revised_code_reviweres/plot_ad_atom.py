import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
from cycler import cycler


sxnp = np.array([1.65294727e-08, 1.68072047e-02, 1.57913285e-02, 1.47307496e-02,
       1.37802350e-02, 1.28710288e-02, 1.19247238e-02, 1.09516290e-02,
       1.02117906e-02, 2.14465429e-02, 1.11099457e-02, 1.26587791e-02,
       1.45917191e-02, 1.66915905e-02, 1.94826593e-02, 2.23582531e-02,
       2.53806793e-02, 2.94667140e-02, 3.39163144e-02, 3.85707117e-02,
       4.34572856e-02, 4.70735328e-02, 5.17684150e-02, 5.64336990e-02,
       5.97825750e-02, 6.08629236e-08])

    
def eval_Li_evap_at_T_Cel(temperature):
    """Calculate lithium evaporation flux at a given temperature in Celsius."""
    a1 = 5.055
    b1 = -8023.0
    xm1 = 6.939
    tempK = temperature + 273.15

    if tempK <= 0:
        raise ValueError("Temperature must be above absolute zero (-273.15°C).")

    vpres1 = 760 * 10 ** (a1 + b1 / tempK)  # Vapor pressure
    sqrt_argument = xm1 * tempK

    if sqrt_argument <= 0:
        raise ValueError("Invalid value for sqrt: xm1 * tempK has non-positive values.")

    fluxEvap = 1e4 * 3.513e22 * vpres1 / np.sqrt(sqrt_argument)  # Evaporation flux
    return fluxEvap


def count_files_in_folder(folder_path):
    """Count the number of files in a folder."""
    return len([file for file in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, file))])


folders = {
    #"nx_P1": r"C:\UEDGE_run_Shahinul\NSTX_PoP\PePi2.0MW\C_Li_omp",
    "nx_P1": r"C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX_PoP_data\PePi2.0MW_Yad2.7/C_Li_omp",
    "nx_P2": r"C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX_PoP_data\NSTX_PoP\PePi2.0MW/C_Li_omp",

   }


file_counts = {key: count_files_in_folder(path) for key, path in folders.items()}


nx_P1, nx_P2= file_counts.values()


datasets = [
   # {'path': r'C:\UEDGE_run_Shahinul\NSTX_PoP\PePi1.5MW',  'nx': nx_P1, 'dt': 10e-3, 'label_tsurf': 'P:1.5'},
   # {'path': r'C:\UEDGE_run_Shahinul\NSTX_PoP\PePi2.0MW', 'nx': nx_P1, 'dt': 5e-3, 'label_tsurf': 'dt:2ms'},
   {'path': r'C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX_PoP_data\PePi2.0MW_Yad2.7', 'nx': nx_P1, 'dt': 5e-3, 'label_tsurf': 'Yad~2.7'},
   {'path': r'C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX_PoP_data\NSTX_PoP\PePi2.0MW',  'nx': nx_P2, 'dt': 5e-3, 'label_tsurf': 'Yad~1e-3'},

   
]

nx = 1001
def process_dataset(data_path, nx, dt, sep=8, ixmp=36):
    
    max_value_tsurf, max_q, evap_flux_max, max_q_Li_list = [], [], [], []
    C_Li_omp, Te, n_Li3, ne, phi_sput, evap, ad, total  = [], [], [], [], [], [], [], []

    dirs = {
        "q_perp": os.path.join(data_path, 'q_perp'),
        "Tsurf_Li": os.path.join(data_path, 'Tsurf_Li'),
        "q_Li_surface": os.path.join(data_path, 'q_Li_surface'),
        "C_Li_omp": os.path.join(data_path, 'C_Li_omp'),
        "n_Li3": os.path.join(data_path, 'n_Li3'),
        "n_Li2": os.path.join(data_path, 'n_Li2'),
        "n_Li1": os.path.join(data_path, 'n_Li1'),
        "n_e": os.path.join(data_path, 'n_e'),
        "T_e": os.path.join(data_path, 'T_e'),
        "Li": os.path.join(data_path, 'Gamma_Li'),
    }

    for i in range(1, nx):
        filenames = {
            "tsurf": os.path.join(dirs["Tsurf_Li"], f'T_surfit_{i}.0.csv'),
            "qsurf": os.path.join(dirs["q_perp"], f'q_perpit_{i}.0.csv'),
            "qsurf_Li": os.path.join(dirs["q_Li_surface"], f'q_Li_surface_{i}.0.csv'),
            "C_Li": os.path.join(dirs["C_Li_omp"], f'CLi_prof{i}.0.csv'),
            "n_Li3": os.path.join(dirs["n_Li3"], f'n_Li3_{i}.0.csv'),
            "n_Li2": os.path.join(dirs["n_Li2"], f'n_Li2_{i}.0.csv'),
            "n_Li1": os.path.join(dirs["n_Li1"], f'n_Li1_{i}.0.csv'),
            "ne": os.path.join(dirs["n_e"], f'n_e_{i}.0.csv.npy'),
            "Te": os.path.join(dirs["T_e"], f'T_e_{i}.0.csv'),
            "PS": os.path.join(dirs["Li"], f'PhysSput_flux_{i}.0.csv'),
            "Evap": os.path.join(dirs["Li"], f'Evap_flux_{i}.0.csv'),
            "Ad": os.path.join(dirs["Li"], f'Adstom_flux_{i}.0.csv'),
            "Total": os.path.join(dirs["Li"], f'Total_Li_flux_{i}.0.csv')
        }

        max_tsurf, max_q_i, evap_flux, max_q_Li_i, C_Li_i, Te_i, n_Li3_i, ne_i, phi_sput_i, evap_i, ad_i, total_i = [np.nan] * 12

        try:
            max_tsurf = np.max(pd.read_csv(filenames["tsurf"]).values)
            max_q_i = np.max(pd.read_csv(filenames["qsurf"]).values)
            max_q_Li_i = np.max(pd.read_csv(filenames["qsurf_Li"]).values)
            C_Li_i = pd.read_csv(filenames["C_Li"]).values[sep]
            Te_i = np.loadtxt(filenames["Te"])[ixmp, sep]
            n_Li3_i = np.loadtxt(filenames["n_Li3"])[ixmp, sep]
            n_Li2_i = np.loadtxt(filenames["n_Li2"])[ixmp, sep]
            n_Li1_i = np.loadtxt(filenames["n_Li1"])[ixmp, sep]
            ne_i = np.load(filenames["ne"])[ixmp, sep]
            phi_sput_i = np.sum(np.loadtxt(filenames["PS"])*sxnp)
            evap_i = np.sum(np.loadtxt(filenames["Evap"])*sxnp)
            ad_i = np.sum(np.loadtxt(filenames["Ad"])*sxnp)
            total_i = np.sum(np.loadtxt(filenames["Total"])*sxnp)
            
        except FileNotFoundError as e:
            print(f"File not found: {e}")

    
        max_value_tsurf.append(max_tsurf)
        max_q.append(max_q_i)
        max_q_Li_list.append(max_q_Li_i)
        C_Li_omp.append(C_Li_i)
        Te.append(Te_i)
        n_Li3.append(n_Li3_i + n_Li2_i + n_Li1_i)
        ne.append(ne_i)
        phi_sput.append(phi_sput_i)
        evap.append(evap_i)
        ad.append(ad_i)
        total.append(total_i)
        

    def replace_with_linear_interpolation(arr):
        arr = pd.Series(arr)
        arr_interpolated = arr.interpolate(method='linear', limit_direction='both')
        return arr_interpolated.fillna(method='bfill').fillna(method='ffill').to_numpy()

    max_value_tsurf = replace_with_linear_interpolation(max_value_tsurf)
    max_q = replace_with_linear_interpolation(max_q)
    max_q_Li_list = replace_with_linear_interpolation(max_q_Li_list)
    C_Li_omp = replace_with_linear_interpolation(C_Li_omp)
    n_Li3 = replace_with_linear_interpolation(n_Li3)
    Te = replace_with_linear_interpolation(Te)
    ne = replace_with_linear_interpolation(ne)
    phi_sput = replace_with_linear_interpolation(phi_sput)
    evap = replace_with_linear_interpolation(evap)
    ad = replace_with_linear_interpolation(ad)
    total = replace_with_linear_interpolation(total)

   
    evap_flux_max = []
    for max_tsurf in max_value_tsurf:
        if not np.isnan(max_tsurf):
            try:
                evap_flux = eval_Li_evap_at_T_Cel(max_tsurf)
            except Exception as e:
                print(f"Error calculating evaporation flux: {e}")
                evap_flux = np.nan
        else:
            evap_flux = np.nan
        evap_flux_max.append(evap_flux)

    evap_flux_max = replace_with_linear_interpolation(evap_flux_max)

   
    q_surface = np.array(max_q) - 2.26e-19 * np.array(evap_flux_max)

   
    time_axis = dt * np.arange(1, len(max_q) + 1)

    return max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li_list, C_Li_omp, n_Li3, Te, ne, phi_sput, evap, ad, total

xl = 5

fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(8, 8), sharex=True)
colors = ['r', 'g', 'b', 'r', 'g', 'b', 'c', 'purple']

for idx, dataset in enumerate(datasets):
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )
    ax1.plot(time_axis, np.array(max_q_Li) / 1e6, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])
    ax2.plot(time_axis, max_value_tsurf, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])
    ax3.plot(time_axis, C_Li_omp * 100, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])

ax1.set_ylabel('q$_{s}^{max}$ (MW/m$^2$)', fontsize=18)
ax1.set_xlim([0, xl])
ax1.set_ylim([0, 10])
ax1.legend(loc='best', fontsize=12, ncol=2)
ax1.grid(True)
ax1.tick_params(axis='both', labelsize=14)

ax2.set_ylabel("T$_{surf}^{max}$ ($^\circ$C)", fontsize=18)
ax2.set_ylim([0, 700])
ax2.set_xlim([0, xl])
ax2.grid(True)
ax2.tick_params(axis='both', labelsize=14)

ax3.set_ylabel("C$_{Li-sep}^{omp}$ (%)", fontsize=18)
ax3.set_ylim([0, 10])
ax3.set_xlim([0, xl])
ax3.set_xlabel('t$_{sim}$ (s)', fontsize=18)
ax3.grid(True)
ax3.tick_params(axis='both', labelsize=14)

plt.tight_layout()
plt.savefig('qsurf_T_surf_CLi_omp.png', dpi=300)
plt.show()



fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(8, 8), sharex=True)
colors = ['r', 'g', 'b', 'c', 'm', 'y', 'k', 'purple']

# Initialize a dictionary to store the end time of each phase
end_times = {}

for idx, dataset in enumerate(datasets):
    # Ensure `process_dataset` is defined or imported
    results = process_dataset(dataset['path'], dataset['nx'], dataset['dt'])
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = results
    
    # Adjust time axis for second-phase runs
    if "_Ph2" in dataset['label_tsurf']:
        # Get the corresponding first-phase dataset label
        first_phase_label = dataset['label_tsurf'].replace("_Ph2", "")
        if first_phase_label in end_times:
            time_axis = time_axis + end_times[first_phase_label]  # Append time axis to continue from the first phase
    
    # Update the end time for the current dataset
    end_times[dataset['label_tsurf']] = time_axis[-1]  # Store the last time of the current dataset
    
    # Plot the data
    ax1.plot(time_axis, np.array(max_q_Li) / 1e6, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx % len(colors)])
    ax2.plot(time_axis, max_value_tsurf, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx % len(colors)])
    ax3.plot(time_axis, C_Li_omp * 100, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx % len(colors)])

ax1.set_ylabel('q$_{s}^{max}$ (MW/m$^2$)', fontsize=18)
ax1.set_xlim([0, time_axis[-1]])  # Adjust x-axis limit based on the full simulation time
ax1.set_ylim([0, 10])
ax1.legend(loc='best', fontsize=12, ncol=2)
ax1.grid(True)
ax1.tick_params(axis='both', labelsize=14)

ax2.set_ylabel("T$_{surf}^{max}$ ($^\circ$C)", fontsize=18)
ax2.set_ylim([0, 700])
ax2.set_xlim([0, time_axis[-1]])  # Adjust x-axis limit based on the full simulation time
ax2.grid(True)
ax2.tick_params(axis='both', labelsize=14)

ax3.set_ylabel("C$_{Li-sep}^{omp}$ (%)", fontsize=18)
ax3.set_ylim([0, 5])  # Adjusted upper limit
ax3.set_xlim([0, time_axis[-1]])  # Adjust x-axis limit based on the full simulation time
ax3.set_xlabel('t$_{sim}$ (s)', fontsize=18)
ax3.grid(True)
ax3.tick_params(axis='both', labelsize=14)

plt.tight_layout()
plt.savefig('qsurf_T_surf_CLi_omp.png', dpi=300)
plt.show()

x1 = 5

fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(4, 7), sharex=True)
colors = ['r', 'g', 'b', 'k', 'm', 'y', 'c', 'purple']

for idx, dataset in enumerate(datasets):
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )
    ax1.plot(time_axis, max_value_tsurf, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])
    ax2.plot(time_axis, total / 1e20, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])
    ax3.plot(time_axis, nLi3 / 1e16, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])

# Titles and axis labels for each subplot
ax1.set_ylabel("T$_{surf}^{max}$ ($^\circ$C)", fontsize=18)
ax1.set_ylim([0, 800])
ax1.set_xlim([0, xl])
ax1.grid(True)
ax1.legend(loc='best', fontsize=12)
ax1.tick_params(axis='both', labelsize=14)
ax1.text(0.02, 0.95, '(a)', transform=ax1.transAxes, fontsize=18, va='top', ha='left')

ax2.set_ylabel("$\phi_{Li}$ (10$^{20}$ atom/s)", fontsize=18)
ax2.set_ylim([0, 20])
ax2.set_xlim([0, xl])
ax2.grid(True)
ax2.tick_params(axis='both', labelsize=14)
ax2.text(0.02, 0.95, '(b)', transform=ax2.transAxes, fontsize=18, va='top', ha='left')

ax3.set_ylabel("n$_{Li}^{omp}$ (10$^{16}$ m$^{-3}$)", fontsize=18)
ax3.set_ylim([0, 1])
ax3.set_xlim([0, xl])
ax3.set_xlabel('t$_{simulation}$ (s)', fontsize=18)
ax3.grid(True)
ax3.tick_params(axis='both', labelsize=14)
ax3.text(0.02, 0.2, '(c)', transform=ax3.transAxes, fontsize=18, va='top', ha='left')

# Adjust layout and save the figure
plt.tight_layout()
plt.savefig('T_surf_nLi_omp_Phi.png', dpi=300)
plt.show()


fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(4, 7), sharex=True)
colors = ['r', 'g', 'b', 'r', 'g', 'b', 'c', 'purple']




fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(4, 7), sharex=True)
colors = ['r', 'g', 'b', 'k', 'm', 'y', 'c', 'purple']

for idx, dataset in enumerate(datasets):
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )
    ax1.plot(time_axis, max_value_tsurf, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])
    ax2.plot(time_axis, total / 1e20, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])
    ax3.plot(time_axis, nLi3 / 1e16, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])

# Set logarithmic y-scale for all subplots
ax1.set_yscale('log')
ax2.set_yscale('log')
ax3.set_yscale('log')

# Titles and axis labels for each subplot
ax1.set_ylabel("T$_{surf}^{max}$ ($^\circ$C)", fontsize=18)
ax1.set_ylim([10, 600])  # log scale can't use 0
ax1.set_xlim([0, xl])
ax1.grid(True, which='both')
ax1.legend(loc='best', fontsize=12)
ax1.tick_params(axis='both', labelsize=14)
ax1.text(0.02, 0.95, '(a)', transform=ax1.transAxes, fontsize=18, va='top', ha='left')

ax2.set_ylabel("$\phi_{Li}$ (10$^{20}$ atom/s)", fontsize=18)
ax2.set_ylim([1e-5, 10])  # Adjusted for log scale
ax2.set_xlim([0, xl])
ax2.grid(True, which='both')
ax2.tick_params(axis='both', labelsize=14)
ax2.text(0.02, 0.95, '(b)', transform=ax2.transAxes, fontsize=18, va='top', ha='left')

ax3.set_ylabel("n$_{Li}^{omp}$ (10$^{16}$ m$^{-3}$)", fontsize=18)
ax3.set_ylim([1, 10])  # Adjusted for log scale
ax3.set_xlim([0, xl])
ax3.set_xlabel('t$_{simulation}$ (s)', fontsize=18)
ax3.grid(True, which='both')
ax3.tick_params(axis='both', labelsize=14)
ax3.text(0.02, 0.2, '(c)', transform=ax3.transAxes, fontsize=18, va='top', ha='left')

# Adjust layout and save the figure
plt.tight_layout()
plt.savefig('T_surf_nLi_omp_Phi_log.png', dpi=300)
plt.show()


fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(5, 5), dpi=300, sharex=True)

for idx, dataset in enumerate(datasets):
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )
    
    ax1.plot(time_axis, np.array(max_q_Li) / 1e6, linestyle='-', linewidth=1.5,
             label=f'{dataset["label_tsurf"]}', color=colors[idx])
    
    ax2.plot(time_axis, max_value_tsurf, linestyle='-', linewidth=1.5,
             label=f'{dataset["label_tsurf"]}', color=colors[idx])

# Axis labels and limits
ax1.set_ylabel('q$_{s}^{max}$ (MW/m$^2$)', fontsize=14)
ax1.set_xlim([0, xl])
ax1.set_ylim([0, 10])
ax1.grid(True, which='both', linestyle='--', linewidth=0.5)
ax1.tick_params(axis='both', labelsize=12)

ax2.set_ylabel("T$_{surf}^{max}$ ($^\circ$C)", fontsize=14)
ax2.set_xlabel('t$_{sim}$ (s)', fontsize=14)
ax2.set_ylim([0, 500])
ax2.set_xlim([0, xl])
ax2.legend(loc='best', fontsize=12, ncol=2)
ax2.grid(True, which='both', linestyle='--', linewidth=0.5)
ax2.tick_params(axis='both', labelsize=12)
plt.tight_layout()
plt.savefig('qsurf_T_surf.pdf', format='pdf', bbox_inches='tight')   # preferred for publication
plt.savefig('qsurf_T_surf.png', dpi=600, bbox_inches='tight')        # high-res image
plt.savefig('qsurf_T_surfdt.eps', format='eps', bbox_inches='tight')   # optional legacy vector
plt.show()





line_styles = ['-', '--', '-.', ':', (0, (3, 1, 1, 1)), (0, (5, 5))]
markers = ['o', 's', '^', 'D', 'x', 'o']  # Only needed for last two
colors = ['r', 'g', 'b', 'k', 'm', 'c', 'y', 'purple']


fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(4, 4), dpi=300, sharex=True)


num_datasets = len(datasets)

for idx, dataset in enumerate(datasets):
    # Unpack the dataset variables (your actual function here)
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )

    style = line_styles[idx % len(line_styles)]
    color = colors[idx % len(colors)]
    label = dataset["label_tsurf"]

    # Use markers only for the last two datasets
    if idx >= num_datasets - 1:
        marker = markers[idx % len(markers)]
        markersettings = {'marker': marker, 'markevery': 10, 'markersize': 6}
    else:
        markersettings = {}

    # --- q_surf plot ---
    ax1.plot(time_axis, np.array(max_q_Li) / 1e6,
             linestyle=style, linewidth=1.5,
             color=color, label=label, **markersettings)

    # --- T_surf plot ---
    ax2.plot(time_axis, max_value_tsurf,
             linestyle=style, linewidth=1.5,
             color=color, label=label, **markersettings)

# === Axis labels and limits ===
ax1.set_ylabel('q$_{s}^{max}$ (MW/m$^2$)', fontsize=14)
ax1.set_xlim([0, xl])
ax1.set_ylim([0, 10])
ax1.grid(True, which='both', linestyle='--', linewidth=0.5)
ax1.tick_params(axis='both', labelsize=12)

ax2.set_ylabel("T$_{surf}^{max}$ ($^\circ$C)", fontsize=14)
ax2.set_xlabel('t$_{simulation}$ (s)', fontsize=14)
ax2.set_xlim([0, xl])
ax2.set_ylim([0, 500])
ax2.grid(True, which='both', linestyle='--', linewidth=0.5)
ax2.tick_params(axis='both', labelsize=12)
ax2.legend(loc='best', fontsize=9, ncol=2)

# === Save and display ===
plt.tight_layout()
plt.savefig('qsurf_T_surf.pdf', format='pdf', bbox_inches='tight')
plt.savefig('qsurf_T_surf.png', dpi=600, bbox_inches='tight')
plt.savefig('qsurf_T_surfdt.eps', format='eps', bbox_inches='tight')
plt.show()


import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from numpy.linalg import norm

# --- Select the reference dataset (smallest dt assumed to be first) ---
ref_dataset = datasets[0]
ref_results = process_dataset(ref_dataset['path'], ref_dataset['nx'], ref_dataset['dt'])
_, _, _, _, ref_time, ref_q_Li, *_ = ref_results
ref_q = np.array(ref_q_Li)

# Prepare for plotting and error tracking
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(4, 4), dpi=300, sharex=True)
num_datasets = len(datasets)
errors = []

# --- Loop through datasets ---
for idx, dataset in enumerate(datasets):
    # Process the dataset
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )

    # Plotting style
    style = line_styles[idx % len(line_styles)]
    color = colors[idx % len(colors)]
    label = dataset["label_tsurf"]

    # Use markers only for last two datasets
    if idx >= num_datasets - 2:
        marker = markers[idx % len(markers)]
        markersettings = {'marker': marker, 'markevery': 10, 'markersize': 6}
    else:
        markersettings = {}

    # --- Plot q_surf ---
    ax1.plot(time_axis, np.array(max_q_Li) / 1e6,
             linestyle=style, linewidth=1.5,
             color=color, label=label, **markersettings)

    # --- Plot T_surf ---
    ax2.plot(time_axis, max_value_tsurf,
             linestyle=style, linewidth=1.5,
             color=color, label=label, **markersettings)

    # --- Error analysis (skip ref dataset) ---
    if idx != 0:
        q = np.array(max_q_Li)
        interp_func = interp1d(time_axis, q, kind='linear', bounds_error=False, fill_value="extrapolate")
        q_interp = interp_func(ref_time)
        l2_error = norm(q_interp - ref_q) / norm(ref_q)
        errors.append((dataset['dt'], l2_error))

# --- Finalize q_surf subplot ---
ax1.set_ylabel('q$_{s}^{max}$ (MW/m$^2$)', fontsize=14)
ax1.set_xlim([0, xl])
ax1.set_ylim([0, 10])
ax1.grid(True, which='both', linestyle='--', linewidth=0.5)
ax1.tick_params(axis='both', labelsize=12)

# --- Finalize T_surf subplot ---
ax2.set_ylabel("T$_{surf}^{max}$ ($^\circ$C)", fontsize=14)
ax2.set_xlabel('t$_{simulation}$ (s)', fontsize=14)
ax2.set_xlim([0, xl])
ax2.set_ylim([0, 500])
ax2.grid(True, which='both', linestyle='--', linewidth=0.5)
ax2.tick_params(axis='both', labelsize=12)
ax2.legend(loc='best', fontsize=9, ncol=2)

# --- Save figure ---
plt.tight_layout()
plt.savefig('qsurf_T_surf.pdf', format='pdf', bbox_inches='tight')
plt.savefig('qsurf_T_surf.png', dpi=600, bbox_inches='tight')
plt.savefig('qsurf_T_surfdt.eps', format='eps', bbox_inches='tight')
plt.show()

# === Error plot (L2 norm vs. time step) ===
if errors:
    dts, errs = zip(*errors)
    plt.figure(dpi=150)
    plt.loglog(dts, errs, 'o-', label='Relative L2 Error')
    plt.xlabel('Time step ?t (s)', fontsize=12)
    plt.ylabel('Error', fontsize=12)
    plt.grid(True, which='both', linestyle='--', linewidth=0.5)
    plt.title('Time Step Convergence', fontsize=14)
    plt.legend()
    plt.tight_layout()
    plt.savefig("convergence_plot.png", dpi=300)
    plt.show()

    # Print error values to console
    print("\n=== Time Step Error Analysis ===")
    for dt, err in errors:
        print(f"dt = {dt:.1e} -> Relative L2 Error = {err:.3e}")


fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(8, 8), sharex=True)
colors = ['r', 'g', 'b', 'k', 'm', 'y', 'c', 'purple']

for idx, dataset in enumerate(datasets):
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )
    ax1.plot(time_axis, max_value_tsurf, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])
    ax2.plot(time_axis, np.array(max_q) / 1e6, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])
    ax3.plot(time_axis, np.array(max_q_Li) / 1e6, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])

ax1.set_ylabel("T$_{surf}^{max}$ ($^\circ$C)", fontsize=18)
ax1.set_ylim([0, 500])
ax1.set_xlim([0, xl])
ax1.grid(True)
ax1.tick_params(axis='both', labelsize=14)

ax2.set_ylabel('q$_{\perp}^{max}$ (MW/m$^2$)', fontsize=18)
ax2.set_xlim([0, xl])
ax2.set_ylim([0, 10])
ax2.legend(loc='best', fontsize=12, ncol=2)
ax2.grid(True)
ax2.tick_params(axis='both', labelsize=14)

ax3.set_ylabel('q$_{s}^{max}$ (MW/m$^2$)', fontsize=18)
ax3.set_xlim([0, xl])
ax3.set_ylim([0, 10])
ax3.legend(loc='best', fontsize=12, ncol=2)
ax3.grid(True)
ax3.tick_params(axis='both', labelsize=14)
ax3.set_xlabel('t$_{sim}$ (s)', fontsize=18)


plt.tight_layout()
plt.savefig('qsurf_T_surf_qperp.png', dpi=300)
plt.show()





fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(8, 8), sharex=True)
colors = ['r', 'g', 'b', 'k', 'm', 'y', 'c', 'purple']

for idx, dataset in enumerate(datasets):
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )
    ax1.plot(time_axis, np.array(max_q_Li) / 1e6, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])
    ax2.plot(time_axis, max_value_tsurf, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])
    ax3.plot(time_axis, nLi3, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])

ax1.set_ylabel('q$_{s}^{max}$ (MW/m$^2$)', fontsize=18)
ax1.set_xlim([0, xl])
ax1.set_ylim([0, 10])
ax1.legend(loc='best', fontsize=12, ncol=2)
ax1.grid(True)
ax1.tick_params(axis='both', labelsize=14)

ax2.set_ylabel("T$_{surf}^{max}$ ($^\circ$C)", fontsize=18)
ax2.set_ylim([0, 500])
ax2.set_xlim([0, xl])
ax2.grid(True)
ax2.tick_params(axis='both', labelsize=14)

ax3.set_ylabel("n$_{Li-sep}^{omp}$ (m$^{-3}$)", fontsize=18)
ax3.set_ylim([0, 1e17])
ax3.set_xlim([0, xl])
ax3.set_xlabel('t$_{sim}$ (s)', fontsize=18)
ax3.grid(True)
ax3.tick_params(axis='both', labelsize=14)

plt.tight_layout()
plt.savefig('qsurf_T_surf_nLi_omp.png', dpi=300)
plt.show()


fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(8, 8), sharex=True)
colors = ['r', 'g', 'b', 'k', 'm', 'y', 'c', 'purple']

for idx, dataset in enumerate(datasets):
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )
    ax1.plot(time_axis, phi_sput/1e22, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])
    ax2.plot(time_axis, evap/1e23, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])
    ax3.plot(time_axis, ad/1e20, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])

ax1.set_ylabel('$\phi_{PS}$ (10$^{22}$ atom/s)', fontsize=16)
ax1.set_xlim([0, xl])
ax1.set_ylim([0, 0.3])
#ax1.legend(loc='best', fontsize=12, ncol=2)
ax1.grid(True)
ax1.tick_params(axis='both', labelsize=14)

ax2.set_ylabel("$\phi_{Ev}$ (10$^{23}$ atom/s)", fontsize=16)
ax2.set_ylim([0, 0.5])
#ax2.legend(loc='best', fontsize=12, ncol=2)
ax2.set_xlim([0, xl])
ax2.grid(True)
ax2.tick_params(axis='both', labelsize=14)

ax3.set_ylabel("$\phi_{ad}$ (10$^{20}$ atom/s)", fontsize=16)
ax3.set_ylim([0, 0.3])
ax3.set_xlim([0, xl])
ax3.set_xlabel('t$_{sim}$ (s)', fontsize=18)
ax3.grid(True)
ax3.tick_params(axis='both', labelsize=14)

plt.tight_layout()
plt.savefig('Phi_Li.png', dpi=300)
plt.savefig('Phi_Li.eps', format='eps', bbox_inches='tight')  
plt.show()



for idx, dataset in enumerate(datasets):
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )
    plt.plot(max_value_tsurf, C_Li_omp * 100, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}',  color=colors[idx])

plt.xlabel("T$_{surf}^{max}$ ($^\circ$C)", fontsize=18)
plt.ylabel("C$_{Li-sep}^{omp}$ (%)", fontsize=18)
plt.legend(fontsize=14)
plt.axhline(3, color='black', linestyle=':', linewidth=2, label='y = 3') 
plt.ylim([0, 1])
plt.xlim([0, 500])

plt.grid(True)
plt.tick_params(axis='both', labelsize=14)
plt.tight_layout()
plt.savefig('T_surf_CLi_omp.png', dpi=300)
plt.show()


for idx, dataset in enumerate(datasets):
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )
    plt.plot(max_value_tsurf, nLi3, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}',  color=colors[idx])

plt.xlabel("T$_{surf}^{max}$ ($^\circ$C)", fontsize=18)
plt.ylabel("n$_{Li-sep}^{omp}$ (m$^{-3}$)", fontsize=18)
plt.legend(fontsize=14)
plt.axhline(3, color='black', linestyle=':', linewidth=2, label='y = 3')  # Reference line at y=3
plt.ylim([0, 1e17])
plt.xlim([0, 500])

plt.grid(True)
plt.tick_params(axis='both', labelsize=14)
plt.tight_layout()
plt.savefig('T_surf_nLi_omp.png', dpi=300)
plt.show()


plt.figure(figsize=(4, 2.25))
colors = ['r', 'g', 'b', 'r', 'g', 'b', 'c', 'purple']
for idx, dataset in enumerate(datasets):
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )
    plt.plot(total/1e21, nLi3, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}',  color=colors[idx])

plt.xlabel("$\phi_{Li}$ ($10^{21}$atom/s)", fontsize=18)
plt.ylabel("n$_{Li-sep}^{omp}$ (m$^{-3}$)", fontsize=18)
plt.legend(fontsize=11)
plt.ylim([0, 10e17])
plt.xlim([0, 10])

plt.grid(True)
plt.tick_params(axis='both', labelsize=14)
plt.tight_layout()
plt.savefig('Cs_Phi_Li_nLi_omp.eps', format='eps', dpi=600)  # High-res EPS for publication
plt.savefig('Cs_Phi_Li_nLi_omp.jpg', format='jpg', dpi=600)  # High-res JPG
plt.savefig('Cs_Phi_Li_nLi_omp.png', format='png', dpi=300)  
plt.show()


plt.figure(figsize=(4, 3))

line_styles = ['-', '--', '-.', ':']

for idx, dataset in enumerate(datasets):
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )
    plt.plot(
        total / 1e21,
        nLi3/1e17,
        linestyle=line_styles[idx % len(line_styles)],
        linewidth=2,
        label=f'{dataset["label_tsurf"]}',
        color=colors[idx]
    )

plt.xlabel(r"$\phi_{Li}$ ($10^{21}$ atom/s)", fontsize=18)
plt.ylabel(r"$n_{Li-sep}^{omp}$ ($10^{17}$ m$^{-3}$)", fontsize=18)
plt.legend(fontsize=11, loc='lower right')  # Legend at bottom right
plt.ylim([0, 1])
plt.xlim([0, 1])

plt.grid(True)
plt.tick_params(axis='both', labelsize=14)
plt.tight_layout()

plt.savefig('Cs_Phi_Li_nLi_omp.eps', format='eps', dpi=600)
plt.savefig('Cs_Phi_Li_nLi_omp.jpg', format='jpg', dpi=600)
plt.savefig('Cs_Phi_Li_nLi_omp.png', format='png', dpi=300)

plt.show()


for idx, dataset in enumerate(datasets):
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )
    plt.plot(time_axis, total, linestyle='-', linewidth=2, label=f'{dataset["label_tsurf"]}',  color=colors[idx])

plt.xlabel("t$_{sim}$ (s)", fontsize=18)
plt.ylabel("$\phi_{Li}$ (atom/s)", fontsize=18)
plt.legend(fontsize=14)
plt.axhline(3, color='black', linestyle=':', linewidth=2, label='y = 3')  # Reference line at y=3
plt.ylim([0, 1e20])
plt.xlim([0, 1])
plt.grid(True)
plt.tick_params(axis='both', labelsize=14)
plt.tight_layout()
plt.savefig('tsim_Phi_Li_omp.png', dpi=300)
plt.show()



plt.figure(figsize=(4, 3))
colors = ['r', 'g', 'b', 'r', 'g', 'b', 'c', 'purple']

for idx, dataset in enumerate(datasets):
    # Process the dataset
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )
    
    # Plot the data with dashed line style
    if idx < 3:  # Add legend only for the first three datasets
        plt.plot(total / 1e21, nLi3/1e18, linestyle='--', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])
    else:  # No legend for the last three datasets
        plt.plot(total / 1e21, nLi3/1e18, linestyle='--', linewidth=2, color=colors[idx])

# Set axis labels and limits
plt.xlabel("$\phi_{Li}$ ($10^{21}$atom/s)", fontsize=18)
plt.ylabel("n$_{Li-sep}^{omp}$ (m$^{-3}$)", fontsize=18)

# Add legend only for the first three datasets
plt.legend(fontsize=11, loc='best')

# Set axis limits
plt.ylim([0, 0.5])
plt.xlim([0, 10])

# Add grid and adjust layout
plt.grid(True)
plt.tick_params(axis='both', labelsize=14)
plt.tight_layout()

# Save the figure in multiple formats
plt.savefig('Cs_Phi_Li_nLi_omp.eps', format='eps', dpi=600)  # High-res EPS for publication
plt.savefig('Cs_Phi_Li_nLi_omp.jpg', format='jpg', dpi=600)  # High-res JPG
plt.savefig('Cs_Phi_Li_nLi_omp.png', format='png', dpi=300)  # High-res PNG

# Show the plot
plt.show()




colors = ['r', 'g', 'b', 'r', 'g', 'b', 'c', 'purple']
time_offsets = [0, 0, 0]  # To track the end time of datasets 1-3
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(4, 4), sharex=True)

for idx, dataset in enumerate(datasets):
    # Process the dataset
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )
    
    # Determine the time offset for continuation
    if idx >= 3:  # For datasets 4-6, continue from the end of datasets 1-3
        time_axis = time_axis + time_offsets[idx - 3]
    else:  # For datasets 1-3, update the time offset
        time_offsets[idx] = time_axis[-1]
    
    # Plot Tsurf
    if idx < 3:  # Add labels only for datasets 1-3
        ax1.plot(time_axis, max_value_tsurf, linestyle='--', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])
    else:  # No label for datasets 4-6
        ax1.plot(time_axis, max_value_tsurf, linestyle='--', linewidth=2, color=colors[idx])

# Customize ax1
ax1.set_ylabel("T$_{surf}$ ($^\circ$C)", fontsize=16)
ax1.set_xlim([0, 1.5])
ax1.set_ylim([0, 700])
#ax1.set_yscale('log') 
ax1.legend(fontsize=11, loc='best')
ax1.grid(True)
ax1.tick_params(axis='both', labelsize=14)

for idx, dataset in enumerate(datasets):
    # Process the dataset
    max_value_tsurf, max_q, evap_flux_max, q_surface, time_axis, max_q_Li, C_Li_omp, nLi3, Te, ne, phi_sput, evap, ad, total = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )
    
    # Determine the time offset for continuation
    if idx >= 3:  # For datasets 4-6, continue from the end of datasets 1-3
        time_axis = time_axis + time_offsets[idx - 3]
    else:  # For datasets 1-3, update the time offset
        time_offsets[idx] = time_axis[-1]
    
    # Plot nLi3
    if idx < 3:  # Add labels only for datasets 1-3
        ax2.plot(time_axis, nLi3 / 1e17, linestyle='--', linewidth=2, label=f'{dataset["label_tsurf"]}', color=colors[idx])
    else:  # No label for datasets 4-6
        ax2.plot(time_axis, nLi3 / 1e17, linestyle='--', linewidth=2, color=colors[idx])

# Customize ax2
ax2.set_xlabel("t$_{simulation}$ (s)", fontsize=16)
ax2.set_ylabel("n$_{Li}^{omp}$ ($10^{17}$ m$^{-3}$)", fontsize=16)
ax2.set_ylim([1e-1, 10])
ax2.set_xlim([0, 1.5])
ax2.set_yscale('log') 
#ax2.legend(fontsize=11, loc='upper right')
ax2.grid(True)
ax2.tick_params(axis='both', labelsize=14)


# Adjust layout
plt.tight_layout()

# Save the figure in multiple formats
plt.savefig('Tsurf_nLi3_shared_x_axis_continuation_no_labels.eps', format='eps', dpi=600)  # High-res EPS for publication
plt.savefig('Tsurf_nLi3_shared_x_axis_continuation_no_labels.jpg', format='jpg', dpi=600)  # High-res JPG
plt.savefig('Tsurf_nLi3_shared_x_axis_continuation_no_labels.png', format='png', dpi=300)  # High-res PNG

# Show the plot
plt.show()


