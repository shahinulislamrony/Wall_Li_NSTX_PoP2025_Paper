from uedge import *
from uedge.hdf5 import *
from uedge.rundt import *
import uedge_mvu.plot as mp
import uedge_mvu.utils as mu
import uedge_mvu.analysis as an
import uedge_mvu.tstep as ut
import UEDGE_utils.analysis as ana
import UEDGE_utils.plot as utplt
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from runcase import *

setGrid()
setPhysics(impFrac=0,fluxLimit=True)
setDChi(kye=1.0, kyi=1.0, difni=0.5,nonuniform = True)
setBoundaryConditions(ncore=6.2e19, pcoree=2.0e6, pcorei=2.0e6, recycp=0.98)
setimpmodel(impmodel=True)
#setgaspuff()

bbb.cion=3
bbb.oldseec=0
bbb.restart=1
bbb.nusp_imp = 3
bbb.icntnunk=0
hdf5_restore("./final_iteration.hdf5") # converged solution with Li atoms and ions for bbb.isteon=0
#bbb.isteon=0

bbb.ftol=1e20;bbb.dtreal=1e-10
bbb.issfon=0; bbb.isbcwdt=1
bbb.exmain()
mu.paws("Completed reading a converged solution for Li atoms and Li ions solution")

