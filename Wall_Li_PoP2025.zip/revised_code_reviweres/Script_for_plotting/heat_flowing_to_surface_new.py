# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os


def eval_Li_evap_at_T_Cel(temperature):
    """Calculate lithium evaporation flux at a given temperature in Celsius."""
    a1 = 5.055
    b1 = -8023.0
    xm1 = 6.939
    tempK = temperature + 273.15

    if np.any(tempK <= 0):
        raise ValueError("Temperature must be above absolute zero (-273.15°C).")

    vpres1 = 760 * 10 ** (a1 + b1 / tempK)  # Vapor pressure
    sqrt_argument = xm1 * tempK

    if np.any(sqrt_argument <= 0):
        raise ValueError("Invalid value for sqrt: xm1 * tempK has non-positive values.")

    fluxEvap = 1e4 * 3.513e22 * vpres1 / np.sqrt(sqrt_argument)  # Evaporation flux
    return fluxEvap


datasets = [
#    {
#     'path': r'C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX-U_g116313\Updated_heat_Andrei_02132025\PePi6MW_Dn0.35Chi0.5_fneut0.35_check',
#     'nx': 200,
#     'dt': 10e-3,
#     'label_tsurf': 'P$_{in}$: 6MW'
# },
   
   {
    'path': r'C:\UEDGE_run_Shahinul\NSTX_PoP\PePi2.0MW',
    'nx': 1000,
    'dt': 5e-3,
    'label_tsurf': 'P$_{in}$: 8MW'
},
   
#    {
#     'path': r'C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX-U_g116313\Case_for_02132024_meeting\PePi8MW_Dn0.35Chi0.5_t5s',
#     'nx': 134,
#     'dt': 10e-3,
#     'label_tsurf': 'P$_{in}$: 8MW'
# },
   
   
#    {
#     'path': r'C:\UEDGE_run_Shahinul\NSTX_U\SOFE\SOFE\nsep_5.7e19_for_power_scan\PePi10MW',
#     'nx': 68,
#     'dt': 10e-3,
#     'label_tsurf': 'P$_{in}$: 8MW'
# },
   
#    {
#     'path': r'C:\UEDGE_run_Shahinul\NSTX_U\SOFE\SOFE\nsep_5.7e19_for_power_scan\PePi11MW',
#     'nx':75,
#     'dt': 10e-3,
#     'label_tsurf': 'P$_{in}$: 10MW'
# },
]


def process_dataset(data_path, nx, dt):
    """Process dataset to extract and compute required values."""
    max_value_tsurf = []
    max_q = []
    max_q_Li = []
    evap_flux_max = []
    CLi_omp = []

    q_perp_dir = os.path.join(data_path, 'q_perp')
    q_Li_dir = os.path.join(data_path, 'q_Li_surface')
    T_surf_dir = os.path.join(data_path, 'Tsurf_Li')
    C_Li_dir = os.path.join(data_path, 'C_Li_omp')

    for i in range(1, nx):  # Adjust range if data indexing starts differently
        filename_tsurf = os.path.join(T_surf_dir, f'T_surfit_{i}.0.csv')
        filename_qsurf = os.path.join(q_perp_dir, f'q_perpit_{i}.0.csv')
        filename_qsurf_Li = os.path.join(q_Li_dir, f'q_Li_surface_{i}.0.csv')
        filename_CLi = os.path.join(C_Li_dir, f'CLi_prof{i}.0.csv') 

        try:
            # Load T_surf data
            df_tsurf = pd.read_csv(filename_tsurf)
            max_tsurf = np.max(df_tsurf.values)
            max_value_tsurf.append(max_tsurf)

            # Load q_perp data
            df_qsurf = pd.read_csv(filename_qsurf)
            max_q_i = np.max(df_qsurf.values)
            max_q.append(max_q_i)
            
            df_qsurf2 = pd.read_csv(filename_qsurf_Li)
            max_q_Li_i = np.max(df_qsurf2.values)
            max_q_Li.append(max_q_Li_i)
            
            C_Li_data = pd.read_csv(filename_CLi).values
            max_value4 = np.average(C_Li_data)
            CLi_omp.append(max_value4)

            # Calculate evaporation flux
            evap_flux = eval_Li_evap_at_T_Cel(max_tsurf)  # Assuming this function is defined elsewhere
            evap_flux_max.append(evap_flux)

        except FileNotFoundError:
            print(f"File {filename_tsurf} or {filename_qsurf} not found. Skipping.")
            continue
        except Exception as e:
            print(f"Error processing files: {e}")
            continue

    # Calculate q_surface outside the loop
    q_surface = np.array(max_q) - 2.26e-19 * np.array(evap_flux_max)
    return max_value_tsurf, max_q, evap_flux_max, q_surface, CLi_omp, dt * np.arange(1, nx), max_q_Li



# Plotting
fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(6, 6), sharex=True)

for dataset in datasets:
    max_value_tsurf, max_q, evap_flux_max, q_surface,  CLi_omp, time_axis, max_q_Li = process_dataset(
        dataset['path'], dataset['nx'], dataset['dt']
    )

    # Plot Tsurf on ax1
    
    #ax1.plot(time_axis, np.array(max_q) / 1e6, marker='o', linestyle='--', label=f'{dataset["label_tsurf"]}')
    ax1.plot(time_axis, np.array(max_q_Li) / 1e6, marker='o', linestyle='--', label=f'{dataset["label_tsurf"]}')
    ax2.plot(time_axis, max_value_tsurf, marker='*', linestyle='-', label=f'Tsurf ({dataset["label_tsurf"]})')
    ax3.plot(time_axis, np.multiply(CLi_omp,100), marker='*', linestyle='-', label=f'Tsurf ({dataset["label_tsurf"]})')

    # Plot q_perp and q_surface on ax2
    #ax2.plot(time_axis, np.array(max_q) / 1e6, marker='d', linestyle='-', label=f'qperp ({dataset["label_tsurf"]})')
   

ax1.set_ylabel('q$_{s}^{max}$ (MW/m$^2$)', fontsize=16)
ax1.set_xlim([0,5])
ax1.set_ylim([0, 10])
ax1.legend(loc='upper right', fontsize=12)
ax1.grid(True)
ax1.tick_params(axis='both', labelsize=14)


ax2.set_ylabel("T$_{surf}^{max}$ ($^\circ$C)", fontsize=16)
ax2.set_ylim([0, 700])
ax2.set_xlim([0, 2.5])
#ax2.set_xlabel('t$_{sim}$ (s)', fontsize=18)
#ax1.legend(loc='upper right', fontsize=12)
ax2.grid(True)
ax2.tick_params(axis='both', labelsize=14)

ax3.set_ylabel("C$_{Li-sep}^{OMP}$ (%)", fontsize=16)
ax3.set_ylim([0, 15])
ax3.set_xlim([0, 2.5])
ax3.set_xlabel('t$_{sim}$ (s)', fontsize=16)
#ax1.legend(loc='upper right', fontsize=12)
ax3.grid(True)
ax3.tick_params(axis='both', labelsize=14)


plt.tight_layout()
plt.show()
