import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy.interpolate import UnivariateSpline

Dn = np.loadtxt(r'C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX-U_g116313\Dn_John_canik.txt')
Chi = np.loadtxt(r'C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX-U_g116313\Chi_John_canik.txt')

plt.plot(Dn[:,0], Dn[:,1], '-*r', linewidth = '2')
plt.xlabel('$\psi$', fontsize = 20)
plt.ylabel("D ($m^2$/s)", fontsize=20, color='k')
plt.ylim([0,1])
plt.xlim([0.85, 1.1])
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
# Add legends
plt.legend(loc='best', fontsize =14)
plt.grid()
plt.show()




com_psi = np.array([-0.04886662, -0.04586042, -0.04421597, -0.04294457, -0.04149323,
       -0.03988257, -0.03838045, -0.03725728, -0.03659735, -0.03638948,
       -0.0361559 , -0.03589872, -0.03559941, -0.03526566, -0.03488076,
       -0.03444407, -0.03395352, -0.03340201, -0.03277571, -0.03206163,
       -0.03125118, -0.03034018, -0.02930021, -0.02812164, -0.02678198,
       -0.02678197])

yyc = np.array([-0.01547601, -0.01356714, -0.01062088, -0.00878213, -0.00706762,
                              -0.00514406, -0.00318701, -0.00153801, -0.00041783,  0.00012821,
                               0.00040441,  0.00071499,  0.00106491,  0.00146118,  0.00191115,
                               0.00242573,  0.00300786,  0.00366598,  0.00440803,  0.00524829,
                               0.0062062,   0.00729005,  0.00851666,  0.00991239,  0.01149827,
                               0.01234134])

Dn_fit = np.array([0.09155547, 0.10042908, 0.10074359, 0.11528957, 0.13272229,
       0.16152222, 0.22189648, 0.25916566, 0.30212967, 0.34511614,
       0.3908658 , 0.4166779 , 0.44530934, 0.47970301, 0.49977535,
       0.52281305, 0.53720178, 0.52607045, 0.51496159, 0.49237319,
       0.47544593, 0.45854113, 0.4387833 , 0.41331941, 0.38514849,
       0.36535697])

coefficients = np.polyfit(yyc, Dn_fit, 7)
polynomial = np.poly1d(coefficients)

x_fit = np.linspace(min(yyc), max(yyc), 100)
y_fit = polynomial(x_fit)

plt.scatter(yyc, Dn_fit, label='Data Points', color='red')
plt.plot(x_fit, y_fit, label='Fitted Cubic Polynomial', color='blue')
plt.xlabel('com_psi')
plt.ylabel('Dn_fit')
plt.title('Cubic Polynomial Fit to Data')
#plt.axhline(0, color='black', lw=0.5, ls='--')
#plt.axvline(0, color='black', lw=0.5, ls='--')
plt.grid()
plt.legend()
plt.show()

# Display the coefficients of the fitted polynomial
print("Coefficients of the fitted polynomial (from highest to lowest degree):")
print(coefficients)

equation = "P(x) = "
for i, coeff in enumerate(coefficients):
    degree_term = len(coefficients) - i - 1
    if degree_term > 0:
        equation += f"{coeff:.6f} * x^{degree_term} + "
    else:
        equation += f"{coeff:.6f}"

print("Polynomial Equation:")
print(equation)


Chi_fit = np.array([0.90331977, 0.87726606, 0.86495254, 0.92028695, 1.01595875,
       1.1792445 , 1.38279971, 1.57271664, 1.8982691 , 2.7655145 ,
       3.48348608, 4.11996765, 4.93255801, 5.83983508, 6.61174837,
       7.69493044, 8.27706267, 9.0218013 , 9.61746991, 9.92890853,10,10.5,11,11.5,12,12.5])


coefficients = np.polyfit(yyc, Chi_fit, 5)
polynomial = np.poly1d(coefficients)

x_fit = np.linspace(min(yyc), max(yyc), 100)
y_fit = polynomial(x_fit)

plt.scatter(yyc, Chi_fit, label='Data Points', color='red')
plt.plot(x_fit, y_fit, label='Fitted Cubic Polynomial', color='blue')
plt.xlabel('r$_{omp}$ - r$_{sep}$ (m)', fontsize = 20)
plt.ylabel("$\chi$ ($m^2$/s)", fontsize=20, color='k')
plt.title('Cubic Polynomial Fit to Data')
#plt.axhline(0, color='black', lw=0.5, ls='--')
#plt.axvline(0, color='black', lw=0.5, ls='--')
plt.grid()
plt.legend()
plt.show()

print('------------Chi----------------')
# Display the coefficients of the fitted polynomial
print("Coefficients of the fitted polynomial (from highest to lowest degree):")
print(coefficients)

equation = "P(x) = "
for i, coeff in enumerate(coefficients):
    degree_term = len(coefficients) - i - 1
    if degree_term > 0:
        equation += f"{coeff:.6f} * x^{degree_term} + "
    else:
        equation += f"{coeff:.6f}"

print("Polynomial Equation:")
print(equation)

plt.plot(com_psi, Dn[:-1,1], '-*r', linewidth = '2')
plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize = 20)
plt.ylabel("D ($m^2$/s)", fontsize=20, color='k')
plt.ylim([0,1])
#plt.xlim([0.85, 1.1])
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
# Add legends
plt.legend(loc='best', fontsize =14)
plt.grid()
plt.show()



plt.plot(Chi[:,0], Chi[:,1], '-*r', linewidth = '2')
plt.xlabel('$\psi$', fontsize = 20)
plt.ylabel("$\chi$ ($m^2$/s)", fontsize=20, color='k')
plt.ylim([0,10])
plt.xlim([0.85, 1.1])
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
# Add legends
plt.legend(loc='best', fontsize =14)
plt.grid()
plt.show()


fig, ax1 = plt.subplots()
ax1.plot(Dn[:, 0], Dn[:, 1], '-*r', linewidth=2)
ax1.set_xlabel('$\psi$', fontsize=20)
ax1.set_ylabel("D ($m^2$/s)", fontsize=20, color='k')
ax1.set_ylim([0, 1])
ax1.set_xlim([0.85, 1.1])
ax1.tick_params(axis='x', labelsize=14)
ax1.tick_params(axis='y', labelsize=14)
ax1.grid()


ax2 = ax1.twinx()

ax2.plot(Chi[:, 0], Chi[:, 1], '-dk', linewidth=2)
ax2.set_ylabel("$\chi$ ($m^2$/s)", fontsize=20, color='k')
ax2.set_ylim([0, 10])
ax2.tick_params(axis='y', labelsize=14)
ax1.legend(['D'], loc='upper left', fontsize=14)
ax2.legend(['$\chi$'], loc='best', fontsize=14)
plt.show()


x_data = Dn[:, 0]
y_data = Dn[:, 1]

def model_func(x, a, b, c, d):
    return a * x**3 + b * x**2 + c * x + d

# Perform curve fitting
params, covariance = curve_fit(model_func, x_data, y_data)

# Display the equation
a, b, c, d = params
print(f"Fitted equation: y = {a:.4f}x^3 + {b:.4f}x^2 + {c:.4f}x + {d:.4f}")

# Generate x values for plotting the fitted curve
x_fit = np.linspace(min(x_data), max(x_data), 100)
y_fit = model_func(x_fit, *params)

# Plot the data and the fitted curve
plt.scatter(x_data, y_data, label='Data', color='red')
plt.plot(x_fit, y_fit, label='Fitted Curve', color='blue')
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.title('Curve Fitting with Higher-Order Polynomial')
plt.legend()
plt.grid()
plt.show()

print('a is :', a)
print('b is :', b)
print('c is :', c)
print('d is :', d)

spline = UnivariateSpline(x_data, y_data, s=0.5)  # Adjust s for smoothness

# Generate x values for plotting the fitted curve
x_fit = np.linspace(min(x_data), max(x_data), 100)
y_fit = spline(x_fit)

# Plot the data and the fitted spline
plt.scatter(x_data, y_data, label='Data', color='red')
plt.plot(x_fit, y_fit, label='Fitted Spline', color='blue')
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.title('Curve Fitting with Smoothing Spline')
plt.legend()
plt.grid()
plt.show()

com_yyc = yyc

P_data = -12952480619329.812500 * com_yyc**7 -59216341208.612869 * com_yyc**6 + 5758434234.017868 * com_yyc**5 + 19276205.260527 * com_yyc**4 -878252.947660 *com_yyc**3 -2477.339995 *com_yyc**2 + 56.660506 * com_yyc + 0.378588

plt.plot(com_yyc, P_data)
plt.show()