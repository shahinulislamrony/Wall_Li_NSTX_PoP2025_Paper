import matplotlib.pyplot as plt
import numpy as np

# Data points for the first plot
data = [
    [0.315, -1.05],
    [0.415, -1.27],
    [0.415, -1.577],
    [0.435, -1.623],
    [0.435, -1.623],
    [0.571, -1.623],
    [0.616, -1.628],
    [1.043, -1.460]
]

# Extract x and y coordinates
x = [point[0] for point in data]
y = [point[1] for point in data]

# First plot
plt.figure(figsize=(4, 3))
plt.plot(x, y, marker='o', linestyle='-', color='b', label='Path')

# Add labels and title
plt.xlabel('R [m]', fontsize=14)
plt.ylabel('Z [m]', fontsize=14)

# Display grid
plt.grid(True)

# Show the plot
plt.show()

# Old data points for comparison
old_data = [
    [0.315, -1.05],
    [0.40, -1.27],
    [0.40, -1.623],
    [0.4, -1.623],
    [0.8, -1.623]
]

# Extract x and y coordinates for old data
x1 = [point[0] for point in old_data]
y1 = [point[1] for point in old_data]

# Second plot to compare the two datasets
plt.figure(figsize=(3, 2))
plt.plot(x, y, linestyle='-', color='b', label='Correct', linewidth = 2)
plt.plot(x1, y1, linestyle='--', color='r', label='old', linewidth = 2)

# Add labels and title
plt.xlabel('R [m]', fontsize=14)
plt.ylabel('Z [m]', fontsize=14)

# Customize ticks
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14)

# Display grid
plt.grid(True)

# Show legend
plt.legend(fontsize=14)

# Show the plot
plt.show()
