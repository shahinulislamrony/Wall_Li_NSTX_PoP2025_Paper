import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.patches import Polygon


# Greenwald density calculation with unit conversion
#n_GW = Ip / (math.pi * a**2 * e)

# Function to calculate cylindrical safety factor (q_cyl)
def calculate_q_cyl(a, B_T, I_p, R_0, kappa):
    q_cyl = (1 + kappa**2/2)*(np.pi * a**2 * B_T) / (I_p * R_0)
    return q_cyl

# NSTX-U parameters

B_T = 1.0 
I_p = 2.0  
R_0 = 0.93   
kappa = 2.74
Aspec = 1.7
a = 0.62
e = 1.60e-19
mu_0 = 4*np.pi*1e-7
 
q_cyl = calculate_q_cyl(a, B_T, I_p, R_0, kappa)
print(f"Cylindrical safety factor q_cyl = {q_cyl:.2f}")


def calculate_lambda_q(B_T, q_cyl, P_SOL, R_geo):
    # Eich Phys. Rev. Lett. 107, 215001

    lambda_q = 0.73 * B_T**(-0.78) * q_cyl**(1.2) * P_SOL**(0.1) * R_geo**(0)
    return lambda_q

def calculate_greenwald(I_p, a, fr = 0.5):
    
    n_gw = ((I_p/(np.pi*a**2))*1.6022e19)*fr
    return n_gw

greenwald = calculate_greenwald(I_p, a, fr=0.5)

print(f"Greenwald density = {greenwald/1e19}")


P_SOL = 10*0.7 # Power crossing the separatrix in MW
R_geo = R_0  # Major radius in meters
#q_cyl = 3.7
 
# Calculate lambda_q

###ITER
#B_T = 5.3  # Toroidal magnetic field (T)
#q_cyl = 2.42  # Cylindrical quantity (safety factor?)
#P_SOL = 120  # Power (W)
#R_geo = 6.2

lambda_q = calculate_lambda_q(B_T, q_cyl, P_SOL, R_geo)

# Print the result in mm
print(f"λ_q = {lambda_q:.2f} mm")


GP_rate_OMP = [0, 600, 675, 700, 760, 800, 850, 900, 930]
ne_esep_OMP = [3.5019, 4.2647, 4.344, 4.37, 4.43, 4.475,  4.528, 4.582, 4.614 ]
Te_sepm_OMP =[]
C_Li_OMP = []

plt.figure(figsize=(4, 3))
plt.plot(np.divide(GP_rate_OMP,1.6022e-19), (ne_esep_OMP), '--*r', markersize = 12, linewidth = 1)
plt.xlabel(r'$\phi_{GP}^{OMP}$ (particle/s)', fontsize=16)
plt.ylabel(r'n$_{e-sep}^{OMP}$ (m$^{-3}$)', fontsize=16)
plt.grid(True)
ymax = 6e21#np.max(np.divide(GP_rate_OMP,1.6022e-19))
plt.xlim([0, ymax])
plt.ylim([0, 5])
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
plt.tick_params(axis='both', labelsize=12)
plt.tight_layout()