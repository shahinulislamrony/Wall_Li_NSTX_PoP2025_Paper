# -*- coding: utf-8 -*-
"""
Created on Tue Apr 15 10:22:06 2025

@author: islam9
"""

import numpy as np
import matplotlib.pyplot as plt 

def eval_Li_evap_at_T_Cel(temperature):
    a1 = 5.055  #  Antioine eq coefficients
    b1 = -8023.0 #
    xm1 = 6.939 
    tempK = temperature  + 273.15
    vpres1 = 760 * 10**(a1 + b1/tempK)  # 1 atm ~ Barr = 760 Torr
    fluxEvap = 1e4 * 3.513e22 * vpres1 / np.sqrt(xm1 * tempK)

    return fluxEvap


def flux_Li_Phys_Sput(Yield=1e-3, UEDGE= False):
    if UEDGE == False:
    
        kB = 1.3806e-23
        eV = 1.6022e-19
        fd = 1e24
        ft = 0
        fli = 0*(ft+fd)*0.65
        ylid = Yield
        ylit = 0.001
        ylili = 1
        fneut = 0.35
        fneutAd = 1
        fluxPhysSput = fneut*(fd*ylid + ft*ylit + fli*ylili)
        
        return fluxPhysSput
    else:
        print('UEDGE model for Li physical sputtering')
        fluxPhysSput = bbb.sputflxrb[:,1,0]/com.sxnp[com.nx,:]
        return fluxPhysSput
        
def flux_Li_Ad_atom(final_temperature, Yield=1e-3, YpsYad=1, eneff=0.9, A=1e-7):
    yadoyps = YpsYad  # ratio of ad-atom to physical sputtering yield
    eneff = eneff  # effective energy (eV), 0.09
    aad = A  # cont
    ylid = Yield
    ylit = 0.001
    ft=0
    kB = 1.3806e-23
    eV = 1.6022e-19
    tempK = final_temperature + 273.15
    fd = 1e24
    fneutAd = 1
    fluxAd = fd*yadoyps/(1 + aad*np.exp(eV*eneff/(kB*tempK)))

    return fluxAd

final_temperature =  np.linspace(0, 800, 800)


fluxEvap = eval_Li_evap_at_T_Cel(final_temperature)
fluxPhysSput = flux_Li_Phys_Sput(UEDGE= False)
fluxAd= flux_Li_Ad_atom(final_temperature,Yield=1e-3, YpsYad=1e-3, eneff=0.9, A=1e-7)

plt.figure(figsize=(4, 2.5), dpi=300)
plt.plot(final_temperature, fluxEvap, label='Evaporation', color='red', linewidth=2)
plt.axhline(fluxPhysSput, label='Phys. Sput', color='blue', linestyle='--', linewidth=2)

plt.plot(final_temperature, fluxAd, label='Ad-atom', color='green', linestyle=':', linewidth=2)

plt.xlabel('Temperature (°C)', fontsize=16)
plt.ylabel('$\Gamma_{Li}$ (/m$^2$.s)', fontsize=16)  # replace with actual units if known
plt.legend(fontsize=11)
plt.grid(True, linestyle='--', alpha=0.6)
plt.yscale('log')
plt.ylim([1e13, 1e26])
plt.xlim([0, 800])
plt.tick_params(axis='both', which='major', labelsize=12)
plt.tight_layout()
plt.savefig('Li_flux_components_highres.png', dpi=600)
plt.savefig('Li_flux_components_highres.eps', format='eps', dpi=600)
plt.show()




import matplotlib.pyplot as plt
from matplotlib.ticker import LogLocator

plt.figure(figsize=(4, 2.5), dpi=300)

# Plotting the data
plt.plot(final_temperature, fluxEvap, label='Evaporation', color='red', linewidth=2)
plt.axhline(fluxPhysSput, label='Phys. Sput', color='blue', linestyle='--', linewidth=2)
plt.plot(final_temperature, fluxAd, label='Ad-atom', color='green', linestyle=':', linewidth=3)

# Labels and legend
plt.xlabel('Temperature (°C)', fontsize=16)
plt.ylabel('$\Gamma_{Li}$ (/m$^2$.s)', fontsize=16)  # Replace with actual units if known
plt.legend(fontsize=11)

# Grid settings
plt.grid(True, which='major', linestyle='--', alpha=0.6)  # Major grid
plt.minorticks_on()  # Enable minor ticks
plt.grid(True, which='minor', linestyle=':', alpha=0.3)  # Minor grid

# Configure minor ticks for y-axis (log scale)
plt.gca().yaxis.set_minor_locator(LogLocator(base=10.0, subs=range(2, 10), numticks=10))

# Axis scaling and limits
plt.yscale('log')
plt.ylim([1e13, 1e26])
plt.xlim([0, 800])

# Tick parameters (inward ticks for both axes)
plt.tick_params(axis='both', which='major', direction='in', labelsize=12)
plt.tick_params(axis='both', which='minor', direction='in')

# Layout and saving the figure
plt.tight_layout()
plt.savefig('Li_flux_components_highres.png', dpi=600)
plt.savefig('Li_flux_components_highres.eps', format='eps', dpi=600)

# Display the plot
plt.show()