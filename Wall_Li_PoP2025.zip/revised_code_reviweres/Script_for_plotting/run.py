bbb.isbcwdt = 1
bbb.restart = 1
bbb.itermx = 30


for i in range(100):
    bbb.dtreal = 1e-10
    bbb.ftol = 1e-4
    print("****************")
    print(f"run with dt {bbb.dtreal} and ftol {bbb.ftol}")
    bbb.exmain()
    
if bbb.iterm == 1:
    print("300 iterations are done")
    savefile = "Li_100iteration_dt1e10ftol1e4.hdf5"
    hdf5_save(savefile)

for i in range(100):
    bbb.dtreal = 1e-9
    bbb.ftol = 1e-4
    print("****************")
    print(f"run with dt {bbb.dtreal} and ftol {bbb.ftol}")
    bbb.exmain()
    
if bbb.iterm == 1:
    print("300 iterations are done")
    savefile = "Li_100iteration_dt1e9ftol1e4.hdf5"
    hdf5_save(savefile)

n = 200
Li_neu = []
Te_odiv = []
ne_odiv = []
i = 0  
bbb.ftol = 1e-4

while i < n:
    bbb.dtreal *= 1.1  # Increment timestep
    print("****************")
    print(f"run with dt {bbb.dtreal} and ftol {bbb.ftol}")  
    print("****************") 
    bbb.exmain()  # Execute main routine

    Te_odiv.append(np.max(bbb.te[com.nx, :] / bbb.ev))
    ne_odiv.append(np.max(bbb.ne[com.nx, :]))
    Li_neu.append(np.max(bbb.ng[com.nx, :, 1]))

    if bbb.iterm != 1:
        print(f"****Failed at dt {bbb.dtreal}, so reduces by 2")
        bbb.dtreal /= 2
        #bbb.ftol *=2
        if bbb.dtreal < 1e-10:
            print("Warning: timestep too small, setting lower bound")
            bbb.dtreal = 1e-10

    i += 1


Te_odiv = np.array(Te_odiv)
ne_odiv = np.array(ne_odiv)
Li_neu = np.array(Li_neu)


np.savetxt("Te.txt", Te_odiv, header="Te over iterations", comments="")
np.savetxt("ne.txt", ne_odiv, header="ne over iterations", comments="")
np.savetxt("Li.txt", Li_neu, header="Li over iterations", comments="")

print("100 iterations are done")
savefile = "Li_100iterationftol1e4.hdf5"
hdf5_save(savefile)


bbb.ftol = 1e-5
i=0
n=100
bbb.dtreal = 1e-8
while i < n:
    bbb.dtreal *= 1.2  # Increment timestep
    print("****************")
    print(f"run with dt {bbb.dtreal} and ftol {bbb.ftol}")  
    print("****************") 
    bbb.exmain()  # Execute main routine

    Te_odiv.append(np.max(bbb.te[com.nx, :] / bbb.ev))
    ne_odiv.append(np.max(bbb.ne[com.nx, :]))
    Li_neu.append(np.max(bbb.ng[com.nx, :, 1]))

    if bbb.iterm != 1:
        print(f"****Failed at dt {bbb.dtreal}, so reduces by 2")
        bbb.dtreal /= 2
        #bbb.ftol *=2
        if bbb.dtreal < 1e-10:
            print("Warning: timestep too small, setting lower bound")
            bbb.dtreal = 1e-10

    i += 1


print("100 iterations are done")
savefile = "Li_100iteration_ftol1e5.hdf5"
hdf5_save(savefile)




