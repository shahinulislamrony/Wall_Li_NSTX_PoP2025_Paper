# -*- coding: utf-8 -*-
"""
Created on Fri Feb 14 09:24:23 2025

@author: islam9
"""
def ORNL():
    Salary = 53795.18
    FED_ded = 9386.23
    SS_ded =335.30
    Med_ded = 780.03
    Deduction = FED_ded + SS_ded  +  Med_ded
    
    return Salary, Deduction

Rony_ORNL = ORNL()

def LLNL():
    Salary = 63077.54
    FED_ded = 5781.68
    SS_ded = 4140.26
    Med_ded = 968.29
    State = 2614.27
    Deduction = FED_ded + SS_ded  +  Med_ded
    
    return Salary, Deduction, State

Rony_LLNL = LLNL()

Rony_Salary = Rony_ORNL[0] + Rony_LLNL[0]
print("***Rony Salary******     :", Rony_Salary)

Rony_Deduction = Rony_ORNL[1] + Rony_LLNL[1]
print("***Rony Deduction****** :", Rony_Deduction)


def Walmart():
    
    Salary = 30787.45
    FED_ded = 1726.84
    SS_ded =1908.82
    Med_ded = 446.42
    State = 256.63
    Deduction = FED_ded + SS_ded  +  Med_ded
    
    return Salary, Deduction, State
Mitu_Walmart = Walmart()

def Sodexo():
    Salary = 11681.82
    FED_ded = 105.97
    SS_ded = 724.27
    Med_ded = 169.39
    State = 199.03
    Deduction = FED_ded + SS_ded  +  Med_ded
    
    return Salary, Deduction, State

Mitu_Sodexo = Sodexo()

def DoorDash():
    Salary = 1700.66
    FED_ded = 0
    SS_ded = 0
    Med_ded = 0
    State = 0
    Deduction = FED_ded + SS_ded  +  Med_ded
    
    return Salary, Deduction, State

Mitu_Door = DoorDash()

def Taco():
    Salary = 2525.93
    FED_ded = 0
    SS_ded = 156.61
    Med_ded = 36.63
    State = 0
    Deduction = FED_ded + SS_ded  +  Med_ded
    
    return Salary, Deduction, State

Mitu_Taco = Taco()



Mitu_Salary = Mitu_Walmart[0] + Mitu_Sodexo[0] + Mitu_Door[0] + Mitu_Taco[0]

print("***Mitu Salary******     :", Mitu_Salary)

Mitu_Deduction = Mitu_Walmart[1] + Mitu_Sodexo[1] + Mitu_Door[1] + Mitu_Taco[1]
print("***Mitu Deduction****** :", Mitu_Deduction)