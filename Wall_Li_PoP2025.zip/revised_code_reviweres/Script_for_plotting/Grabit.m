% Load the image
imagePath = 'C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX-U_g116313\Dn.png'; % Replace with your image path
image = imread(imagePath);
% Check if the file exists
if isfile(imagePath)
    % Load the image
    image = imread(imagePath);

    % Convert to grayscale if it's a color image
    grayImage = rgb2gray(image);

    % Perform OCR on the grayscale image
    ocrResults = ocr(grayImage);

    % Display extracted text from OCR
    disp('Extracted Text:');
    disp(ocrResults.Text);

    % Display the original image
    figure;
    imshow(image);
    hold on;

    % Draw bounding boxes around recognized words
    wordBBox = ocrResults.WordBoundingBoxes;
    for i = 1:size(wordBBox, 1)
        rectangle('Position', wordBBox(i, :), 'EdgeColor', 'red');
        text(wordBBox(i, 1), wordBBox(i, 2) - 10, ocrResults.Words{i}, 'Color', 'red', 'FontSize', 10);
    end
    hold off;

    % Save the extracted text to a file
    fid = fopen('extracted_text.txt', 'w');
    fprintf(fid, '%s\n', ocrResults.Text);
    fclose(fid);

    % Example: Extract pixel intensity values
    pixelValues = grayImage(:); % Convert the image to a 1D array
    disp(['Total Pixels: ', num2str(numel(pixelValues))]);

    % Perform thresholding to create a binary image
    threshold = 128; % Example threshold value
    binaryImage = grayImage > threshold;
    figure;
    imshow(binaryImage);
    title('Binary Image (Thresholding)');

    % Edge detection using the Canny method
    edges = edge(grayImage, 'canny');
    figure;
    imshow(edges);
    title('Edge Detection (Canny)');

    % Save pixel values to a .mat file
    save('pixelValues.mat', 'pixelValues');

    % Save the binary image as a .png file
    imwrite(binaryImage, 'binary_image.png');

    % Save the edge-detected image
    imwrite(edges, 'edge_detected.png');

else
    disp('Error: File not found.');
end
