clearvars; 
close all; 
clc; clear; 
pc = phys_const;
fontSize =14;


vol = load('C:\UEDGE_run_Shahinul\Sherwood_u_d_Cs\BC_n6e19_PePi6MW\vol.txt');
n_Li1 = load('C:\UEDGE_run_Shahinul\Sherwood_u_d_Cs\BC_n6e19_PePi6MW\n_Li1\n_Li1_0.0.csv');



PePi5MW = readtable('C:\UEDGE_run_Shahinul\Sherwood\PePi2.5MW\BC_n6e19_PePi2.5MW\Li_all.csv');
PePi6MW = readtable('C:\UEDGE_run_Shahinul\Sherwood\PePi3MW\BC_n6e19_Pe3Pi3e6\Li_all.csv');
PePi8MW = readtable('C:\UEDGE_run_Shahinul\Sherwood\PePi4MW\BC_n6e19_PePei4MW\Li_all.csv');
PePi10MW = readtable('C:\UEDGE_run_Shahinul\Sherwood\PePi5MW\BC_n6e19_PePi5MW\Li_all.csv');


Li_radiation_5MW = PePi5MW.Li_rad;
Li_radiation_6MW = PePi6MW.Li_rad;
Li_radiation_8MW = PePi8MW.Li_rad;
Li_radiation_10MW = PePi10MW.Li_rad;

% Li_source_8WM = PePi8MW.phi_Li_source_odiv+abs(PePi8MW.phi_Li_source_idiv);
% Li_source_9WM = PePi9MW.phi_Li_source_odiv+abs(PePi9MW.phi_Li_source_idiv);
% Li_source_8WM = PePi8MW.phi_Li_source_odiv+abs(PePi8MW.phi_Li_source_idiv);
% Li_source_10WM = PePi10MW.phi_Li_source_odiv+abs(PePi10MW.phi_Li_source_idiv);

It = linspace(1,101,101);
dt =10e-3;


figure; 
hold on; box on; grid on;
plot(It.*dt,Li_radiation_5MW./1e6, '-sk', 'LineWidth',2 )
plot(It(1:97).*dt,Li_radiation_6MW./1e6, '-om', 'LineWidth',2 )
plot(It(1:89).*dt,Li_radiation_8MW./1e6, '-hr', 'LineWidth',2 )
plot(It(1:90).*dt,Li_radiation_10MW./1e6, '-dg', 'LineWidth',2 )
%xlabel(' t_{simulation} (s)')
ylabel('Li_{rad} (MW)')
set(gcf,'color','w'); set(gca,'fontsize',14)
legend('P - 8MW', 'P - 9 MW', 'P - 8MW', 'P - 10 MW')
ylim([0 , 2])
xlim([0, 1])
xlabel(' t_{simulation} (s)')


figure; 
subplot(2,1,1)
hold on; box on; grid on;
plot(It.*dt,Li_radiation_8MW./1e6, '-sk', 'LineWidth',2 )
plot(It.*dt,Li_radiation_9MW./1e6, '-hr', 'LineWidth',2 )
%plot(It(1:90).*dt,Li_radiation_10MW./1e6, '-dg', 'LineWidth',2 )
%xlabel(' t_{simulation} (s)')
ylabel('Li_{rad} (WM)')
set(gcf,'color','w'); set(gca,'fontsize',14)
legend('P - 8MW', 'P - 9 MW', 'P - 8MW', 'P - 10 MW')
%ylim([0 , 0.03])
xlim([0, 1])
set(gca, 'XTickLabel', []);


subplot(2,1,2)
hold on; box on; grid on;
plot(It.*dt,Li_source_8WM, '-sk', 'LineWidth',2 )
plot(It.*dt,Li_source_9WM, '-hr', 'LineWidth',2 )
%plot(It(1:85).*dt,Li_source_10WM(1:85), '-dg', 'LineWidth',2 )
xlabel(' t_{simulation} (s)')
ylabel('\phi_{Li}^{Odiv} (atom/s)')
set(gcf,'color','w'); set(gca,'fontsize',14)
%legend('P - 5MW', 'P - 6 MW')
%ylim([0 , 0.03])
xlim([0, 1])
%set(gca, 'XTickLabel', []);

