import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.patches import Polygon

# Define paths and variables for ncore and BC 
# paths = [
#     r'C:\UEDGE_run_Shahinul\NSTX_U\SOFE\SOFE\ncore_12e19_PePi_Scan\nsep_5.7e19_for_power_scan\PePi3MW_ncore_flux_BC',
#     r'C:\UEDGE_run_Shahinul\NSTX_U\SOFE\SOFE\ncore_12e19_PePi_Scan\nsep_5.7e19_for_power_scan\PePi3MW',

# ]

# ## Paths for flux expansion comparison
# paths = [
#    # r'C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX-U_g116313\Flux_expansion_com\NSTX-U_g116313_QF_low_expansion\PePi3MW_ncore_flux_BC',
#    # r'C:\UEDGE_run_Shahinul\NSTX_U\old\SOFE\SOFE\ncore_12e19_PePi_Scan\nsep_5.7e19_for_power_scan\PePi3MW_ncore_flux_BC',
#    # r'C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX-U_g116313\Flux_expansion_com\FluxBC_Dn0.3Chi0.4_Gas_puff_R_N0.95',
#    # r'C:\UEDGE_run_Shahinul\NSTX_U\old\SOFE\SOFE\ncore_12e19_PePi_Scan\nsep_5.7e19_for_power_scan\PePi3MW',


#]


## Paths for flux gas puff and flux comparison
paths = [
    r'C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX-U_g116313\Gas_puff_Comparison\FluxBC_Dn0.3Chi0.4',
   r'C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX-U_g116313\Gas_puff_Comparison\FluxBC_Dn0.3Chi0.4_Gas_puff_R_N0.95',



]


Var = np.array([0, 1])
myleg = [ 'WO-puff', 'With-puff']
com_nx=104; com_ny=24
bbb_ixmp = 67; com_iysptrx=8;
com_oxpt=42;
bbb_ev = 1.6022e-19

marker = 'o' 
line_style = '-.sr' 




def read_csv(filepath):
    try:
        return pd.read_csv(filepath).values
    except Exception as e:
        print(f"Error reading {filepath}: {e}")
        return None

com_data = {}
bbb_data = {}

for path in paths:
    com_data[path] = {
        'vol': read_csv(os.path.join(path, 'vol.csv')),
        'rm': read_csv(os.path.join(path, 'rm.csv')),
        'rm1': read_csv(os.path.join(path, 'rm1.csv')),
        'rm2': read_csv(os.path.join(path, 'rm2.csv')),
        'rm3': read_csv(os.path.join(path, 'rm3.csv')),
        'rm4': read_csv(os.path.join(path, 'rm4.csv')),
        'yyrb': read_csv(os.path.join(path, 'yyrb.csv')),
        'yylb': read_csv(os.path.join(path, 'yylb.csv')),
        'yyc': read_csv(os.path.join(path, 'yyc.csv')),
        'zm': read_csv(os.path.join(path, 'zm.csv')),
        'zm1': read_csv(os.path.join(path, 'zm1.csv')),
        'zm2': read_csv(os.path.join(path, 'zm2.csv')),
        'zm3': read_csv(os.path.join(path, 'zm3.csv')),
        'zm4': read_csv(os.path.join(path, 'zm4.csv')),
        'angfx': read_csv(os.path.join(path, 'angfx.csv')),
        'sx': read_csv(os.path.join(path, 'sx.csv')),
        'sy': read_csv(os.path.join(path, 'sy.csv'))
    }

    bbb_data[path] = {
        'Te': read_csv(os.path.join(path, 'te.csv')),
        'Ti': read_csv(os.path.join(path, 'ti.csv')),
        'ne': read_csv(os.path.join(path, 'ne.csv')),
        'ni': read_csv(os.path.join(path, 'ni.csv')),
        'natom': read_csv(os.path.join(path, 'natom.csv')),
        'uup': read_csv(os.path.join(path, 'uup.csv')),
        'up': read_csv(os.path.join(path, 'up.csv')),
        'upLi1': read_csv(os.path.join(path, 'upLi1.csv')),
        'upLi2': read_csv(os.path.join(path, 'upLi2.csv')),
        'upLi3': read_csv(os.path.join(path, 'upLi3.csv')),
        
        'feex': read_csv(os.path.join(path, 'feex.csv')),
        'feix': read_csv(os.path.join(path, 'feix.csv')),
        'fnix': read_csv(os.path.join(path, 'fnix.csv')),
        'fnix_neu': read_csv(os.path.join(path, 'fnix_neu.csv')),
        'fniy_neu': read_csv(os.path.join(path, 'fniy_neu.csv')),
        'pri': read_csv(os.path.join(path, 'pri.csv')),
        'pre': read_csv(os.path.join(path, 'pre.csv')),
        'pr': read_csv(os.path.join(path, 'pr.csv')),
        'fniy': read_csv(os.path.join(path, 'fniy.csv')),
        'feey': read_csv(os.path.join(path, 'feey.csv')),
        'feiy': read_csv(os.path.join(path, 'feiy.csv')),
        'erlrc': read_csv(os.path.join(path, 'erlrc.csv')),
        'erliz': read_csv(os.path.join(path, 'erliz.csv')),
        'pradhyd': read_csv(os.path.join(path, 'pradhyd.csv')),
        'psor': read_csv(os.path.join(path, 'psor.csv')),
        'psorrg': read_csv(os.path.join(path, 'psorrg.csv')),
        'prad': read_csv(os.path.join(path, 'prad.csv')),
        'qpar': read_csv(os.path.join(path, 'q_para.csv')),
        'qpar_odiv': read_csv(os.path.join(path, 'q_para_odiv.csv')),
        'qperp_odiv': read_csv(os.path.join(path, 'q_perp_div.csv')),
        'q_odiv': read_csv(os.path.join(path, 'q_odiv.csv')),
    }
    

fig, axes = plt.subplots(2, 1, figsize=(4, 4))  

for i, path in enumerate(paths):
    if 'Te' in bbb_data[path]:  
        Te = bbb_data[path]['Te']
        yyc = com_data[path]['yyc']
        axes[0].plot(yyc, Te[bbb_ixmp, :-1]/1e3, label=myleg[i] if i < len(myleg) else f'Path {i}')
           
#axes[0].set_xlabel(r'r$_{omp}$ - r$_{sep}$ (m)', fontsize=16)
axes[0].set_ylabel('T$_e$ (keV)', fontsize=18)
axes[0].set_title('T$e^{OMP}$')
axes[0].set_ylim([0,1.5])
axes[0].legend(loc='best', fontsize=8, ncol=2, title_fontsize='11')
axes[0].grid(True)

for i, path in enumerate(paths):
    if 'Te' in bbb_data[path]:  # Check if 'Te' is in the current path's data
        feex = bbb_data[path]['feex']
        feix = bbb_data[path]['feex']
        feey = bbb_data[path]['feey']
        feiy = bbb_data[path]['feiy']
        yyc = com_data[path]['yyc']
        sx = com_data[path]['sx']
        sy = com_data[path]['sy']
        conduction = (feey) + feiy 

        axes[1].plot(yyc, (conduction[bbb_ixmp,:-1]/sy[bbb_ixmp, :-1])/1e6, label=myleg[i] if i < len(myleg) else f'Path {i}')
       
axes[1].set_xlabel(r'r$_{omp}$ - r$_{sep}$ (m)', fontsize=16)
axes[1].set_ylabel(r'q$_{cond}$ (MW/m2)', fontsize=16)
axes[1].grid(True)
axes[1].set_ylim([0.0, 2])
#axes[1].set_yscale('log')
axes[1].tick_params(axis='both', labelsize=12)

fig.tight_layout()
fig.savefig('Combined_Chi_D_omp.png', dpi=300, bbox_inches='tight')
plt.show()

plt.figure(figsize=(5,3))
for i, path in enumerate(paths):
    if 'Te' in bbb_data[path]:  # Check if 'Te' is in the current path's data
        feex = bbb_data[path]['feex']
        feix = bbb_data[path]['feex']
        feey = bbb_data[path]['feey']
        feiy = bbb_data[path]['feiy']
        yyc = com_data[path]['yyc']
        sx = com_data[path]['sx']
        sy = com_data[path]['sy']
        conduction = (feey) + (feiy)
        convection = (feex) + (feix)

        plt.plot(yyc, (convection[bbb_ixmp,:-1]/sx[bbb_ixmp, :-1])/1e6, label=myleg[i] if i < len(myleg) else f'Path {i}')
       
plt.xlabel(r'r$_{omp}$ - r$_{sep}$ (m)', fontsize=16)
plt.ylabel(r'q$_{convec}$ (MW/m2)', fontsize=16)
plt.grid(True)
plt.xlim([-0.010, 0])
plt.ylim([-1e9, 10])
#plt.yscale('log')
plt.tick_params(axis='both', labelsize=12)
plt.tight_layout()

plt.show()
     
plt.figure(figsize=(5,3))


for i, path in enumerate(paths):
    if 'Te' in bbb_data[path]:  # Check if 'Te' is in the current path's data
        feex = bbb_data[path]['feex']
        feix = bbb_data[path]['feex']
        feey = bbb_data[path]['feey']
        feiy = bbb_data[path]['feiy']
        yyc = com_data[path]['yyc']
        sx = com_data[path]['sx']
        sy = com_data[path]['sy']
        conduction = (feey) + (feiy)

        
        plt.plot(yyc, conduction[bbb_ixmp,:-1]/sy[bbb_ixmp, :-1], label=myleg[i] if i < len(myleg) else f'Path {i}')
       
    
plt.xlabel(r'r$_{omp}$ - r$_{sep}$ (m)', fontsize=18)
plt.ylabel(r'q$_{conduction}$ (W/m2)', fontsize=18)
plt.title(r'P$_{total}$', fontsize=20)
plt.grid(True)
#plt.ylim([0, 10])
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.legend(loc='best', fontsize=12)
plt.tight_layout()
plt.savefig('P_omp.png', dpi=300, bbox_inches='tight')
plt.show()
        
fig, axs = plt.subplots(2, 1, sharex=True, figsize=(6, 5))

for i, path in enumerate(paths):
    if 'Te' in bbb_data[path]:
        Te = bbb_data[path]['Te']
        yyc = com_data[path]['yyc']
        axs[0].plot(yyc, Te[bbb_ixmp, :-1]/1e3, label=myleg[i] if i < len(myleg) else f'Path {i}')

#axs[0].set_xlabel('r$_{omp}$ - r$_{sep}$ (m)', fontsize=18)
axs[0].set_ylabel('T$_e$ (keV)', fontsize=18)
axs[0].set_title('T$e^{OMP}$')
axs[0].set_ylim([0,0.5])
axs[0].grid(True)

axs[0].tick_params(axis='both', labelsize=14)
axs[0].legend(loc='best', fontsize=14)

for i, path in enumerate(paths):
    if 'ne' in bbb_data[path]:
        ne = bbb_data[path]['ne']
        ni = bbb_data[path]['ni']
        natom = bbb_data[path]['natom']
        yyc = com_data[path]['yyc']
        axs[1].plot(yyc, ne[bbb_ixmp, :-1]/1e19, label=myleg[i] if i < len(myleg) else f'Path {i}')

axs[1].set_xlabel('r$_{omp}$ - r$_{sep}$ (m)', fontsize=18)
axs[1].set_ylabel('n$_e$ (10$^{20}$ m$^{-3}$)', fontsize=18)
axs[1].set_title('n$e^{OMP}$')
axs[1].grid(True)
axs[1].tick_params(axis='both', labelsize=14)
#axs[1].legend(loc='best', fontsize=14)
axs[1].set_ylim([0, 8])
plt.tight_layout()
plt.savefig('Te_ne_omp.png', dpi=300, bbox_inches='tight')
plt.show()


plt.figure(figsize=(5,3))


# Iterate over paths
for i, path in enumerate(paths):
    if 'Te' in bbb_data[path]:  # Check if 'Te' is in the current path's data
        Te = bbb_data[path]['Te']
        ne = bbb_data[path]['ne']
        ni = bbb_data[path]['ni']
        Ti = bbb_data[path]['Ti']
        up = bbb_data[path]['up']
        
        # Calculate total pressure
        Press = (ne * Te*bbb_ev + ni * Ti*bbb_ev) + 0.5 * 1.673e-27 * (up) ** 2
        
        # Extract the coordinate data for plotting
        yyc = com_data[path]['yyc']
        
        plt.plot(yyc, Press[bbb_ixmp, :-1]/1e3, label=myleg[i] if i < len(myleg) else f'Path {i}')
       
    

plt.xlabel(r'r$_{omp}$ - r$_{sep}$ (m)', fontsize=18)
plt.ylabel(r'P (kPa)', fontsize=18)
plt.title(r'P$_{total}$', fontsize=20)
plt.grid(True)
plt.ylim([0, 20])
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.legend(loc='best', fontsize=14)
plt.tight_layout()
plt.savefig('P_omp.png', dpi=300, bbox_inches='tight')
plt.show()
     
# Iterate over paths
for i, path in enumerate(paths):
    if 'Te' in bbb_data[path]:  # Check if 'Te' is in the current path's data
        Te = bbb_data[path]['Te']
        ne = bbb_data[path]['ne']
        ni = bbb_data[path]['ni']
        Ti = bbb_data[path]['Ti']
        up = bbb_data[path]['up']
        zm = com_data[path]['zm']
        upLi1 = bbb_data[path]['upLi1']
        upLi2 = bbb_data[path]['upLi2']
        upLi3 = bbb_data[path]['upLi3']
    
        
        plt.plot(zm[:,10], up[:, 10]/1e4, color ='red', linestyle = '-', linewidth = 2)
       

plt.xlabel(r'Z (m)', fontsize=18)
plt.ylabel(r'u$_{||}$ (1e4 m/s)', fontsize=18)
plt.title(r'3rd FT', fontsize=20)
plt.grid(True)
plt.xlim([-1.65, -1.25])
plt.ylim([0, 6])
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.legend(loc='best', fontsize=14)
plt.tight_layout()
plt.savefig('P_omp.png', dpi=300, bbox_inches='tight')
plt.show()
     

        
fig, axs = plt.subplots(2, 1, sharex=True, figsize=(6, 5))

for i, path in enumerate(paths):
    if 'Te' in bbb_data[path]:
        Te = bbb_data[path]['Te']
        yyc = com_data[path]['yyc']
        axs[0].plot(yyc, Te[bbb_ixmp, :-1]/1e3, label=myleg[i] if i < len(myleg) else f'Path {i}')

#axs[0].set_xlabel('r$_{omp}$ - r$_{sep}$ (m)', fontsize=18)
axs[0].set_ylabel('T$_e$ (keV)', fontsize=18)
axs[0].set_title('T$e^{OMP}$')
axs[0].set_ylim([0,1.5])
axs[0].grid(True)

axs[0].tick_params(axis='both', labelsize=14)
axs[0].legend(loc='best', fontsize=14)

for i, path in enumerate(paths):
    if 'ne' in bbb_data[path]:
        ne = bbb_data[path]['ne']
        ni = bbb_data[path]['ni']
        natom = bbb_data[path]['natom']
        yyc = com_data[path]['yyc']
        axs[1].plot(yyc, ne[bbb_ixmp, :-1]/1e20, label=myleg[i] if i < len(myleg) else f'Path {i}')

axs[1].set_xlabel('r$_{omp}$ - r$_{sep}$ (m)', fontsize=18)
axs[1].set_ylabel('n$_e$ (10$^{20}$ m$^{-3}$)', fontsize=18)
axs[1].set_title('n$e^{OMP}$')
axs[1].grid(True)
axs[1].tick_params(axis='both', labelsize=14)
#axs[1].legend(loc='best', fontsize=14)
axs[1].set_ylim([0, 1.5])
plt.tight_layout()
plt.savefig('Te_ne_omp.png', dpi=300, bbox_inches='tight')
plt.show()

    
    
plt.figure()
for i, path in enumerate(paths):
    if 'Te' in bbb_data[path]:
        Te = bbb_data[path]['Te']
    
        yyc = com_data[path]['yyc']
        plt.plot(yyc, Te[bbb_ixmp, :-1], label=myleg[i] if i < len(myleg) else f'Path {i}')
plt.xlabel('r$_{omp}$ - r$_{sep}$ (m)', fontsize=18)
plt.ylabel('T$_e$ (eV)', fontsize=18)
plt.title('T$e^{Odiv}$')
plt.grid(True)
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
#plt.legend(loc='best', fontsize=14)
plt.tight_layout()
plt.savefig('Te_odiv.png', dpi=300, bbox_inches='tight')
plt.show()


plt.figure()
for i, path in enumerate(paths):
    if 'ne' in bbb_data[path]:
        ne = bbb_data[path]['ne']
        yyc = com_data[path]['yyc']
        plt.plot(yyc, ne[bbb_ixmp, :-1], label=myleg[i] if i < len(myleg) else f'Path {i}')

plt.xlabel('r$_{omp}$ - r$_{sep}$ (m)', fontsize=18)
plt.ylabel('n$_e$ (m$^{-3}$)', fontsize=18)
plt.title('n$e^{Odiv}$')
plt.grid(True)
plt.ylim([0, 6.5e19])
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
plt.legend(loc='best', fontsize=14)
plt.tight_layout()
plt.savefig('ne_odiv.png', dpi=300, bbox_inches='tight')
plt.show()

plt.figure()
for i, path in enumerate(paths):
    if 'q_odiv' in bbb_data[path]:
        q_odiv = bbb_data[path]['q_odiv']
        yyrb = com_data[path]['yyrb']
        plt.plot(yyrb,  q_odiv/1e6, linewidth=2, label=myleg[i] if i < len(myleg) else f'Path {i}')

plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize=18)
plt.ylabel('q$_\perp^{odiv}$ (MW/m$^2$)', fontsize=18)
plt.title('q$_{\perp}^{Odiv}$', fontsize=14)
plt.grid(True)
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
plt.legend(loc='best', fontsize=14)
plt.ylim([0 , 5])
plt.tight_layout()
plt.savefig('q_odiv.png', dpi=300, bbox_inches='tight')
plt.show()


# plt.figure()
# for i, path in enumerate(paths):
#     if 'qperp_odiv' in bbb_data[path]:
#         qperp = bbb_data[path]['qperp_odiv']
#         yyrb = com_data[path]['yyrb']
#         plt.plot(yyrb,  qperp/1e6, linewidth=2, label=myleg[i] if i < len(myleg) else f'Path {i}')

# plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize=18)
# plt.ylabel('q$_\perp^{odiv}$ (MW/m$^2$)', fontsize=18)
# plt.title('q$_{\perp}^{Odiv}$', fontsize=14)
# plt.grid(True)
# plt.xticks(fontsize=14) 
# plt.yticks(fontsize=14) 
# plt.legend(loc='best', fontsize=14)
# plt.ylim([0 , 15])
# plt.tight_layout()
# plt.savefig('q_odiv.png', dpi=300, bbox_inches='tight')
# plt.show()


ymax=0

plt.figure()
for i, path in enumerate(paths):
    if 'qperp_odiv' in bbb_data[path]:
        fnix = bbb_data[path]['fnix']
        angfx = com_data[path]['angfx']
        sx = com_data[path]['sx']
        flux = fnix[com_nx-1,:]*angfx[com_nx-1,:]/sx[com_nx-1,:]
        yyrb = com_data[path]['yyrb']
        plt.plot(yyrb,  -1*flux[:-1], linewidth=2, label=myleg[i] if i < len(myleg) else f'Path {i}')
        ymax = max(ymax, max(abs(flux[:-1])))

plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize=18)
plt.ylabel('$\Gamma^{odiv}$ (/m$^2$s)', fontsize=18)
plt.title('$\Gamma_{D^+}^{Odiv}$', fontsize=14)
plt.grid(True)
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
plt.legend(loc='best', fontsize=14)
plt.ylim([0, ymax])
plt.tight_layout()
plt.savefig('Gamma_odiv.png', dpi=300, bbox_inches='tight')
plt.show()

Te_odiv_max = []
plt.figure()
for i, path in enumerate(paths):
    if 'Te' in bbb_data[path]:
        Te = bbb_data[path]['Te']
        Te_odiv_max.append(max(Te[com_nx,:]))
        yyrb = com_data[path]['yyrb']
        plt.plot(yyrb, Te[com_nx, :-1], label=myleg[i] if i < len(myleg) else f'Path {i}')
Te_odiv_max  = np.array(Te_odiv_max)
plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize=18)
plt.ylabel('T$_e$ (eV)', fontsize=18)
plt.title('T$e^{Odiv}$')
plt.grid(True)
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
plt.legend(loc='best', fontsize=14)
plt.tight_layout()
plt.savefig('Te_odiv.png', dpi=300, bbox_inches='tight')
plt.show()


plt.figure()
for i, path in enumerate(paths):
    if 'ne' in bbb_data[path]:
        ne = bbb_data[path]['ne']
        ni = bbb_data[path]['ni']
        natom = bbb_data[path]['natom']
        yyrb = com_data[path]['yyrb']
        plt.plot(yyrb, ne[com_nx, :-1], label=myleg[i] if i < len(myleg) else f'Path {i}')

plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize=18)
plt.ylabel('n$_e$ (m$^{-3}$)', fontsize=18)
plt.title('n$e^{Odiv}$')
plt.grid(True)
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
plt.legend(loc='best', fontsize=14)
plt.tight_layout()
plt.savefig('ne_odiv.png', dpi=300, bbox_inches='tight')
plt.show()


plt.figure()
for i, path in enumerate(paths):
    if 'ne' in bbb_data[path]:
        ne = bbb_data[path]['ne']
        ni = bbb_data[path]['ni']
        natom = bbb_data[path]['natom']
        yyrb = com_data[path]['yyrb']
        plt.plot(yyrb, natom[com_nx, :-1], label=myleg[i] if i < len(myleg) else f'Path {i}')

plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize=18)
plt.ylabel('n$_{atom}$ (m$^{-3}$)', fontsize=18)
#plt.title('n$e^{Odiv}$')
plt.grid(True)
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
plt.legend(loc='best', fontsize=14)
plt.tight_layout()
plt.savefig('ne_odiv.png', dpi=300, bbox_inches='tight')
plt.show()



plt.figure()
for i, path in enumerate(paths):
    if 'up' in bbb_data[path]:
        up = bbb_data[path]['up']
        yyrb = com_data[path]['yyrb']
        plt.plot(yyrb, up[com_nx, :-1], label=myleg[i] if i < len(myleg) else f'Path {i}')
plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize=18)
plt.ylabel('u$_{||D+}$ (m/s)', fontsize=18)
plt.title('u$_{||D+}^{Odiv}$')
plt.grid(True)
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
plt.ylim([0, 6e4])
plt.legend(loc='best', fontsize=14)
plt.tight_layout()
plt.savefig('upara_odiv.png', dpi=300, bbox_inches='tight')
plt.show()


plt.figure()
for i, path in enumerate(paths):
    if 'Ti' in bbb_data[path]:
        Ti = bbb_data[path]['Ti']
        yyrb = com_data[path]['yyrb']
        plt.plot(yyrb, Ti[com_nx, :-1], label=myleg[i] if i < len(myleg) else f'Path {i}')

plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize=18)
plt.ylabel('T$_i$ (eV)', fontsize=18)
plt.title('T$i^{Odiv}$')
plt.grid(True)
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
plt.legend(loc='best', fontsize=14)
plt.tight_layout()
plt.savefig('Ti_odiv.png', dpi=300, bbox_inches='tight')
plt.show()



fnix_Odiv = []
fnix_Idiv = []

# Loop through each path and process the data
for i, path in enumerate(paths):
    if 'fnix' in bbb_data[path]:
        fnix = bbb_data[path]['fnix']
        fnix_Odiv.append(np.sum(fnix[com_nx - 1, :]))
        fnix_Idiv.append(np.abs(np.sum(fnix[0, :])))

fnix_Odiv = np.array(fnix_Odiv)
fnix_Idiv = np.array(fnix_Idiv)


fniy_core = []
fniy_ny = []
for i, path in enumerate(paths):
    if 'fniy' in bbb_data[path]:
        fniy = bbb_data[path]['fniy']
        fniy_core.append(np.sum(fniy[:, 0]))
        fniy_ny.append(np.abs(np.sum(fniy[:, com_ny-1])))
        
fniy_core = np.array(fniy_core)
fniy_ny = np.array(fniy_ny)

S_ion = []
S_rec = []
for i, path in enumerate(paths):
    if 'psor' in bbb_data[path]:
        psor = bbb_data[path]['psor']
        S_ion.append(np.sum(psor))
               
S_ion = np.array(S_ion)

for i, path in enumerate(paths):
    if 'psorrg' in bbb_data[path]:
        psorrg = bbb_data[path]['psorrg']
        S_rec.append(np.sum(psorrg))
               
S_rec= np.array(S_rec)

plt.figure()
plt.plot(Var, fnix_Odiv/1e23, line_style, linewidth=2, marker=marker, markersize=12, label='Odiv')
plt.plot(Var, fnix_Idiv/1e23, '--k', linewidth=2, marker='*', markersize=12, label='Idiv')
plt.plot(Var, fniy_core/1e23, '-.g', linewidth=2, marker='h', markersize=12, label='Core')
plt.plot(Var, S_ion/1e23, '-b', linewidth=2, marker='d', markersize=12, label='Ion')
plt.plot(Var, S_rec/1e23, '--m', linewidth=2, marker='<', markersize=12, label='Rec')

plt.ylabel('$\phi$ (1e23/s)', fontsize=18)
plt.xlabel('n$_{i}^{core-BC}$ (m$^{-3}$)', fontsize=18)
plt.grid(True)
plt.box(True)
plt.legend(loc='center', fontsize=14, ncol=2, title_fontsize='13')
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.ylim([0, 4])
plt.tight_layout()
plt.savefig('Particle.png', dpi=300, bbox_inches='tight')
plt.show()  


Prad_h = []
for i, path in enumerate(paths):
    if 'pradhyd' in bbb_data[path]:
        pradhyd = bbb_data[path]['pradhyd']
        vol = com_data[path]['vol']
        total_radiated_power = np.sum(pradhyd * vol)
        Prad_h.append(total_radiated_power)
        
Prad_h = np.array(Prad_h)


Prad_imp = []

for i, path in enumerate(paths):
    if 'prad' in bbb_data[path]:
        prad = bbb_data[path]['prad']
        vol = com_data[path]['vol']
        if prad.shape == vol.shape:
            total_radiated_power = np.sum(prad * vol)
        else:
           # print(f"Warning: Shapes of 'prad' and 'vol' are not compatible for element-wise multiplication at index {i}.")
            total_radiated_power = 0
            
        Prad_imp.append(total_radiated_power)

Prad_imp = np.array(Prad_imp)



fht_Odiv=[]
fht_Idiv=[]
for i, path in enumerate(paths):
    if 'feex' and 'feix' in bbb_data[path]:
        feex = bbb_data[path]['feex']
        feix = bbb_data[path]['feix']
        fht = abs(feex)+abs(feix)
        fht_Odiv.append(np.sum(fht[com_nx-1,:]))
        fht_Idiv.append(np.sum(fht[0,:]))
fht_Odiv = np.array(fht_Odiv)
fht_Idiv = np.array(fht_Idiv)

fht_ny = []
fht_core =[]
fht_sep =[]
for i, path in enumerate(paths):
    if 'feey' and 'feiy' in bbb_data[path]:
        feey = bbb_data[path]['feey']
        feiy = bbb_data[path]['feiy']
        fht = abs(feey)+abs(feiy)
        fht_ny.append(np.sum(fht[:,com_ny-2]))
        fht_sep.append(np.sum(fht[:,8]))
        fht_core.append(np.sum(fht[:,0]))
        
fht_ny = np.array(fht_ny)
fht_core = np.array(fht_core)
fht_sep = np.array(fht_sep)


mi = 3.3452e-27
eV= 1.6022e-19
ebind = 13.6

Kinetic_odiv = []
Kinetic_Idiv =[]
Pot_odiv = []
Pot_Idiv =[]

for i, path in enumerate(paths):
    if 'up' in bbb_data[path] and 'fnix' in bbb_data[path]:
        up = bbb_data[path]['up']
        fnix = bbb_data[path]['fnix']
        if up.shape[0] > com_nx and fnix.shape[0] > com_nx and up.shape[1] == fnix.shape[1]:
            Kinetic_odiv_value = 0.5 * mi * up[com_nx, :]**2 * fnix[com_nx-1, :]
            Kinetic_Idiv_value = 0.5 * mi * up[0, :]**2 * fnix[0, :]
            Pot_odiv_value =  fnix[com_nx-1, :]*ebind*eV
            Pot_Idiv_value =  fnix[0, :]*ebind*eV
            Kinetic_odiv.append(np.sum(np.abs(Kinetic_odiv_value)))
            Kinetic_Idiv.append(np.sum(np.abs(Kinetic_Idiv_value)))
            Pot_odiv.append(np.sum(np.abs(Pot_odiv_value)))
            Pot_Idiv.append(np.sum(np.abs(Pot_Idiv_value)))
            
        else:
            print(f"Warning: Index out of bounds for path {path}.")
    else:

        print(f"Warning: 'up' or 'fnix' not found for path {path}.")
        
Kinetic_odiv = np.array(Kinetic_odiv)
Kinetic_Idiv = np.array(Kinetic_Idiv)
Pot_odiv = np.array(Pot_odiv)
Pot_Idiv = np.array(Pot_odiv)


fht_Odiv = fht_Odiv+ Kinetic_odiv  + Pot_odiv  # plasma+ kinetic+potential 
fht_Idiv = fht_Idiv+ Kinetic_Idiv  + Pot_Idiv

Kinetic_wall = []
Pot_wall = []

for i, path in enumerate(paths):
    if 'up' in bbb_data[path] and 'fniy' in bbb_data[path]:
        up = bbb_data[path]['up']
        fniy = bbb_data[path]['fniy']
        if up.shape[0] > com_nx and fniy.shape[0] > com_nx and up.shape[1] == fniy.shape[1]:
            Kinetic_wall_value = 0.5 * mi * up[:, com_ny-1]**2 * fniy[:, com_ny-1]
            Pot_wall_value =  fniy[:, com_ny-1]*ebind*eV

            Kinetic_wall.append(np.sum(np.abs(Kinetic_wall_value)))

            Pot_wall.append(np.sum(np.abs(Pot_odiv_value)))

            
        else:
            print(f"Warning: Index out of bounds for path {path}.")
    else:

        print(f"Warning: 'up' or 'fnix' not found for path {path}.")
        
Kinetic_wall = np.array(Kinetic_wall)
Pot_wall = np.array(Pot_wall)

fht_ny = fht_ny+ Pot_wall + Kinetic_wall


plt.figure()
plt.plot(Var, fht_sep/1e6, '--c', linewidth=2, marker='<', markersize=12, label='P$_{SOL}$')
plt.plot(Var, (fht_Odiv)/1e6, line_style, linewidth=2, marker=marker, markersize=12, label='P$_{Odiv}$')
plt.plot(Var, (fht_Idiv)/1e6, '--k', linewidth=2, marker='*', markersize=12, label='P$_{Idiv}$')
plt.plot(Var, fht_ny/1e6, '-.g', linewidth=2, marker='h', markersize=12, label='P$_{Wall}$')
#plt.plot(Var, Prad_imp/1e6, '-b', linewidth=2, marker='d', markersize=12, label='P$_{Rad-Imp}$')
plt.plot(Var, Prad_h/1e6, '--m', linewidth=2, marker='<', markersize=12, label='P$_{Rad-H}$')
plt.ylabel('$q$ (MW)', fontsize=18)
plt.xlabel('I$_{puff}$ (A)', fontsize=18)
plt.grid(True)
plt.box(True)
plt.legend(loc='center', fontsize=14, ncol=3, title_fontsize='13')
#plt.legend(loc='best', fontsize=14, bbox_to_anchor=(1.05, 1))
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.ylim([0,6])
#plt.yscale('log')
plt.tight_layout()
plt.savefig('Power.png', dpi=300, bbox_inches='tight')
plt.show()  



   
P_balance = fht_sep - (fht_Odiv + fht_Idiv+ fht_ny+Prad_imp+Prad_h)
Error = P_balance/fht_sep

plt.figure()
plt.plot(Var, Error*100, '--c', linewidth=2, marker='<', markersize=12)
plt.xlabel('I$_{puff}$ (A)', fontsize=18)
plt.ylabel('Error (%)', fontsize=18)
plt.title("power balance", fontsize=18)
plt.grid(True)
plt.box(True)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
#plt.ylim([0, 4])
plt.tight_layout()
plt.savefig('Power_balance.png', dpi=300, bbox_inches='tight')
plt.show()  


###OMP ne vs, divertor heat flux

Gamma_odiv_max = []
for i, path in enumerate(paths):
    if 'qperp_odiv' in bbb_data[path]:
        fnix = bbb_data[path]['fnix']
        angfx = com_data[path]['angfx']
        sx = com_data[path]['sx']
        flux = abs(fnix[com_nx-1,:]*angfx[com_nx-1,:]/sx[com_nx-1,:])
        Gamma_odiv_max.append(max(flux))
Gamma_odiv_max  = np.array(Gamma_odiv_max)


ni_OMP = []
q_odiv_max =[]

for i, path in enumerate(paths):
    if 'ni' in bbb_data[path] and 'qperp_odiv' in bbb_data[path]:
        ni = bbb_data[path]['ni']
        q_odiv = bbb_data[path]['qperp_odiv']
        ni_OMP.append((ni[bbb_ixmp, com_iysptrx]))
        q_odiv_max.append(max( q_odiv))
ni_OMP = np.array(ni_OMP)
q_odiv_max = np.array(q_odiv_max)
plt.figure()
plt.plot(ni_OMP/1e19, q_odiv_max/1e6, '--r', linewidth=2, marker='<', markersize=12)
plt.xlabel('n$_{e,sep}^{OMP}$ (1e19 m$^{-3}$)', fontsize=18)
plt.ylabel('q$_{\perp, max}^{odiv}$ (MW/m$^2$)', fontsize=18)
plt.title('OMP ni Vs peak Odiv heat flux')
plt.grid(True)
plt.box(True)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.ylim([0, 40])
plt.tight_layout()
plt.savefig('Core_ne_q_odiv.png', dpi=300, bbox_inches='tight')
plt.show()  

plt.figure()
plt.plot(ni_OMP/1e19, Gamma_odiv_max/1e23, '--r', linewidth=2, marker='<', markersize=12)
plt.xlabel('n$_{i,sep}^{OMP}$ (1e19 m$^{-3}$)', fontsize=18)
plt.ylabel('$\Gamma_{max}^{odiv}$ (1e23/m$^2$s)', fontsize=18)
plt.title('OMP ni Vs peak Odiv particle flux')
plt.grid(True)
plt.box(True)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.ylim([0, 8])
plt.tight_layout()
plt.savefig('Core_ni_Gamma_odiv.png', dpi=300, bbox_inches='tight')
plt.show()  

Te_odiv_max = []
for i, path in enumerate(paths):
    if 'Te' in bbb_data[path]:
        Te = bbb_data[path]['Te']
        Te_odiv_max.append(max(Te[com_nx,:]))       
Te_odiv_max  = np.array(Te_odiv_max)


plt.figure()
plt.plot(ni_OMP/1e19, Te_odiv_max, '--r', linewidth=2, marker='<', markersize=12)
plt.xlabel('n$_{i,sep}^{OMP}$ (1e19 m$^{-3}$)', fontsize=18)
plt.ylabel('$T_{e,max}^{odiv}$ (eV)', fontsize=18)
plt.title('OMP ni Vs peak Odiv T_e')
plt.grid(True)
plt.box(True)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.ylim([0, 200])
plt.tight_layout()
plt.savefig('Core_ni_Te_odiv.png', dpi=300, bbox_inches='tight')
plt.show()  

plt.figure()
plt.plot(Var, Gamma_odiv_max/1e23, '--r', linewidth=2, marker='<', markersize=12)
plt.xlabel('I$_{GP}$ (A)', fontsize=18)
plt.ylabel('$\Gamma_{max}^{odiv}$ (1e23/m$^2$s)', fontsize=18)
plt.title('Peak Odiv particle flux vs gas puff')
plt.grid(True)
plt.box(True)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.ylim([0, 8])
plt.tight_layout()
plt.savefig('Gas_puff_Gamma_odiv.png', dpi=300, bbox_inches='tight')
plt.show() 

# ###Li case
# sputflxrb = np.array([0.00000000e+00, 0.00000000e+00, 0.00000000e+00, 0.00000000e+00,
#        0.00000000e+00, 0.00000000e+00, 0.00000000e+00, 0.00000000e+00,
#        0.00000000e+00, 2.80064155e+20, 2.31841895e+21, 9.88541921e+21,
#        1.73292896e+22, 2.08246342e+22, 2.17966619e+22, 2.10666436e+22,
#        1.91452944e+22, 1.65844092e+22, 1.36190670e+22, 1.07066686e+22,
#        8.21896475e+21, 6.33840480e+21, 4.92764200e+21, 3.59906750e+21,
#        1.17513877e+21, 0.00000000e+00])

# n_Li_atom = np.array([5.33360617e+13, 5.23149275e+13, 3.52233783e+13, 1.97033332e+13,
#        1.32945292e+13, 1.88964068e+13, 3.04992907e+13, 3.19719114e+13,
#        1.81176188e+13, 1.54267796e+14, 6.45644207e+14, 1.68864160e+15,
#        2.62544046e+15, 3.40403310e+15, 4.20428364e+15, 4.78710538e+15,
#        4.98550130e+15, 4.77194089e+15, 4.33580141e+15, 3.88148247e+15,
#        3.62339386e+15, 3.67120895e+15, 4.15662934e+15, 5.25153226e+15,
#        5.04174281e+15, 1.11239121e+16])

# plt.figure()
# flux = fnix[com_nx-1,:]*angfx[com_nx-1,:]/sx[com_nx-1,:]
# plt.plot(yyrb,  -1*flux[:-1], linewidth=2, label='$\Gamma_D+$')
# plt.plot(yyrb, sputflxrb[:-1],linewidth=2, label='$\Gamma_{Li}^{sput}$')
# ymax = max(ymax, max(abs(flux[:-1])))
# plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize=18)
# plt.ylabel('$\Gamma^{odiv}$ (/m$^2$s)', fontsize=18)
# plt.title('$\Gamma^{Odiv}$', fontsize=14)
# plt.grid(True)
# plt.xticks(fontsize=14) 
# plt.yticks(fontsize=14) 
# plt.legend(loc='best', fontsize=14)
# #plt.ylim([0, ymax])
# plt.tight_layout()
# plt.yscale('log')
# plt.savefig('Gamma_Li_sput.png', dpi=300, bbox_inches='tight')
# plt.show()

# Yield = sputflxrb/abs(flux)

# plt.figure()

# plt.plot(yyrb,  Yield[:-1], linewidth=2, label='$Yield$')
# plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize=18)
# plt.ylabel('Y$_{PS}^{D on Li}$', fontsize=18)
# plt.grid(True)
# plt.xticks(fontsize=14) 
# plt.yticks(fontsize=14) 
# plt.legend(loc='best', fontsize=14)
# #plt.ylim([0, ymax])
# plt.tight_layout()
# #plt.yscale('log')
# plt.savefig('Y_Li_sput.png', dpi=300, bbox_inches='tight')
# plt.show()


# Kappal=3 # sheath potential through entrace
# mi = 1.1708e-26
# zi= 1

# Energy = (0.5*mi*up[com_nx,:]**2)/1.6022e-19 + Ti[com_nx,:] + zi*Kappal*Te[com_nx,:]

# plt.figure()
# plt.plot(yyrb, Energy[:-1], label='Energy', linewidth=2)
# plt.xlabel('r$_{div} - r_{sep}$ (m)', fontsize=18)
# plt.ylabel('Energy (eV)', fontsize=18)
# plt.title('Odiv', fontsize=18)
# plt.xticks(fontsize=14) 
# plt.yticks(fontsize=14) 
# #plt.ylim([0, 1.6])
# #plt.yscale('log')
# plt.legend(loc='best', fontsize=22)
# plt.grid(True)
# plt.savefig('Energy.png', dpi=300, bbox_inches='tight')
# plt.show()

# q = 0.16
# E_th = 6.92  # eV
# ETF = 209  # eV
# E_sb = 1.67  # eV

# # Incident ion energy range
# E = np.linspace(6.93, 500, 1000)
# E_reduced = E / ETF

# # Calculations
# part_1 = 1 - ((E_th / E)**(2 / 3))
# part_2 = (1 - (E_th / E))**2

# s_n_numerator = 3.441 * np.sqrt(E_reduced) * np.log(E_reduced + 2.718)
# s_n_denominator = 1 + 6.355 * np.sqrt(E_reduced) + E_reduced * (6.882 * np.sqrt(E_reduced) - 1.708)
# s_n = s_n_numerator / s_n_denominator

# Y_Li = q * s_n * part_1 * part_2

# # Plotting
# plt.figure()
# plt.plot(E, Y_Li, linewidth=2)
# plt.ylabel('Y$_{D,Li}^{ps}$ (atoms/ions)',fontsize=18)
# plt.xlabel('E (eV)',fontsize=18)
# plt.title('Yield of Lithium Atoms as a Function of Incident Ion Energy')
# plt.grid(True)
# plt.xlim([0, 100])
# plt.ylim([0, 0.1])
# plt.xticks(fontsize=14) 
# plt.yticks(fontsize=14) 
# plt.savefig('SPut_rate.png', dpi=300, bbox_inches='tight')
# plt.show()



# zm= com_data[path]['zm']
# zm1 = com_data[path]['zm1']
# zm2 = com_data[path]['zm2']
# zm3 = com_data[path]['zm3']
# zm4 = com_data[path]['zm4']
   
# rm = com_data[path]['rm']
# rm1 = com_data[path]['rm1']
# rm2 = com_data[path]['rm2']
# rm3 = com_data[path]['rm3']
# rm4 = com_data[path]['rm4']

# zm_3d = np.stack([zm, zm1, zm2, zm3, zm4], axis=2)
# rm_3d = np.stack([rm, rm1, rm2, rm3, rm4], axis=2)

# patches = []  
# for iy in range(com_ny+1):
#     for ix in range(com_nx+1):
#         rcol = rm_3d[ix, iy, [1, 2, 4, 3]]
#         zcol = zm_3d[ix, iy, [1, 2, 4, 3]] 
#         polygon = Polygon(np.column_stack((rcol, zcol)), True)
#         patches.append(polygon)
  
# fig, ax = plt.subplots(figsize=(8, 6))
# contour_filled = ax.contourf(rm, zm, natom, cmap='viridis')
# contour_lines = ax.contour(rm, zm, natom, colors='black', levels=10)  # Adjust levels as needed
# cbar = plt.colorbar(contour_filled, ax=ax, label='n$_{Li^0}$ (m$^{-3}$)')
# ax.set_xlabel('Z (m)', fontsize=18)
# ax.set_ylabel('r (m)', fontsize=18)
# ax.set_title('Contour Plot of n$_{Li^0}$', fontsize=18)
# ax.tick_params(axis='both', which='major', labelsize=14)
# plt.savefig('2DLiatom_contour.png', dpi=300, bbox_inches='tight')
# plt.show()


# plt.figure()

# for iy in np.arange(0,com_ny+1):
#     for ix in np.arange(0,com_nx+1):
#         plt.plot(rm_3d[ix,iy,[1,2,4,3,1]],
#                  zm_3d[ix,iy,[1,2,4,3,1]], 
#                  color="black", linewidth=0.5)
# plt.xlabel('R [m]')
# plt.ylabel('Z [m]')
# plt.grid(True)
# plt.axes().set_aspect('equal', 'datalim')
# plt.show()

# fig = plt.figure(figsize=(12, 10))
# ax = fig.add_subplot(111, projection='3d')

#for iy in range(com_ny+1):
 #   for ix in range(com_nx+1):
 #       x = rm_3d[ix, iy, [1, 2, 4, 3, 1]]
 #       y = zm_3d[ix, iy, [1, 2, 4, 3, 1]]
 #       X, Y = np.meshgrid(x, y)
 #       Z = natom[ix, iy] * np.ones_like(X)  
 #       contour = plt.contourf(X, Y, natom, cmap='viridis', levels=20)
 #       plt.colorbar(contour, label='n$_{atom}$')
#ax.set_xlabel('R [m]')
#ax.set_ylabel('Z [m]')
#ax.set_zlabel('n$_{atom}$')
#ax.set_aspect('auto')

#plt.show()





