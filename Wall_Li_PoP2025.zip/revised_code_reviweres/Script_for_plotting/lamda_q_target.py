import sys
import math
from scipy.special import erfc
from scipy.special import erfc
import itertools
import scipy.optimize
from scipy.special import erfc, erfcx
from scipy.interpolate import interp1d
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy import integrate
from uedge import *
import uedge_mvu.plot as mp
import uedge_mvu.utils as mu
import uedge_mvu.analysis as mana
import UEDGE_utils.analysis as ana
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from runcase import *



setGrid()
setPhysics(impFrac=0,fluxLimit=True)
setDChi(kye=0.7, kyi=0.2, difni=0.5,nonuniform = True)
setBoundaryConditions(ncore=1.2e19, pcoree=3.0e6, pcorei=3.0e6, recycp=0.98)
setimpmodel(impmodel=True,sput_factor=1e-0)


#-non-orthogonal grid settings
isnonog=1
methg=66
bbb.lenpfac=120

bbb.cion=3
bbb.oldseec=0
bbb.restart=1
bbb.nusp_imp = 3


bbb.oldseec=0
bbb.restart=1
hdf5_restore("./final.hdf5")
bbb.ftol=1e20
bbb.ftol=1e20;bbb.issfon=0; bbb.exmain()

kwargs = {'color': 'red', 'fontsize': 16}


psurfo = ana.PsurfOuter()  # q_perp 
qsurfo = psurfo[1:-1] / com.sxnp[com.nx + 1, 1:-1]
target_heat = qsurfo
q_max = np.max(target_heat)
y_data = target_heat
q0 = q_max 

lambda_cal = 0.63*(com.bpol[bbb.ixmp,:,0])**(-1.19)
ave_lam_OMP = np.average(lambda_cal)

print("---$\lambda_q$ = 0.63*B$_{pol,OMP}^-1.19$---")
print("Lambda_q at OMP Midplane mm", ave_lam_OMP)

fx_cal = com.bpol[bbb.ixmp,com.iysptrx,0]*0.85/(com.bpol[com.nx,com.iysptrx,0]*0.85)
print("flux espansion fun is :", np.mean(fx_cal))

x_data =com.yyc[1:-1] ### r_omp - r_sep

x_data = com.yyrb[1:-1]
x_data= x_data.reshape(-1)

print('size of x_data', len(x_data))
print('size of y data', len(y_data))

def eichFunction(x, S, lq, q0, s0):
    fx = 7.2 #np.mean(fx_cal) #30 # Value of fx
    sBar = x - s0
    t0 = (S / (2 * lq * fx))**2
    t1 = sBar / (lq * fx)
    t2 = S / (2 * lq * fx)
    t3 = sBar / S
    qback = q0/80
    return (q0 / 2) * np.exp(t0 - t1) * erfc(t2 - t3)+qback

# Initial guess for the parameters [S, lq, q0, s0]
initial_guess = [1.0, 2, np.max(y_data), 0]

popt, pcov = curve_fit(eichFunction, x_data, y_data, p0=initial_guess)

S_opt, lq_opt, q0_opt, s0_opt = popt

print("lamda q is :", lq_opt)


x_fit = np.linspace(min(x_data), max(x_data), 10000)
y_fit = eichFunction(x_fit, *popt)

plt.scatter(x_data, y_data/1e6, color='red', label='UEDGE')
plt.plot(x_fit, y_fit/1e6, color='blue', label='Eich Fitted')
plt.ylabel('q$_{\perp}$ (MW/m$^2$)', fontsize=16)
plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize=16)
plt.legend(fontsize=16)
plt.text(x_data[15], np.max(y_data)/5e6, f'$\lambda_q$ mm ={lq_opt*1e3:.3f}', fontsize=12, color='black')
plt.title('Eich fit, target coordinates', fontsize=16)
plt.grid(True)
plt.savefig('Eich_fit.png', dpi=300, bbox_inches='tight')
plt.show()




