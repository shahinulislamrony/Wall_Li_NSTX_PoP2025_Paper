import numpy as np
import matplotlib.pyplot as plt

Power_core =1e+04 #W
Power_inner_wall = 1142 #kW
Recomb_power_inner_wall =29.64 #kW
Power_outer_wall =  1226 #kW
Recomb_power_outer_wall =  22.17 #kW
Power_entering_outer_leg =  3065 #kW
Recomb_power_entering_outer_leg: 96.13 #kW
Power_entering_inner_leg =  1737 #kW
Recomb_power_entering_inner_leg = 78.01 #kW


fangle =np.array([0.81611186, 0.7723902 , 0.69527584, 0.63330423, 0.59172619,
       0.5667284 , 0.55726562, 0.56004184, 0.57135042, 0.60919825,
       0.70216924, 0.83530364, 0.99820568, 1.1820282 , 1.38919899,
       1.63278844, 1.88831669, 2.16423215, 2.50124627, 2.85037922,
       3.22755096, 3.65833106, 4.1227272 , 4.60789368, 5.18910015,
       5.43530802])
yyrb = np.array([-0.09580207, -0.0883297 , -0.07360328, -0.05940535, -0.04597069,
       -0.03356609, -0.02240577, -0.01260851, -0.00402888,  0.00984205,
        0.03007019,  0.04991498,  0.06846575,  0.08608859,  0.10297708,
        0.1194364 ,  0.13546967,  0.15123152,  0.1666732 ,  0.18186758,
        0.19708181,  0.21228164,  0.22750439,  0.2429528 ,  0.25864637,
        0.26654581])

plt.figure(figsize=(4, 3))
plt.plot(yyrb, fangle)
plt.xlabel('r$_{div}$ - r$_{sep}$ (m)', fontsize=18)
plt.ylabel(r'$\alpha$ ($^\circ$)',fontsize=18)
plt.title('Odiv', fontsize=16)
plt.grid(True)
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
plt.tight_layout()
plt.show()