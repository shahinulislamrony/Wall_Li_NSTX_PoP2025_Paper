import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os



datasets = [

   
   {
    'path': r'C:\UEDGE_run_Shahinul\NSTX_U\SOFE\SOFE\nsep_5.7e19_for_power_scan\PePi11MW',
    'nx':45,
    'dt': 10e-3,
    'label_tsurf': 'P$_{in}$: 10MW'
},
]

y = np.array([-0.09580207462684603,
-0.08832970240356444,
-0.0736032835946869,
-0.05940535145149375,
-0.04597068542798662,
-0.03356608683338166,
-0.022405774195931892,
-0.012608512173608828,
-0.004028876066202621,
0.009842046169595279,
0.030070191968999637,
0.04991497946182823,
0.06846574719291333,
0.08608859016189475,
0.10297707708342747,
0.11943639570806182,
0.1354696686903838,
0.15123151946826402,
0.1666731989874109,
0.18186758091031596,
0.19708180838227363,
0.2122816417631439,
0.22750439039645876,
0.2429527986507295,
0.25864637285072395,
0.2665458144169497,
])
# Colormap
cmap = plt.get_cmap('turbo')

# Create a figure and axis
fig, ax = plt.subplots()

for dataset in datasets:
    data_path = dataset['path']
    nx = dataset['nx']
    
    max_value_tsurf = []
    max_q = []

    q_perp_dir = os.path.join(data_path, 'q_perp')
    T_surf_dir = os.path.join(data_path, 'Tsurf_Li')

    # Loop through nx values
    for i in range(1, nx + 1):  # Adjust range if data indexing starts differently
        filename_tsurf = os.path.join(T_surf_dir, f'T_surfit_{i}.0.csv')
        filename_qsurf = os.path.join(q_perp_dir, f'q_perpit_{i}.0.csv')

        try:
            # Load T_surf data
            df_tsurf = pd.read_csv(filename_tsurf)
            max_tsurf = np.max(df_tsurf.values)
            max_value_tsurf.append(max_tsurf)

            # Load q_perp data
            df_qsurf = pd.read_csv(filename_qsurf)
            q_data = df_qsurf
            max_q_i = np.max(df_qsurf.values)
            max_q.append(max_q_i)
        except FileNotFoundError:
            print(f"Files for i={i} not found. Skipping...")

    norm = plt.Normalize(1, np.max(max_value_tsurf))

    # Plotting
    for i in range(len(max_value_tsurf)):
        color = cmap(norm(max_value_tsurf[i]))
        ax.plot(y[:-1], q_data/1e6, linewidth=2, marker='*', color=color, 
                label=f'Path {i+1} {dataset["label_tsurf"]}')

# Add colorbar
sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
sm.set_array([])  # Only needed for older versions of matplotlib
cbar = fig.colorbar(sm, ax=ax)
cbar.set_label('$T_{surf}^{max}$ (C)', fontsize=14)

# Labels and grid
ax.set_xlabel("r$_{div}$ - r$_{sep}$ (m)", fontsize=16)
ax.set_ylabel("q$_{\perp}^{Odiv}$ (MW/m$^2$)", fontsize=20)
ax.tick_params(axis='both', labelsize=16)
ax.grid(True)
plt.tight_layout()
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.ylim([0, 5])

# Save and show plot
plt.savefig('Iteration_vs_heat.png', dpi=300)
plt.show()