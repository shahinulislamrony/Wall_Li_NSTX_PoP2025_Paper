import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.patches import Polygon


paths = [
   r'C:\Users\islam9\OneDrive - LLNL\Desktop\NSTX-U_g116313\Case_for_02132024_meeting\PePi6MW_Dn0.35Chi0.5_utstep_ph2_data_analysis',

]


#Var = np.array([5.7,5.9,6.1,6.3,6.5,6.7,6.9,7.1,7.3,7.5,8,8.5,9,9.5,10,10.5,11,11.5,12,12.5])
#myleg = [ 'Cont', 'Jeremy', 'Shahinul', 'Canik', 'Meier']
com_nx=104; com_ny=24
bbb_ixmp = 67; com_iysptrx=8;
com_ixpt=12; com_oxpt2=92;
bbb_ev = 1.6022e-19

marker = 'o' 
line_style = '-.sr' 




def read_csv(filepath):
    try:
        return pd.read_csv(filepath).values
    except Exception as e:
        print(f"Error reading {filepath}: {e}")
        return None

com_data = {}
bbb_data = {}

for path in paths:
    com_data[path] = {
        'vol': read_csv(os.path.join(path, 'vol.csv')),
        'rm': read_csv(os.path.join(path, 'rm.csv')),
        'rm1': read_csv(os.path.join(path, 'rm1.csv')),
        'rm2': read_csv(os.path.join(path, 'rm2.csv')),
        'rm3': read_csv(os.path.join(path, 'rm3.csv')),
        'rm4': read_csv(os.path.join(path, 'rm4.csv')),
        'yyrb': read_csv(os.path.join(path, 'yyrb.csv')),
        'yylb': read_csv(os.path.join(path, 'yylb.csv')),
        'yyc': read_csv(os.path.join(path, 'yyc.csv')),
        'zm': read_csv(os.path.join(path, 'zm.csv')),
        'zm1': read_csv(os.path.join(path, 'zm1.csv')),
        'zm2': read_csv(os.path.join(path, 'zm2.csv')),
        'zm3': read_csv(os.path.join(path, 'zm3.csv')),
        'zm4': read_csv(os.path.join(path, 'zm4.csv')),
        'angfx': read_csv(os.path.join(path, 'angfx.csv')),
        'sx': read_csv(os.path.join(path, 'sx.csv')),
        'sy': read_csv(os.path.join(path, 'sy.csv'))
    }

    bbb_data[path] = {
        'Te': read_csv(os.path.join(path, 'te.csv')),
        'Ti': read_csv(os.path.join(path, 'ti.csv')),
        'ne': read_csv(os.path.join(path, 'ne.csv')),
        'ni': read_csv(os.path.join(path, 'ni.csv')),
        
        'niLi1': read_csv(os.path.join(path, 'nLi1.csv')),
        'niLi2': read_csv(os.path.join(path, 'nLi2.csv')),
        'niLi3': read_csv(os.path.join(path, 'nLi3.csv')),
        'sput': read_csv(os.path.join(path, 'sput.csv')),
        
        'natom': read_csv(os.path.join(path, 'natom.csv')),
        'uup': read_csv(os.path.join(path, 'uup.csv')),
        'up': read_csv(os.path.join(path, 'up.csv')),
        
        'upLi1': read_csv(os.path.join(path, 'upLi1.csv')),
        'upLi2': read_csv(os.path.join(path, 'upLi2.csv')),
        'upLi3': read_csv(os.path.join(path, 'upLi3.csv')),
        
        'feex': read_csv(os.path.join(path, 'feex.csv')),
        'feix': read_csv(os.path.join(path, 'feix.csv')),
        'fnix': read_csv(os.path.join(path, 'fnix.csv')),
        'fnix_neu': read_csv(os.path.join(path, 'fnix_neu.csv')),
        'fniy_neu': read_csv(os.path.join(path, 'fniy_neu.csv')),
        'pri': read_csv(os.path.join(path, 'pri.csv')),
        'pre': read_csv(os.path.join(path, 'pre.csv')),
        'pr': read_csv(os.path.join(path, 'pr.csv')),
        'fniy': read_csv(os.path.join(path, 'fniy.csv')),
        'feey': read_csv(os.path.join(path, 'feey.csv')),
        'feiy': read_csv(os.path.join(path, 'feiy.csv')),
        'erlrc': read_csv(os.path.join(path, 'erlrc.csv')),
        'erliz': read_csv(os.path.join(path, 'erliz.csv')),
        'pradhyd': read_csv(os.path.join(path, 'pradhyd.csv')),
        'psor': read_csv(os.path.join(path, 'psor.csv')),
        'psorrg': read_csv(os.path.join(path, 'psorrg.csv')),
        'prad': read_csv(os.path.join(path, 'prad.csv')),
        'qpar': read_csv(os.path.join(path, 'q_para.csv')),
        'qpar_odiv': read_csv(os.path.join(path, 'q_para_odiv.csv')),
        'qperp_odiv': read_csv(os.path.join(path, 'q_perp_div.csv')),
        'q_odiv': read_csv(os.path.join(path, 'q_odiv.csv')),
        'kye': read_csv(os.path.join(path, 'kye.csv')),
        'dif': read_csv(os.path.join(path, 'dif.csv')),
        
        
    }
    
for i, path in enumerate(paths):
    if 'Te' in bbb_data[path]:  # Check if 'Te' is in the current path's data
        Te = bbb_data[path]['Te']
        ne = bbb_data[path]['ne']
        ni = bbb_data[path]['ni']
        Ti = bbb_data[path]['Ti']
        up = bbb_data[path]['up']
        fnix = bbb_data[path]['fnix']
        sput = bbb_data[path]['sput']
        yyrb = com_data[path]['yyrb']

# if (isph_sput(igsp) .ge. 1) then  # use fits for phys sput
#                    do ifld = ipsputt_s, ipsputt_e 
#                      eng_sput = ( 0.5*mi(ifld)*up(ixt,iy,ifld)**2 + 
#      .                            ti(ixt,iy) +  zi(ifld)*
#      .                            kappal(iy,jx)*te(ixt,iy) )/ev


Kappal=3 # sheath potential through entrace
mi = 1.1708e-26
zi= 1
ev = 1.6022e-19
sput = sput.reshape(-1)
Y_ps = sput/fnix[com_nx-1,:-1]

# Y_ps_57e18 = np.array([0.        , 0.01447188, 0.01698457, 0.01879606, 0.02017134,
#        0.02122715, 0.02258428, 0.02676668, 0.03598021, 0.04599086,
#        0.04601853, 0.0460411 , 0.0458344 , 0.04378638, 0.04049019,
#        0.0375014 , 0.03613374, 0.03620574, 0.03667398, 0.03669692,
#        0.03587806, 0.03372703, 0.02835166, 0.01606106, 0.00340194,
#        0.        ])


Y_ps = np.array([0.        , 0.00485806, 0.00660479, 0.00738189, 0.00786787,
       0.00863202, 0.01120384, 0.01827377, 0.03097668, 0.04467717,
       0.04479999, 0.04416589, 0.0426361 , 0.04017119, 0.03674964,
       0.03209956, 0.02599572, 0.01914748, 0.01440177, 0.01222012,
       0.01199561, 0.01246531, 0.01120098, 0.00600229, 0.00092791,
       0.        ])

Phy_sput = np.array([0.000000000000000000e+00,
5.412680226356326400e+17,
1.969077394704222464e+18,
6.073953155095811072e+18,
1.553993744244441702e+19,
3.443904930550669722e+19,
7.584312949119270912e+19,
2.096940648205286769e+20,
8.007972034675698565e+20,
4.667818601729832255e+21,
5.110095207067647214e+21,
5.584809616337012785e+21,
6.202058831703558849e+21,
6.811802203679681937e+21,
7.200669570727759839e+21,
6.995385205779718996e+21,
5.957900306141348364e+21,
4.683078267041917960e+21,
3.776373877653137523e+21,
3.352130556453875876e+21,
2.932684555278221312e+21,
2.377112457440769606e+21,
1.504129572726742188e+21,
4.561003628445514465e+20,
3.510458755015177830e+19,
0.000000000000000000e+00,])


Y = Phy_sput / fnix[com_nx,:]
plt.figure()
plt.plot(yyrb[:-1], Y_ps[1:-1], linewidth=2)
plt.xlabel('r$_{div} - r_{sep}$ (m)', fontsize=18)
plt.ylabel('Yps ', fontsize=18)
plt.title('Odiv', fontsize=18)
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
#plt.ylim([0, 1.6])
#plt.yscale('log')
plt.legend(loc='best', fontsize=22)
plt.grid(True)
plt.savefig('Energy.png', dpi=300, bbox_inches='tight')
plt.show()

Energy = (0.5*mi*up[com_nx,:]**2 + Ti[com_nx,:] + zi*Kappal*Te[com_nx,:])

plt.figure()
plt.plot(yyrb, Energy[:-1], linewidth=2)
plt.xlabel('r$_{div} - r_{sep}$ (m)', fontsize=18)
plt.ylabel('Energy (eV)', fontsize=18)
plt.title('Odiv', fontsize=18)
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
#plt.ylim([0, 1.6])
#plt.yscale('log')
plt.title(r'$\frac{1}{2} mu^2 + (T_i + K T_e)$', fontsize=14)
#plt.legend(loc='best', fontsize=22)
plt.grid(True)
plt.savefig('Energy.png', dpi=300, bbox_inches='tight')
plt.show()


q = 0.16
E_th = 6.92  # eV
ETF = 209  # eV
E_sb = 1.67  # eV

# Incident ion energy range
E = np.linspace(6.93, 500, 1000)
E_reduced = E / ETF

# Calculations
part_1 = 1 - ((E_th / E)**(2 / 3))
part_2 = (1 - (E_th / E))**2

s_n_numerator = 3.441 * np.sqrt(E_reduced) * np.log(E_reduced + 2.718)
s_n_denominator = 1 + 6.355 * np.sqrt(E_reduced) + E_reduced * (6.882 * np.sqrt(E_reduced) - 1.708)
s_n = s_n_numerator / s_n_denominator

Y_Li = q * s_n * part_1 * part_2

# Plotting
plt.figure()
plt.plot(E, Y_Li, linewidth=2)
plt.ylabel('Y$_{D,Li}^{ps}$ (atoms/ions)',fontsize=18)
plt.xlabel('E (eV)',fontsize=18)
plt.title('Yield of Lithium Atoms as a Function of Incident Ion Energy')
plt.grid(True)
plt.xlim([0, 200])
plt.ylim([0, 0.1])
plt.xticks(fontsize=14) 
plt.yticks(fontsize=14) 
plt.savefig('SPut_rate.png', dpi=300, bbox_inches='tight')
plt.show()