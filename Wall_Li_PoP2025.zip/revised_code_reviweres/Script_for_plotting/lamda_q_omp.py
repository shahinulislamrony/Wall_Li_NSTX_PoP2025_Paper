import numpy as np
import scipy.optimize
from scipy.special import erfc
import matplotlib.pyplot as plt
import sys
import math
from scipy.special import erfc
from scipy.special import erfc
import itertools
import scipy.optimize
from scipy.special import erfc, erfcx
from scipy.interpolate import interp1d
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy import integrate
from uedge import *
import uedge_mvu.plot as mp
import uedge_mvu.utils as mu
import uedge_mvu.analysis as mana
import UEDGE_utils.analysis as ana
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from runcase import *



setGrid()
setPhysics(impFrac=0,fluxLimit=True)
setDChi(kye=0.7, kyi=0.2, difni=0.5,nonuniform = True)
setBoundaryConditions(ncore=7.44e19, pcoree=3.0e6, pcorei=3.0e6, recycp=0.98)
setimpmodel(impmodel=True,sput_factor=1e-0)


#-non-orthogonal grid settings
isnonog=1
methg=66
bbb.lenpfac=120

bbb.cion=3
bbb.oldseec=0
bbb.restart=1
bbb.nusp_imp = 3


bbb.oldseec=0
bbb.restart=1
hdf5_restore("./final.hdf5")
bbb.ftol=1e20
bbb.ftol=1e20;bbb.issfon=0; bbb.exmain()

kwargs = {'color': 'red', 'fontsize': 16}


# Compute target heat flux
#target_heat = ana.qsurfparOuter()
#target_heat = target_heat[:-1]
#q_max = np.max(target_heat)
#print("Heat flux (max):", q_max)

psurfo = ana.qsurfparOuter() #ana.PsurfOuter(), q_perp
qsurfo = psurfo[1:-1]#/com.sxnp[com.nx+1,1:-1]
target_heat = qsurfo
q_max = np.max(target_heat)
print("Heat flux (max):", q_max)

# x_data (radial coordinates) and y_data (heat flux)
x_data = com.yyc[1:-1]
y_data = target_heat

# Empirical calculation of λ_q at OMP
lambda_cal = 0.63 * (com.bpol[bbb.ixmp, :, 0]) ** -1.19
ave_lam_OMP = np.average(lambda_cal)
print("--- λ_q = 0.63 * B_pol,OMP^-1.19 ---")
print(f"λ_q at OMP Midplane (mm): {ave_lam_OMP:.3f}")

lam = ana.eichFitOuter()
print('lambda_q is :', lam)

# Define the Eich model
def qEich(rho, q0, S, lq, qbg, rho_0):
    rho = rho - rho_0
    return q0 / 2 * np.exp((S / (2*lq)) ** 2 - rho / lq) * erfc(S / (2 *lq) - rho / S) + qbg

# Fit the Eich model
def eichFitOuter(lqoGuess=1, x_data=None, y_data=None):
    if x_data is None or y_data is None:
        raise ValueError("x_data and y_data must be provided.")
    
    bounds = ([0, 1e-9, 1e-9, 0, np.min(x_data)], [np.inf, np.inf, np.inf, np.inf, np.max(x_data)])
    oguess = (np.max(y_data) - np.min(y_data[y_data > 0]), lqoGuess / 1000 / 2, lqoGuess / 1000, np.min(y_data[y_data > 0]), np.mean(x_data))
    
    try:
        popt, pcov = scipy.optimize.curve_fit(qEich, x_data, y_data, p0=oguess, bounds=bounds)
        lqeo, So = popt[2], popt[1]
        lqeo_err, So_err = np.sqrt(np.diag(pcov))[2], np.sqrt(np.diag(pcov))[1]
        return popt, (lqeo, So, lqeo_err, So_err)
    except Exception as e:
        print("Fitting failed:", e)
        return None, (None, None, None, None)

# Plotting function
def plotEichFit(x_data, y_data, popt):
    if popt is None:
        print("Invalid fit parameters. Skipping plot.")
        return
    
    x_fit = np.linspace(np.min(x_data), np.max(x_data), 1000)
    y_fit = qEich(x_fit, *popt)

    plt.figure(figsize=(6, 4))
    plt.scatter(x_data, y_data / 1e6, color='red', label='UEDGE')
    plt.plot(x_fit, y_fit / 1e6, color='blue', label='Eich Fit')
    plt.ylabel('q$_{||}$ (MW/m$^2$)', fontsize=16)
    plt.xlabel('r$_{sep}$ - r$_{omp}$ (m)', fontsize=16)
    plt.legend(fontsize=16)
    plt.xticks(fontsize=14) 
    plt.yticks(fontsize=14)
    ymax = 180# q_max/1e6
    plt.ylim([0, ymax])
    plt.xlim([-0.015, 0.015])
    plt.title(f'Eich Fitted -λ$_q$: {(lqeo * 1e3):.2f} mm', fontsize=16)
    #plt.text(0.0, 10, f"\nλ$_q$: {(lqeo*1e3):.5f} (mm)")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig('Eich_fit_omp.png', dpi=300, bbox_inches='tight')
    plt.show()

# Perform the fit
popt, (lqeo, So, lqeo_err, So_err) = eichFitOuter(lqoGuess=2, x_data=x_data, y_data=y_data)

# Output results
if popt is not None:
    print(f"Fit Results:\nλ_q (m): {lqeo:.5f} ± {lqeo_err:.5f}\nS (m): {So:.5f} ± {So_err:.5f}")

# Plot results
plotEichFit(x_data, y_data, popt)
