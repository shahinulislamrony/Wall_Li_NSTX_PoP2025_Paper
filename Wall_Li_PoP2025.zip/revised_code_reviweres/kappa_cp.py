# -*- coding: utf-8 -*-
"""
Created on Fri Jul 11 08:52:54 2025
@author: islam9
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

# -----------------------
# Experimental Graphite data (for thermal conductivity fit)
# -----------------------
T_exp = np.array([0, 25, 125, 300, 425, 600, 725, 1200, 1225, 1725, 2000])  # °C
K_exp = np.array([105.26, 102.56, 93.02, 80.0, 72.73, 64.52, 59.70, 46.51, 45.98, 37.38, 33.90])  # W/m·K


def quadratic_func(T, a, b, c):
    return a * T**2 + b * T + c


popt, _ = curve_fit(quadratic_func, T_exp, K_exp)
a, b, c = popt

def C_thermal_conductivity(T):
    return a * T**2 + b * T + c


def Li_rho(T_C):
    T_K = T_C + 273.15
    return 562 - 0.10 * T_K  # kg/m³

def Li_thermal_conductivity(T_C):
    T_K = T_C + 273.15
    if 200 < T_K < 453:
        return 44 + 0.02019 * T_K + 8037 / T_K
    else:
        return 33.25 + 0.0368 * T_K + 1.096e-5 * T_K**2

def specific_heat_Cp_Li(T_C):
    T_K = T_C + 273.15
    if 200 < T_K < 453:
        return (-6.999e8 / T_K**4 + 1.087e4 / T_K**2 + 3.039 + 5.605e-6 * T_K**2) * 1e3
    else:
        return (1.044e5 / T_K**2 - 135.1 / T_K + 4.180) * 1e3

def C_specific_heat(T):
    return -0.000000 * T**4 + 0.000003 * T**3 - 0.004663 * T**2 + 3.670527 * T + 630.194408


T_graphite = np.array([0, 20, 100, 200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800])  # °C
density_graphite = np.array([1.82, 1.81, 1.79, 1.77, 1.73, 1.69, 1.66, 1.63, 1.60, 1.57, 1.54, 1.50]) * 1e3  # kg/m³

# Fit cubic polynomial (degree 3)
coeffs = np.polyfit(T_graphite, density_graphite, 3)

def graphite_density(T_C):

    a, b, c, d = coeffs
    return a * T_C**3 + b * T_C**2 + c * T_C + d


plt.figure(figsize=(7,4))
plt.plot(T_graphite, density_graphite, linestyle='-', color='brown')
plt.title('F6510 Graphite Density vs Temperature')
plt.xlabel('Temperature (°C)')
plt.ylabel('Density (kg/m³)')
plt.grid(True)
plt.tight_layout()
plt.show()

# -----------------------
# Combined plots
# -----------------------

T_range = np.linspace(0, 1000, 1000)  # Temperature range in °C




fig, axs = plt.subplots(3, 1, figsize=(3, 5), sharex=True)
plt.subplots_adjust(hspace=0.35)

# Density plot
axs[0].plot(T_range, [Li_rho(T) for T in T_range], label='Lithium', color='blue')
axs[0].plot(T_range, [graphite_density(T) for T in T_range], label='Graphite', color='red', linestyle='--')
axs[0].set_ylabel(r'$\rho$ (kg/m$^3$)')
axs[0].legend()
axs[0].grid(True)
axs[0].minorticks_on()                      # Enable minor ticks
axs[0].grid(which='minor', linestyle=':', linewidth=0.5, alpha=0.7)
axs[0].set_ylim(0, 2000)
axs[0].set_xlim(0, 1000)

# Thermal conductivity plot
axs[1].plot(T_range, [Li_thermal_conductivity(T) for T in T_range], label='Lithium', color='blue')
axs[1].plot(T_range, C_thermal_conductivity(T_range), label='Graphite', color='red', linestyle='--')
axs[1].set_ylabel(r'$\kappa$ (W/m·K)')
#axs[1].legend(loc='upper right')
axs[1].grid(True)
axs[1].minorticks_on()                     # Enable minor ticks
axs[1].grid(which='minor', linestyle=':', linewidth=0.5, alpha=0.7)
axs[1].set_ylim(0, 120)
axs[1].set_xlim(0, 1000)

# Specific heat plot
axs[2].plot(T_range, [specific_heat_Cp_Li(T) for T in T_range], label='Lithium', color='blue')
axs[2].plot(T_range, C_specific_heat(T_range), label='Graphite', color='red', linestyle='--')
axs[2].set_ylabel(r'$C_p$ (J/kg·K)')
axs[2].set_xlabel('Temperature (°C)')
axs[2].grid(True)
axs[2].minorticks_on()                     # Enable minor ticks
axs[2].grid(which='minor', linestyle=':', linewidth=0.5, alpha=0.7)
axs[2].set_ylim(0, 5000)
axs[2].set_xlim(0, 1000)

plt.tight_layout()
plt.savefig("Li_C_properties_appendix.png", dpi=300)
plt.show()

