import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import os

x_data = np.array([-0.05544489, -0.0507309, -0.04174753, -0.03358036, -0.02614719, -0.01935555, -0.01316453,
                   -0.00755603, -0.00245243, 0.00497426, 0.012563, 0.01795314, 0.02403169, 0.03088529,
                   0.03865124, 0.04744072, 0.05723254, 0.06818729, 0.0804908, 0.09413599, 0.10907809,
                   0.12501805, 0.14181528, 0.15955389, 0.17792796, 0.18716496])

q_data = np.array([8.52e4, 8.52e4, 8.66e4, 9.22e4, 1.08e5, 1.47e5, 2.28e5, 4.01e5, 9.41e5,
                   8.44e6, 6.76e6, 6.09e6, 5.14e6, 4.17e6, 3.37e6, 2.76e6, 2.30e6, 1.92e6,
                   1.61e6, 1.36e6, 1.16e6, 1.01e6, 8.83e5, 7.12e5, 3.89e5, 3.89e5])


def eval_Li_evap_at_T_Cel(temperature):
    a1 = 5.055  
    b1 = -8023.0
    xm1 = 6.939 
    tempK = temperature + 273.15

    if np.any(tempK <= 0):
        raise ValueError("Temperature must be above absolute zero (-273.15°C).")

    vpres1 = 760 * 10**(a1 + b1 / tempK)  

    sqrt_argument = xm1 * tempK
    if np.any(sqrt_argument <= 0):
        raise ValueError(f"Invalid value for sqrt: xm1 * tempK has non-positive values.")

    fluxEvap = 1e4 * 3.513e22 * vpres1 / np.sqrt(sqrt_argument)  # Evaporation flux
    return fluxEvap



def solve_heat_equation_2d(
    Lx, Ly, Nx, Ny, dt, Nt,
    q_data, Tin_case,
    DEPTH, LI_DENSITY,
    heat_per_atom, graphite_x_pos,
    eval_Li_evap_at_T_Cel, 
    energy_per_Li1_neutralization,
    energy_per_Li2_neutralization,
    energy_per_Li3_neutralization,
    Li_thermal_conductivity,
    C_thermal_conductivity,
    specific_heat_Cp,
    C_specific_heat,
    Li_rho,
    graphite_density
):

    dx = Lx / (Nx - 1)
    dy = Ly / (Ny - 1)

    lithium_thickness = graphite_x_pos * dx  # Physical thickness of Li
    thickness_mm = lithium_thickness * 1e3
    print("Li thickness (mm):", thickness_mm)

    volume_li = Lx * lithium_thickness * DEPTH
    mass_li = LI_DENSITY * volume_li  # kg
    print("Lithium mass (g):", mass_li * 1e3)
    print("time step is:", dt)

    temp_surf = []
    no_itera = []

    T = np.zeros((Ny, Nx))
    try:
        T = np.load('T_surf2D.npy')
        print("Initial read from last stage, Temp max:", np.max(T[:, 1]))
    except (FileNotFoundError, ValueError) as e:
        T[:] = 25
        print("Error encountered, setting initial temp to 25°C:", e)

    for n in range(Nt):
        T_new = T.copy()

        for i in range(1, Nx - 1):
            for j in range(1, Ny - 1):
                T_ij = T[j, i]
                if i < graphite_x_pos:  # Lithium region
                    kappa = Li_thermal_conductivity(T_ij)
                    cp = specific_heat_Cp(T_ij)
                    rho = Li_rho(T_ij)
                else:  # Graphite region
                    kappa = C_thermal_conductivity(T_ij)
                    cp = C_specific_heat(T_ij)
                    rho = graphite_density(T_ij)

                alpha = 1 / (rho * cp)

                T_ip = T[j, i + 1]
                T_im = T[j, i - 1]
                if i + 1 < graphite_x_pos:
                    kappa_ip = Li_thermal_conductivity(T_ip)
                else:
                    kappa_ip = C_thermal_conductivity(T_ip)
                if i - 1 < graphite_x_pos:
                    kappa_im = Li_thermal_conductivity(T_im)
                else:
                    kappa_im = C_thermal_conductivity(T_im)
                kappa_xp = 0.5 * (kappa + kappa_ip)
                kappa_xm = 0.5 * (kappa + kappa_im)

                T_jp = T[j + 1, i]
                T_jm = T[j - 1, i]

                if i < graphite_x_pos:
                    kappa_jp = Li_thermal_conductivity(T_jp)
                    kappa_jm = Li_thermal_conductivity(T_jm)
                else:
                    kappa_jp = C_thermal_conductivity(T_jp)
                    kappa_jm = C_thermal_conductivity(T_jm)

                kappa_yp = 0.5 * (kappa + kappa_jp)
                kappa_ym = 0.5 * (kappa + kappa_jm)

                alpha = kappa / (rho * cp)

                term_x = (kappa_xp * (T_ip - T_ij) - kappa_xm * (T_ij - T_im)) / dx**2
                term_y = (kappa_yp * (T_jp - T_ij) - kappa_ym * (T_ij - T_jm)) / dy**2

                T_new[j, i] = T_ij + dt * (term_x + term_y) / (rho * cp)

        # Calculate evaporation and sputtering fluxes
        evap_flux = eval_Li_evap_at_T_Cel(T_new[:, 1])
        fluxPhysSput = 0
        fluxAd = 0
 
        Gamma = evap_flux + fluxPhysSput + fluxAd

        Gamma_incident_Li1 = 0#bbb.fnix[com.nx, :, 2] / com.sxnp[com.nx, :]
        Gamma_incident_Li2 = 0#bbb.fnix[com.nx, :, 3] / com.sxnp[com.nx, :]
        Gamma_incident_Li3 = 0#bbb.fnix[com.nx, :, 4] / com.sxnp[com.nx, :]

        Gamma_all = Gamma_incident_Li1 + Gamma_incident_Li2 + Gamma_incident_Li3
        Gamma_net = Gamma 

        # Latent heat calculations
        L_f_per_mol = 3000.0       # J/mol (your value)
        M_li = 6.941e-3            # kg/mol
        L_f_kg = L_f_per_mol / M_li  # J/kg

        latent_T_range = (T_new[:, 1] > 178) & (T_new[:, 1] < 182)
        L_f = np.zeros_like(T_new[:, 1])
        L_f[latent_T_range] = L_f_kg

        area = Lx * DEPTH

        if np.any(L_f > 0):
            q_latent = (mass_li * L_f) / (dt * area)
            q_latent = np.clip(q_latent, 0, 2e6)  # Clip max 2 MW/m²
        else:
            q_latent = np.zeros_like(T_new[:, 1])

        q_ion = (energy_per_Li1_neutralization * Gamma_incident_Li1
                 + energy_per_Li2_neutralization * Gamma_incident_Li2
                 + energy_per_Li3_neutralization * Gamma_incident_Li3)

        heat_flux_Li_surface = q_data - heat_per_atom * Gamma_net - q_latent + q_ion

        # Boundary condition at left edge (Li surface)
        kappa_left = np.vectorize(Li_thermal_conductivity)(T_new[:, 0])
        T_new[:, 0] = T[:, 1] + (heat_flux_Li_surface * dx) / kappa_left

        # Other boundary conditions: Neumann (zero-gradient)
        T_new[:, -1] = T[:, -2]  # right edge
        T_new[0, :] = T[1, :]    # bottom edge
        T_new[-1, :] = T[-2, :]  # top edge

        max_change = np.max(np.abs(T_new - T))
        temp_surface = np.max(T_new[:, 1])
        temp_surf.append(temp_surface)
        no_itera.append(n)

        T = T_new.copy()

        if max_change < 1e-5:
            print(f"Convergence achieved at time step {n*dt:.5f} s with max change {max_change:.2e}")
            break
        if n % (Nt // 10) == 0:
            x = np.linspace(0, Lx, Nx)
            y = np.linspace(0, Ly, Ny)
            X, Y = np.meshgrid(x, y)
            plt.figure(figsize=(12, 6))
            plt.contourf(X, Y, T, cmap='inferno')
            plt.colorbar(label='Temperature (°C)')
            plt.xlabel('x (m)')
            plt.ylabel('y (m)')
            plt.title(f'Temperature at t={n * dt:.4e} s')
            plt.axvline(x=graphite_x_pos * dx, color='g', linestyle='--', label='Graphite start')
            plt.annotate('Graphite', xy=(graphite_x_pos * dx, 0.02),
                         xytext=(graphite_x_pos * dx + 0.005, 0.1 * Ly),
                         arrowprops=dict(facecolor='black', width=2),
                         fontsize=14, color='red')
            plt.legend()
            plt.savefig(f'time{n * dt:.3e}.png', dpi=300)
            #plt.show()
            plt.close()


    return T, no_itera, temp_surf, Gamma_net, heat_flux_Li_surface, q_ion


def run_standalone_heat_sim():
    t_sim = 5e-0
    dt = 1e-4
    Nt = int(t_sim / dt)
    DEPTH = 0.05
    LI_DENSITY = 535
    Lx = 0.05
    Ly = x_data[-1] - x_data[0]
    Nx = 91
    Ny = len(q_data)
    graphite_x_pos = int(Nx / 10)
    Tin_case = 25  # Initial surface temperature

    # Energetics
    heat_per_atom = 147000 / 6.022e23  # J
    e = 1.60218e-19
    I0 = 5.39 * e
    I1 = 75.6 * e
    I2 = 122.4 * e

    # Material properties
    def Li_rho(T): return 562 - 0.1 * (T + 273.15)

    def Li_thermal_conductivity(T):
        T_K = T + 273.15
        if 200 < T_K < 453:
            return 44 + 0.02019 * T_K + 8037 / T_K
        else:
            return 33.25 + 0.0368 * T_K + 1.096e-5 * T_K**2

    def specific_heat_Cp(T):
        T_K = T + 273.15
        if 200 < T_K < 453:
            return (-6.999e8 / T_K**4 + 1.087e4 / T_K**2 + 3.039 + 5.605e-6 * T_K**2) * 1e3
        else:
            return (1.044e5 / T_K**2 - 135.1 / T_K + 4.180) * 1e3

    def C_specific_heat(T):
        return -0.000000 * T**4 + 0.000003 * T**3 - 0.004663 * T**2 + 3.670527 * T + 630.194408

    # Graphite conductivity fit
    T_exp = np.array([0, 25, 125, 300, 425, 600, 725, 1200, 1225, 1725, 2000])
    K_exp = np.array([105.26, 102.56, 93.02, 80.0, 72.73, 64.52, 59.70, 46.51, 45.98, 37.38, 33.90])
    a, b, c = curve_fit(lambda T, a, b, c: a * T**2 + b * T + c, T_exp, K_exp)[0]
    def C_thermal_conductivity(T): return a * T**2 + b * T + c

    T_graphite = np.array([0, 20, 100, 200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800])
    density_graphite = np.array([1.82, 1.81, 1.79, 1.77, 1.73, 1.69, 1.66, 1.63, 1.60, 1.57, 1.54, 1.50]) * 1e3
    coeffs = np.polyfit(T_graphite, density_graphite, 3)
    def graphite_density(T): return np.polyval(coeffs, T)

    # Solve
    T, no_it, temp_surf, Gamma_net, q_surf, q_ion = solve_heat_equation_2d(
        Lx, Ly, Nx, Ny, dt, Nt,
        q_data, Tin_case,
        DEPTH, LI_DENSITY,
        heat_per_atom, graphite_x_pos,
        eval_Li_evap_at_T_Cel, 
        I0, I1, I2,
        Li_thermal_conductivity,
        C_thermal_conductivity,
        specific_heat_Cp,
        C_specific_heat,
        Li_rho,
        graphite_density
    )

    print("Simulation complete. Final surface max T:", np.max(T[:, 1]))

    # Save arrays
    np.save('T_surf2D.npy', T)
    np.savetxt('Tsurf_max.txt', temp_surf)
    np.savetxt('q_surface.txt', q_surf)
    np.savetxt('t_sim.txt', np.multiply(no_it, dt))

    # Grid for plotting
    x = np.linspace(0, Lx, Nx)
    y = np.linspace(0, Ly, Ny)
    X, Y = np.meshgrid(x, y)
    t_array = np.multiply(no_it, dt)

    # === Plots ===
    # Final surface temp
    plt.figure(figsize=(8, 6))
    plt.plot(y, T[:, 1], label='Final Surface Temp')
    plt.xlabel('y (m)')
    plt.ylabel('Tsurf (°C)')
    plt.grid()
    plt.legend()
    plt.tight_layout()
    plt.savefig('Tsurf_final.png', dpi=300)

    # Heat flux
    plt.figure(figsize=(8, 6))
    plt.plot(y, q_data / 1e6, label='Heat flux', color='red', marker='o')
    plt.xlabel('y (m)', fontsize=16)
    plt.ylabel('q$_{div}$ (MW/m²)', fontsize=16)
    plt.grid()
    plt.legend()
    plt.tight_layout()
    plt.savefig('heat_flux.png', dpi=300)

    # Dual axis
    fig, ax1 = plt.subplots(figsize=(8, 6))
    ax1.plot(y, q_data / 1e6, color='tab:red', marker='o')
    ax1.set_xlabel('y (m)', fontsize=16)
    ax1.set_ylabel('Heat flux (MW/m²)', color='tab:red', fontsize=16)
    ax1.tick_params(axis='y', labelcolor='tab:red')
    ax2 = ax1.twinx()
    ax2.plot(y, T[:, 1], color='tab:blue', marker='o')
    ax2.set_ylabel('Temperature (°C)', color='tab:blue', fontsize=16)
    ax2.tick_params(axis='y', labelcolor='tab:blue')
    plt.title('Heat Flux and Temperature on Surface')
    fig.tight_layout()
    plt.savefig('dual_axis_plot.png', dpi=300)

    # Tmax evolution
    plt.figure(figsize=(6, 4))
    plt.plot(t_array, temp_surf, color='red', marker='o')
    plt.xlabel('t$_{simulation}$ (s)', fontsize=16)
    plt.ylabel('T$_{surf}^{max}$ (°C)', fontsize=16)
    plt.grid()
    plt.tight_layout()
    plt.savefig('tsurf_max.png', dpi=300)

    # EPS versions
    for fmt in ['eps']:
        plt.figure(figsize=(5, 3))
        plt.plot(y, q_data / 1e6, color='tab:red', marker='o')
        plt.xlabel('y (m)', fontsize=16)
        plt.ylabel('Heat flux (MW/m²)', fontsize=16)
        plt.grid()
        plt.tight_layout()
        plt.savefig(f'heat.{fmt}', format=fmt, dpi=300)

        plt.figure(figsize=(5, 3))
        plt.plot(t_array, temp_surf, color='red')
        plt.xlabel('t$_{simulation}$ (s)', fontsize=16)
        plt.ylabel('T$_{surf}^{max}$ (°C)', fontsize=16)
        plt.grid()
        plt.ylim([0, 900])
        plt.xlim([0, t_sim])
        plt.tight_layout()
        plt.savefig(f'tsurf_max.{fmt}', format=fmt, dpi=300)

    # Combined heat flux + 2D temp
    fig = plt.figure(figsize=(8, 4))
    gs = gridspec.GridSpec(1, 2, width_ratios=[1, 2], wspace=0.05)

    ax0 = plt.subplot(gs[0])
    ax0.plot(q_data / 1e6, y, color='red', marker='o')
    ax0.set_xlabel('q$_{\\perp}$ (MW/m²)', fontsize=18)
    ax0.set_ylabel('y (m)', fontsize=18)
    ax0.set_title('(a) q$_\\perp$', fontsize=18)
    ax0.tick_params(labelsize=14)
    ax0.grid(True)
    ax0.minorticks_on()
    ax0.grid(which='minor', linestyle=':', linewidth=0.5)
    ax0.set_xlim([10, 0])
    ax0.set_ylim([Ly, 0])

    ax1 = plt.subplot(gs[1], sharey=ax0)
    cf = ax1.contourf(X, Y, T, cmap='plasma')
    cbar = plt.colorbar(cf, ax=ax1)
    cbar.set_label('Temperature (°C)', fontsize=16)
    cbar.ax.tick_params(labelsize=14)
    ax1.set_xlabel('x (m)', fontsize=18)
    ax1.set_title('(b) Temperature Distribution', fontsize=18)
    ax1.axvline(x=graphite_x_pos * (Lx / (Nx - 1)), color='g', linestyle='--')
    ax1.annotate('Graphite', xy=(graphite_x_pos * (Lx / (Nx - 1)), 0.002), xytext=(0.005, 0.1 * Ly),
                 arrowprops=dict(facecolor='black', width=2), fontsize=16, color='red')
    ax1.tick_params(labelsize=14)
    plt.setp(ax1.get_yticklabels(), visible=False)

    plt.tight_layout()
    plt.savefig('combined_heatflux_temp_highres.png', dpi=300)
    plt.show()

# Run it
run_standalone_heat_sim()
