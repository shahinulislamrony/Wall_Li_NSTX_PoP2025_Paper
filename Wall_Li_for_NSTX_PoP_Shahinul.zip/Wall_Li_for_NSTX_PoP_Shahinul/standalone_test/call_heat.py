import sys
import math
import os
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import UEDGE_utils.analysis as ana
import UEDGE_utils.plot as utplt
from uedge import *
from uedge.hdf5 import *
from uedge.rundt import *
import uedge_mvu.plot as mp
import uedge_mvu.utils as mu
import uedge_mvu.analysis as mana
import uedge_mvu.tstep as ut
import UEDGE_utils.analysis as ana
from runcase import *
import traceback
import heat_code


x_data = np.array([-0.05544489, -0.0507309, -0.04174753, -0.03358036, -0.02614719, -0.01935555, -0.01316453, -0.00755603, -0.00245243, 0.00497426,
                   0.012563, 0.01795314, 0.02403169, 0.03088529, 0.03865124, 0.04744072, 0.05723254, 0.06818729, 0.0804908, 0.09413599,
                   0.10907809, 0.12501805, 0.14181528, 0.15955389, 0.17792796, 0.18716496]) 

q_data = np.array([8.516863747058426088e+04,
8.516863747058426088e+04,
8.658732672732640640e+04,
9.224168689024644846e+04,
1.082405806727624731e+05,
1.466081975609702058e+05,
2.283389318490335718e+05,
4.005193897112387349e+05,
9.411837655898311641e+05,
8.442317867601789534e+06,
6.758609278505317867e+06,
6.093629471681456082e+06,
5.143711920255075209e+06,
4.166083592164705973e+06,
3.367501593478952069e+06,
2.760775028947197832e+06,
2.298189146693516523e+06,
1.918289905024330597e+06,
1.605707128312068060e+06,
1.355246104763937416e+06,
1.158708622615067521e+06,
1.007663975185001036e+06,
8.828309174558679806e+05,
7.124721239178314572e+05,
3.894704975398445386e+05,
3.894704975398445386e+05,
])


t_run = 5.0  # seconds
dt_each = 10e-3  # time step
Tsurf_max = []

# === Run simulation ===
try:
    T, no_it, temp_surf, Gamma, qsurf, qion = heat_code.run_heat_simulation(
        bbb=bbb, com=com, t_sim=dt_each
    )
    Tsurf = T
    np.save('T_surf2D.npy', T)
    
    T_max = np.max(Tsurf[:, 1])
    print('Peak temp is:', T_max)
    Tsurf_max.append(T_max)
    
    final_temperature = Tsurf[:, 1]
    fluxEvap = eval_Li_evap_at_T_Cel(final_temperature)
    fluxPhysSput = flux_Li_Phys_Sput(bbb=bbb, com=com, UEDGE=True)
    fluxAd = flux_Li_Ad_atom(final_temperature, bbb=bbb, com=com, Yield=1e-3, YpsYad=1e-3, eneff=0.9, A=1e-7)
    tot = fluxEvap + fluxAd

    # Save results
    for data, name in zip(
        [Tsurf[:, 1], qsurf, qion, Gamma, fluxEvap, fluxPhysSput, fluxAd, tot],
        ['T_surfit', 'q_Li_surface', 'q_ion', 'Gamma_Li_surface', 
         'Evap_flux', 'PhysSput_flux', 'Adstom_flux', 'Total_Li_flux']
    ):
        save_csv(data, name.split('_')[0], name, i)

    print('---- Heat simulation completed ----')
    print('Surface temperature array length:', len(Tsurf))

except Exception as e:
    print(f"[ERROR] Failed to run heat simulation: {e}")
    traceback.print_exc()

# === Mesh Preparation ===
x = np.linspace(0, Lx, Nx)
y = np.linspace(0, Ly, Ny)
X, Y = np.meshgrid(x, y)

# === Plot: 2D Temperature Distribution ===
plt.figure(figsize=(6, 4))
cf = plt.contourf(X, Y, T[0], cmap='inferno')
cbar = plt.colorbar(cf)
cbar.set_label('Temperature (°C)', fontsize=18)
cbar.ax.tick_params(labelsize=14)

plt.xlabel('x (m)', fontsize=18)
plt.ylabel('y (m)', fontsize=18)
plt.title('Temperature Distribution')
plt.axvline(x=graphite_x_pos * dx, color='g', linestyle='--', label='Graphite Position')
plt.annotate('Graphite Region', xy=(graphite_x_pos * dx, 0.002), 
             xytext=(graphite_x_pos * dx + 0.0005, 0.1 * Ly),
             arrowprops=dict(facecolor='black', width=2), fontsize=20, color='red')
plt.legend()
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.tight_layout()
plt.savefig('final_2D.png', dpi=300)

# === Plot: Heat Flux Profile ===
plt.figure(figsize=(8, 6))
plt.plot(np.linspace(0, Ly, len(q_data)), q_data / 1e6, label='Heat flux', color='red', marker='o')
plt.xlabel('y (m)', fontsize=16)
plt.ylabel('q$_{div}$ (MW/m²)', fontsize=16)
plt.grid()
plt.legend()
plt.title('UEDGE Heat Flux on LM surface')
plt.tight_layout()
plt.savefig('heat_flux.png', dpi=300)

# === Plot: Surface Temperature ===
plt.figure(figsize=(8, 6))
plt.plot(Y[:, 0], T[0][:, 1], label='Temperature on surface', color='b', marker='o')
plt.xlabel('y (m)', fontsize=16)
plt.ylabel('Surface temp (°C)', fontsize=16)
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig('final_Tsurf.png', dpi=300)

# === Dual Axis Plot ===
fig, ax1 = plt.subplots(figsize=(8, 6))
ax1.set_xlabel('y (m)', fontsize=16)
ax1.set_ylabel('Heat flux (MW/m²)', fontsize=16, color='red')
ax1.plot(Y[:, 0], q_data / 1e6, color='red', marker='o')
ax1.tick_params(axis='y', labelcolor='red')
ax1.grid(True)

ax2 = ax1.twinx()
ax2.set_ylabel('Temperature (°C)', fontsize=16, color='blue')
ax2.plot(Y[:, 0], T[0][:, 1], color='blue')
ax2.tick_params(axis='y', labelcolor='blue')
fig.tight_layout()
ax2.legend(['Temperature'], loc='upper right')
plt.title('Heat Flux and Temperature on Surface')
plt.savefig('dual_axis_plot.png', dpi=300)
plt.show()

# === Time Evolution Plots ===
t_sim = np.multiply(T[1], dt_each)
np.savetxt('Tmax.txt', T[2])
np.savetxt('tsim.txt', t_sim)
np.savetxt('final.npy', T[0])
np.savetxt('q_surface', T[3])

plt.figure(figsize=(6, 4))
plt.plot(t_sim, T[2], color='red', marker='o')
plt.ylabel('T$_{surf}^{max}$ (°C)', fontsize=16)
plt.xlabel('t$_{simulation}$ (s)', fontsize=16)
plt.grid()
plt.ylim([0, 800])
plt.tight_layout()
plt.savefig('tsurf_max.png', dpi=300)

# === Export EPS Format ===
for fname in ['tsurf_max.eps', 'heat.eps']:
    plt.figure(figsize=(5, 3))
    plt.plot(Y[:, 0], q_data / 1e6, color='tab:red', marker='o', label='Heat flux')
    plt.xlabel('y (m)', fontsize=16)
    plt.ylabel('Heat flux (MW/m²)', fontsize=16)
    plt.grid()
    plt.ylim([0, 10])
    plt.xlim([0, 0.25])
    plt.tick_params(axis='both', labelsize=16)
    plt.tight_layout()
    plt.savefig(fname, format='eps', dpi=300)

# === Combined Heat Flux & 2D Temperature Plot ===
fig = plt.figure(figsize=(8, 4))
gs = gridspec.GridSpec(1, 2, width_ratios=[1, 2], wspace=0.05)

# Left subplot: heat flux
ax0 = plt.subplot(gs[0])
y_vals = np.linspace(0, Ly, len(q_data))
ax0.plot(q_data / 1e6, y_vals, color='red', marker='o')
ax0.set_xlabel('q$_{\\perp}$ (MW/m²)', fontsize=18)
ax0.set_ylabel('y (m)', fontsize=18)
ax0.set_title('(a) q$_\\perp$', fontsize=18)
ax0.set_xlim([10, 0])  # Inverted
ax0.set_ylim([Ly, 0])
ax0.tick_params(labelsize=14)
ax0.grid(True)
ax0.minorticks_on()
ax0.grid(which='minor', linestyle=':', linewidth=0.5, color='gray')

# Right subplot: 2D temperature
ax1 = plt.subplot(gs[1], sharey=ax0)
cf = ax1.contourf(X, Y, T[0], cmap='plasma')
cbar = plt.colorbar(cf, ax=ax1)
cbar.set_label('Temperature (°C)', fontsize=16)
cbar.ax.tick_params(labelsize=14)

ax1.set_xlabel('x (m)', fontsize=18)
ax1.set_title('(b) Temperature Distribution', fontsize=18)
ax1.axvline(x=graphite_x_pos * dx, color='g', linestyle='--', label='Graphite Position')
ax1.annotate('Graphite Region', xy=(graphite_x_pos * dx, 0.002),
             xytext=(graphite_x_pos * dx + 0.0005, 0.1 * Ly),
             arrowprops=dict(facecolor='black', width=2), fontsize=16, color='red')
ax1.annotate('Li', xy=(graphite_x_pos * dx, 0.002),
             xytext=(0.002, 0.1 * Ly), fontsize=16, color='white')
ax1.tick_params(labelsize=14)
ax1.set_xlim([0, Lx])
ax1.set_ylim([0, Ly])
plt.setp(ax1.get_yticklabels(), visible=False)
ax1.legend(fontsize=14)

plt.tight_layout()
plt.savefig('combined_heatflux_temp_highres.png', dpi=300)
plt.show()
