# UEDGE_utils

Developed for UEDGE 7.0.9.2.2. Python 3 and linux are recommended to avoid bugs.

## Setup

Set up UEDGE_utils as a package by running the following command inside the directory containing `setup.py`:

    pip3 install .
