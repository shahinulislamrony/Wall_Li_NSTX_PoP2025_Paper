import os
import datetime
import copy
import numpy as np
from scipy.optimize import curve_fit
from scipy.special import erfc
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection, LineCollection
from matplotlib.backends.backend_pdf import PdfPages
import h5py
from uedge import bbb, com, api
from uedge import __version__ as uedgeVersion
from matplotlib.collections import PolyCollection
from mpl_toolkits.axes_grid1 import make_axes_locatable



def plotmesh(iso=True, zshift=0.0, xlim=None, ylim=None, yinv=False, title="UEDGE grid", subtitle=None, show=True):

    #fig,ax = plt.subplots(1)

    if (iso):
        plt.axes().set_aspect('equal', 'datalim')
    else:
        plt.axes().set_aspect('auto', 'datalim')

    #plt.plot([np.min(com.rm),np.max(com.rm)], [np.min(com.zm),np.max(com.zm)])
        
    for iy in np.arange(0,com.ny+2):
        for ix in np.arange(0,com.nx+2):
            plt.plot(com.rm[ix,iy,[1,2,4,3,1]],
                     com.zm[ix,iy,[1,2,4,3,1]]+zshift, 
                     color="black", linewidth=0.5)
            
    plt.xlabel('R [m]')
    plt.ylabel('Z [m]')
    #fig.suptitle('UEDGE grid')
    #plt.title('UEDGE grid')
    plt.suptitle(title)
    plt.title(subtitle, loc="left")
    plt.grid(False)
    #plt.tight_layout()
    #plt.tight_layout(pad=2.0)
    #plt.subplots_adjust(left=0.15)

    if xlim:
        plt.xlim(xlim)
    if ylim:
        plt.ylim(ylim)

    if yinv:
        plt.gca().invert_yaxis()

    plt.savefig('2D_plot.png', dpi=300)
        
    if show:
        plt.show()

def plotmesh_shahinul(iso=True, zshift=0.0, xlim=None, ylim=None, yinv=False, title="UEDGE grid", subtitle=None, show=True):

    #fig,ax = plt.subplots(1)

    if (iso):
        plt.axes().set_aspect('equal', 'datalim')
    else:
        plt.axes().set_aspect('auto', 'datalim')

    #plt.plot([np.min(com.rm),np.max(com.rm)], [np.min(com.zm),np.max(com.zm)])
        
    for iy in np.arange(0,com.ny+2):
        for ix in np.arange(0,com.nx+2):
            plt.plot(com.rm[ix,iy,[1,2,4,3,1]],
                     com.zm[ix,iy,[1,2,4,3,1]]+zshift, 
                     color="black", linewidth=0.5)
            
    plt.xlabel('R [m]')
    plt.ylabel('Z [m]')
    #fig.suptitle('UEDGE grid')
    #plt.title('UEDGE grid')
    plt.suptitle(title)
    plt.title(subtitle, loc="left")
    plt.grid(False)
    #plt.tight_layout()
    #plt.tight_layout(pad=2.0)
    #plt.subplots_adjust(left=0.15)

    if xlim:
        plt.xlim(xlim)
    if ylim:
        plt.ylim(ylim)

    if yinv:
        plt.gca().invert_yaxis()

    plt.savefig('2D_plot.png', dpi=300)
        
    if show:
        plt.show()



def plotvar(var, zshift=0.0, iso=True, grid=False, label=None, vmin=None, vmax=None, yinv=False, title="UEDGE data", subtitle=None, show=True, cmap ='cmap', log = False, xlim = False):
    
    patches = []

    for iy in np.arange(0,com.ny+2):
        for ix in np.arange(0,com.nx+2):
            rcol=com.rm[ix,iy,[1,2,4,3]]
            zcol=com.zm[ix,iy,[1,2,4,3]]+zshift
            rcol.shape=(4,1)
            zcol.shape=(4,1)
            polygon = Polygon(np.column_stack((rcol,zcol)), True)
            patches.append(polygon)

    #-is there a better way to cast input data into 2D array?
    vals=np.zeros((com.nx+2)*(com.ny+2))

    for iy in np.arange(0,com.ny+2):
        for ix in np.arange(0,com.nx+2):
            k=ix+(com.nx+2)*iy
            vals[k] = var[ix,iy]


     # Set vmin and vmax disregarding guard cells
    if not vmax:
        vmax = np.max(var)
    if not vmin:
        vmin = np.min(var)


    
    norm = matplotlib.colors.Normalize(vmin=vmin, vmax=vmax)

    if log:
       norm =  matplotlib.colors.LogNorm(vmin=vmin, vmax=vmax)

    ###p = PatchCollection(patches, cmap=cmap, norm=norm)
    p = PatchCollection(patches, norm=norm,cmap=cmap)
    p.set_array(np.array(vals))




    fig,ax = plt.subplots(1)

    ax.add_collection(p)
    ax.autoscale_view()
    plt.colorbar(p, label=label)
     

    if iso:
        plt.axis('equal')  # regular aspect-ratio
    
    fig.suptitle(title)
    ax.set_title(subtitle, loc="left")
    plt.xlabel('R [m]')
    plt.ylabel('Z [m]')

    if grid:
        plt.grid(True)

    if yinv:
        plt.gca().invert_yaxis()

    if xlim:
       plt.xlim([0.2, 0.6])
       plt.ylim([-1.6, -1.3]) 
        
    #if (iso):
    #    plt.axes().set_aspect('equal', 'datalim')
    #else:
    #    plt.axes().set_aspect('auto', 'datalim')

    if show:
        plt.show()


def plotvar_shahinul(var, zshift=0.0, iso=True, grid=False, label=None, vmin=None, vmax=None, yinv=False, title="UEDGE data", subtitle=None, show=True, cmap='turbo', log=False, xlim=False):
    patches = []

    # Create patches for the mesh
    for iy in np.arange(0, com.ny + 2):
        for ix in np.arange(0, com.nx + 2):
            rcol = com.rm[ix, iy, [1, 2, 4, 3]]
            zcol = com.zm[ix, iy, [1, 2, 4, 3]] + zshift
            rcol.shape = (4, 1)
            zcol.shape = (4, 1)
            polygon = Polygon(np.column_stack((rcol, zcol)), True)
            patches.append(polygon)

    # Prepare data values
    vals = np.zeros((com.nx + 2) * (com.ny + 2))
    for iy in np.arange(0, com.ny + 2):
        for ix in np.arange(0, com.nx + 2):
            k = ix + (com.nx + 2) * iy
            vals[k] = var[ix, iy]

    # Set vmin and vmax disregarding guard cells
    if not vmax:
        vmax = np.max(var)
    if not vmin:
        vmin = np.min(var)

    norm = matplotlib.colors.Normalize(vmin=vmin, vmax=vmax)
    if log:
        norm = matplotlib.colors.LogNorm(vmin=vmin, vmax=vmax)

    # Create patch collection
    p = PatchCollection(patches, norm=norm, cmap=cmap)
    p.set_array(np.array(vals))

    # Create figure and axis
    fig, ax = plt.subplots(figsize=(6, 4))  # Set figure size for paper (width x height in inches)

    ax.add_collection(p)
    ax.autoscale_view()
    plt.colorbar(p, label=label)

    # Set aspect ratio
    if iso:
        ax.set_aspect('equal')  # Regular aspect ratio

    # Set titles and labels
    fig.suptitle(title, fontsize=16)
    ax.set_title(subtitle, loc="left")
    plt.plot(com.rm[:, com.iysptrx + 1, 2], com.zm[:, com.iysptrx + 1, 2], '--m', linewidth=2)
    plt.xlabel('R [m]', fontsize=16)
    plt.ylabel('Z [m]', fontsize=16)
    plt.yticks(fontsize=14)
    plt.xticks(fontsize=14)
    plt.tight_layout()
    #fig.subplots_adjust(top=0.9, bottom=0.1, left=0.1, right=0.9)

    # Add grid if requested
    if grid:
        plt.grid(True)

    # Invert y-axis if requested
    if yinv:
        ax.invert_yaxis()

    # Set axis limits if provided
    if xlim:
        ax.set_xlim([0.3, 0.9])
        ax.set_ylim([-1.62, -1.2])

    # Save the figure in high quality
    plt.savefig('figure.png', dpi=600, format='png')  # Save high-quality PNG
    plt.savefig('figure.eps', format='eps')           # Save high-quality EPS

    # Show the plot if requested
    if show:
        plt.show()

def plot_multiple_vars_shahinul(vars, zshift=0.0, iso=True, grid=True, labels=None, vmin=None, vmax=None, yinv=False, titles=None, show=True, cmap='turbo', log=False, xlim=True, figsize=(10, 5), cbar_fontsize=12):
    num_vars = len(vars)  # Number of variables to plot
    fig, axes = plt.subplots(1, num_vars, figsize=figsize, sharey=True, constrained_layout=False)  # Shared y-axis

    # Calculate global vmin and vmax if not provided
    if vmin is None:
        vmin = min(np.min(var) for var in vars)
    if vmax is None:
        vmax = max(np.max(var) for var in vars)

    # Define normalization (linear or logarithmic)
    norm = matplotlib.colors.Normalize(vmin=vmin, vmax=vmax)
    if log:
        norm = matplotlib.colors.LogNorm(vmin=max(vmin, 1e-10), vmax=vmax)  # Handle log normalization safely

    for i, var in enumerate(vars):
        patches = []
        vals = np.zeros((com.nx + 2) * (com.ny + 2))

        # Create patches for the mesh
        for iy in np.arange(0, com.ny + 2):
            for ix in np.arange(0, com.nx + 2):
                rcol = com.rm[ix, iy, [1, 2, 4, 3]]
                zcol = com.zm[ix, iy, [1, 2, 4, 3]] + zshift
                rcol.shape = (4, 1)
                zcol.shape = (4, 1)
                polygon = Polygon(np.column_stack((rcol, zcol)), True)
                patches.append(polygon)

                # Store data values
                k = ix + (com.nx + 2) * iy
                vals[k] = var[ix, iy]

        # Create patch collection
        p = PatchCollection(patches, norm=norm, cmap=cmap)
        p.set_array(np.array(vals))

        # Add patches to subplot
        ax = axes[i]
        ax.add_collection(p)

        # Set axis limits if provided
        if xlim:
            ax.set_xlim([0.3, 0.9])
            ax.set_ylim([-1.62, -1.2])
        else:
            ax.autoscale_view()

        # Set aspect ratio
        if iso:
            ax.set_aspect('equal')

        # Set titles and labels
        subplot_title = titles[i] if titles else f"Variable {i+1}"
        ax.set_title(subplot_title, fontsize=16, loc="left")
        ax.set_xlabel('R [m]', fontsize=12)
        if i == 0:
            ax.set_ylabel('Z [m]', fontsize=12)

        # Add grid if requested
        if grid:
            ax.grid(True)

        # Invert y-axis if requested
        if yinv:
            ax.invert_yaxis()

        # Add plot line
        ax.plot(com.rm[:, com.iysptrx + 1, 2], com.zm[:, com.iysptrx + 1, 2], '--m', linewidth=2)

    # Add shared color bar to the right of the last subplot
    divider = make_axes_locatable(axes[-1])  # Use the last subplot
    cax = divider.append_axes("right", size="5%", pad=0.1)  # Adjust size and padding
    cbar = fig.colorbar(p, cax=cax)
    cbar.ax.tick_params(labelsize=cbar_fontsize)  # Adjust tick size
    # No label for the color bar

    # Adjust layout
    fig.tight_layout()

    # Save the figure in high quality
    plt.savefig('multiple_variables.png', dpi=600, format='png')  # Save high-quality PNG
    plt.savefig('multiple_variables.eps', format='eps')           # Save high-quality EPS

    # Show the plot if requested
    if show:
        plt.show()

def plotrprof(var, ix=-1, use_psin=False, title="UEDGE data", subtitle=None, lines=True, dots=False, xlim=None, ylim=None, xlog=False, ylog=False, show=True):
    # Plotting radial profiles of UEDGE data
    #
    # Usage example:
    # plotrprof(bbb.te/ev, title="Te [eV]")
    # plotrprof(ni[:,:,1], title="Nn [m-3]")
    #==================================#
    
    fig,ax = plt.subplots(1)

    if (ix<0):
        ix0=bbb.ixmp
    else:
        ix0=ix

    if (use_psin):
        psin=(com.psi-com.simagx)/(com.sibdry-com.simagx)
        xcoord=psin[ix0,:,0]
        xlabel='Psi_norm'
    else:
        ###xcoord=com.rm[ix0,:,0]-com.rm[ix0,com.iysptrx,0]
        xcoord=com.rm[bbb.ixmp,:,0]-com.rm[bbb.ixmp,com.iysptrx,0]
        xlabel='rho=R-Rsep [m]'
        

    if (lines):
        ##plt.plot(com.rm[ix0,:,0]-com.rm[ix0,com.iysptrx,0],var[ix0,:])
        plt.plot(xcoord, var[ix0,:])
    
    if (dots):
        ##plt.plot(com.rm[ix0,:,0]-com.rm[ix0,com.iysptrx,0],var[ix0,:],"o")
        plt.plot(xcoord, var[ix0,:],"o")

        
    if xlim:
        plt.xlim(xlim)

    if ylim:
        plt.ylim(ylim)

    if ylog:
        plt.yscale('log')

    if xlog:
        plt.xscale('log')
        
    plt.xlabel(xlabel)
    fig.suptitle(title)
    ax.set_title(subtitle, loc="right")
    plt.grid(True)

    if show:
        plt.show()







def plotpprof(var, ir=-1, parallel=False, title="UEDGE data", xlog=False, ylog=False,
              subtitle=None, lines=True, dots=False, xlim=None, ylim=None, show=True):


    fig,ax = plt.subplots(1)

    
    if (ir<0):
        ir=com.ny+1
    
    if parallel:
        #-parallel length
        x=np.cumsum(com.dx[:,ir]/com.rr[:,ir])
        xlabel="lpar [m]"
    else:
        #-poloidal length
        x=np.cumsum(com.dx[:,ir])
        xlabel="lpol [m]"
    

    if (lines):
        plt.plot(x, var[:,ir])
        
    if (dots):
        plt.plot(x, var[:,ir],"o")

        
    if xlim:
        plt.xlim(xlim)

    if ylim:
        plt.ylim(ylim)

    if ylog:
        plt.yscale('log')

    if xlog:
        plt.xscale('log')


    plt.xlabel(xlabel)
    fig.suptitle(title)
    ax.set_title(subtitle, loc="right")
    plt.grid(True)
    

    if show:
        plt.show()



        

        
def show_flow(vx, vy, scale=1.0, ispec=0, color="red", xlim=None, ylim=None, title=None, subtitle=None):
#-show a vector field given by its UEDGE x,y components

    #-RZ components of the vector field                                                                                
    vr=np.zeros([com.nx+2,com.ny+2])
    vz=np.zeros([com.nx+2,com.ny+2])


    for ix in range(com.nx+1):
        for jy in range(com.ny+1):

	    #-unit vector in poloidal direction (given by R,Z components)                                             
            ex=np.array([com.rm[ix,jy,2]-com.rm[ix,jy,1],com.zm[ix,jy,2]-com.zm[ix,jy,1]])
            ex=ex/np.sqrt(np.dot(ex,ex))

            #-unit vectors in the radial direction (given by R,Z components)                                          
            ey=np.array([-ex[1],ex[0]])
            #ey=ey/np.sqrt(np.dot(ey,ey)) #-redundant


            #-change the direction in the private regions
            sign=1
            
            ##-inner lower leg PF
            if (ix>=0 and ix<=com.ixpt1[0] and jy<=com.iysptrx1[0]):
                sign=-1
                
            ##-inner upper leg PF
            if (ix>=com.ixpt2[0]+1 and ix<=com.ixlb[0]-1 and jy<=com.iysptrx1[0]+1):
                sign=-1

            ##-outer lower leg PF
            if (ix>=com.ixpt2[0]+1 and ix<=com.nx+1 and jy<=com.iysptrx1[0]):
                sign=-1
            
            ##-outer upper leg PF
            if (ix>=com.ixlb[0] and ix<=com.ixpt1[0] and jy<=com.iysptrx1[0]+1):
                sign=-1

            ey=ey*sign
                
                            
            #-flux vector (in RZ components)                                                                          
            vr[ix,jy]=vx[ix,jy]*ex[0] + vy[ix,jy]*ey[0]
            vz[ix,jy]=vx[ix,jy]*ex[1] + vy[ix,jy]*ey[1]


            #-set zero in guard cells                                                                                 
            if (ix==0 or ix==com.nx+1 or jy==0 or jy==com.ny+1):
                vr[ix,jy]=0.0
                vz[ix,jy]=0.0

                
    plotmesh(show=False, xlim=xlim, ylim=ylim, title=title, subtitle=subtitle)
    plt.quiver(com.rm[:,:,0], com.zm[:,:,0], vr*scale, vz*scale, color=color)
    plt.show()



def show_flow_ni(ispec=0, flux=False, scale=1.0, color="red", xlim=None, ylim=None, title=None, subtitle=None):
    #-show ion or neutral density flow
    
    ##-X,Y components of the the flux vector
    vx=bbb.fnix[:,:,ispec]/com.dy
    vy=bbb.fniy[:,:,ispec]/com.dx

    if not(flux):
        #-velocity vector
        vx=vx/bbb.ni[:,:,ispec]
        vy=vy/bbb.ni[:,:,ispec]
    
    show_flow(vx, vy, scale=scale, color=color, xlim=xlim, ylim=ylim, title=title, subtitle=subtitle)



    

def show_flow_test(option=2, scale=1.0, color="red", xlim=None, ylim=None, title=None, subtitle=None):
    #-show test flow
    
    ##-X,Y components of the the flux vector
    
    if (option==0):
        print("Using unit poloidal vector flow")
        vx=1.0+np.zeros([com.nx+2,com.ny+2])
        vy=0.0+np.zeros([com.nx+2,com.ny+2])
    elif (option==1):
        print("Using unit radial vector flow")
        vx=0.0+np.zeros([com.nx+2,com.ny+2])
        vy=1.0+np.zeros([com.nx+2,com.ny+2])    
    else:
        print("Using unit radial=poloidal vector flow")
        vx=1.0+np.zeros([com.nx+2,com.ny+2])
        vy=1.0+np.zeros([com.nx+2,com.ny+2])

    show_flow(vx, vy, scale=scale, color=color, xlim=xlim, ylim=ylim, title=title, subtitle=subtitle)



def zoom(factor):
    '''
    Zoom in/out of plot view, adjusting x and y axes by the same factor.
    '''
    x1, x2 = plt.gca().get_xlim()
    plt.xlim([(x1+x2)/2-factor*(x2-x1)/2, (x1+x2)/2+factor*(x2-x1)/2])
    y1, y2 = plt.gca().get_ylim()
    plt.ylim([(y1+y2)/2-factor*(y2-y1)/2, (y1+y2)/2+factor*(y2-y1)/2])


def getPatches():
    '''
    Create cell patches for 2D plotting.
    '''
    patches = []
    for iy in np.arange(0,com.ny+2):
        for ix in np.arange(0,com.nx+2):
            rcol=com.rm[ix,iy,[1,2,4,3]]
            zcol=com.zm[ix,iy,[1,2,4,3]]
            patches.append(np.column_stack((rcol,zcol)))
    return patches
    

def plotvar_new(var, title='', label=None, iso=True, rzlabels=True, stats=True, message=None,
            orientation='vertical', vmin=None, vmax=None, minratio=None, cmap=plt.cm.viridis, log=False,
            patches=None, show=True, sym=False, showGuards=False, colorbar=True, extend=None, norm=None,linscale=1):
    '''
    Plot a quantity on the grid in 2D. 
    
    Args:
        patches: supplying previously computed patches lowers execution time
        show: set this to False if you are calling this method to create a subplot
        minratio: set vmin to this fraction of vmax (useful for log plots with large range)
        sym: vmax=-vmin
    '''
    plt.rcParams['axes.axisbelow'] = True
    
    if not patches:
        patches = getPatches()

    # reorder value in 1-D array
    vals = var.T.flatten()
    
    # Set vmin and vmax disregarding guard cells
    if not vmax:
        vmax = np.max(analysis.nonGuard(var))
    if not vmin:
        vmin = np.min(analysis.nonGuard(var))
        
    if show:
        rextent = np.max(com.rm)-np.min(com.rm)
        zextent = np.max(com.zm)-np.min(com.zm)
        fig, ax = plt.subplots(1, figsize=(4.8, 6.4))
    else:
        ax = plt.gca()
        
    if sym:
        maxval = np.max(np.abs([vmax, vmin]))
        vmax = maxval
        vmin = -maxval
        cmap = plt.cm.bwr
        plt.gca().set_facecolor('lightgray')
    else:
        plt.gca().set_facecolor('gray')
        
    _extend = 'neither' # minratio related
        
    # Need to make a copy for set_bad
    cmap = copy.copy(cmap)
    
    if not np.any(var > 0):
        log = False

    if log:
        cmap.set_bad((1,0,0,1))
        if vmin > 0:
            if minratio:
                vmin = vmax/minratio
                _extend = 'min'
            _norm = matplotlib.colors.LogNorm(vmin=vmin, vmax=vmax)
        else:
            if minratio:
                # linscale=np.log10(minratio)/linscale
                _norm = matplotlib.colors.SymLogNorm(vmin=vmin, vmax=vmax, linthresh=vmax/minratio, linscale=linscale, base=10)
            else:
                _norm = matplotlib.colors.SymLogNorm(vmin=vmin, vmax=vmax, linthresh=(vmax-vmin)/1000, linscale=linscale, base=10)
    else:
        _norm = matplotlib.colors.Normalize(vmin=vmin, vmax=vmax)
    if norm:
        _norm = norm
    p =  PolyCollection(patches, array=np.array(vals), cmap=cmap, norm=_norm)
    
    #if (vmin > np.min(analysis.nonGuard(var))) and (vmax < np.max(analysis.nonGuard(var))):
     #   _extend = 'both'
    #elif vmin > np.min(analysis.nonGuard(var)):
     #   _extend = 'min'
    #elif vmax < np.max(analysis.nonGuard(var)):
     #   _extend = 'max'
    
    #if extend:
     #  _extend = extend
    
    if showGuards:
        plt.scatter(com.rm[0,:,0], com.zm[0,:,0], c=var[0,:], cmap=cmap)
        plt.scatter(com.rm[com.nx+1,:,0], com.zm[com.nx+1,:,0], c=var[com.nx+1,:], cmap=cmap)
        plt.scatter(com.rm[:,0,0], com.zm[:,0,0], c=var[:,0], cmap=cmap)
        plt.scatter(com.rm[:,com.ny+1,0], com.zm[:,com.ny+1,0], c=var[:,com.ny+1], cmap=cmap)
        if 'dnbot' in com.geometry[0].decode('UTF-8'):
            plt.scatter(com.rm[bbb.ixmp-1,:,0], com.zm[bbb.ixmp-1,:,0], c=var[bbb.ixmp-1,:], cmap=cmap)
            plt.scatter(com.rm[bbb.ixmp,:,0], com.zm[bbb.ixmp,:,0], c=var[bbb.ixmp,:], cmap=cmap)

    ax.grid(False)
    plt.title(title)
    if rzlabels:
        plt.xlabel(r'$R$ [m]')
        plt.ylabel(r'$Z$ [m]')
    else:
        plt.gca().axes.get_xaxis().set_visible(False)
        plt.gca().axes.get_yaxis().set_visible(False)
        
    ax.add_collection(p)
    ax.autoscale_view()    

    if colorbar:
        if sym and log and minratio:
            # maxpow = int(np.log10(vmax))
            # minpow = int(np.log10(vmax/minratio)+0.5)
            # print(minpow, maxpow)
            # ticks = [-10**p for p in range(maxpow, minpow-1, -1)]
            # ticklabels = ['$-10^{%d}$' % p for p in range(maxpow, minpow-1, -1)]
            # ticks.append(0)
            # ticklabels.append('0')
            # ticks.extend([10**p for p in range(minpow, maxpow+1)])
            # ticklabels.extend(['$10^{%d}$' % p for p in range(minpow, maxpow+1)])
            
            # ticks = np.arange(1,10)
            # cbar = plt.colorbar(p, label=label, extend=_extend, orientation=orientation, ticks=ticks)
            # cbar.set_ticks(ticks)
            # cbar.set_ticklabels(ticklabels)
            # minticks = []
            # for p in range(maxpow, minpow-1, -1):
            #     minticks.extend([i*10**p for i in range(2, 10)])
            #cbar.set_ticks(minticks)
            cbar = plt.colorbar(p, label=label, extend=_extend, orientation=orientation)
        else:
            cbar = plt.colorbar(p, label=label, extend=_extend, orientation=orientation)
    
    if iso:
        plt.axis('equal')  # regular aspect-ratio
        
    
    
    if show:
        plt.tight_layout()
        plt.show(block=False)
    
